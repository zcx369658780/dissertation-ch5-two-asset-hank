"""Exact rational SOURCE_ONLY fixtures; no production, HA or equilibrium imports."""
from fractions import Fraction as F
from decimal import Decimal,localcontext
import json,pathlib,sys,copy
R=pathlib.Path(__file__).parent
def ss(xs):return sum(xs,F(0))
def interpolate(a,b):
 for k in ['province','metric','unit','population','time_type','geographic_basis','definition_version']:
  if a.get(k) in (None,'UNKNOWN') or b.get(k) in (None,'UNKNOWN'):return {'status':'INDETERMINATE_'+k}
  if a[k]!=b[k]:return {'status':'MISMATCH_'+k}
 if a.get('year')!=2017 or b.get('year')!=2019:return {'status':'ENDPOINT_YEAR_MISMATCH'}
 if not a.get('original_verified') or not b.get('original_verified'):return {'status':'ORIGINAL_ENDPOINT_UNVERIFIED'}
 if a.get('value') is None or b.get('value') is None:return {'status':'MISSING_ENDPOINT'}
 x,y=Decimal(str(a['value'])),Decimal(str(b['value']))
 if min(x,y)<=0:return {'status':'NONPOSITIVE_ENDPOINT'}
 with localcontext() as c:
  c.prec=40;loglin=(x*y).sqrt();arith=(x+y)/2
  return {'status':'I_CANDIDATE_NOT_OFFICIAL','log_linear':str(loglin),'arithmetic':str(arith),'method_delta':str(arith-loglin),'bracket':[str(min(x,y)),str(max(x,y))],'bracket_is_confidence_interval':False}
def run():
 tests=[]
 def check(name,actual,expected=True,detail=None):
  ok=actual==expected;tests.append(dict(name=name,actual=actual,expected=expected,pass_test=ok,detail=detail));return ok
 cases=[]
 for seed in [1,2]:
  n=31;H=[F(100+seed*53+7*i)+F(i*i,10) for i in range(n)];p=[F(30+seed*7+i,100) for i in range(n)];E=[H[i]*p[i] for i in range(n)]
  weights=[[F(1+((j+3)*(i+seed+2))%23+(20+i%9 if j==i else 0)) for i in range(n)] for j in range(n)]
  M=[[weights[j][i]/ss(weights[k][i] for k in range(n)) for i in range(n)] for j in range(n)]
  flow=[[M[j][i]*E[i] for i in range(n)] for j in range(n)]
  h=[[F(8+(2*j+i+seed)%13,10) for i in range(n)] for j in range(n)];eff=[[F(7+(j+3*i+seed)%11,10) for i in range(n)] for j in range(n)]
  D=[ss(flow[j]) for j in range(n)];L=[ss(flow[j][i]*h[j][i]*eff[j][i] for i in range(n)) for j in range(n)]
  w=[F(8+j%6,10) for j in range(n)];tax=[F(j%9,50) for j in range(n)]
  net=[ss(flow[j][i]*h[j][i]*eff[j][i]*w[j]*(1-tax[j]) for j in range(n)) for i in range(n)]
  gross=ss(w[j]*L[j] for j in range(n));T=ss(w[j]*L[j]*tax[j] for j in range(n))
  check(f'fixture{seed}_population_to_employment',all(0<E[i]<H[i] for i in range(n)))
  check(f'fixture{seed}_national_heads_conservation',ss(D)==ss(E))
  check(f'fixture{seed}_national_gross_net_tax',ss(net)+T==gross)
  cp=[F(15+i%7,100) for i in range(n)];cn=[F(30+i%9,100) for i in range(n)];prov=[]
  for i in range(n):
   check(f'fixture{seed}_origin_{i+1}_column',ss(M[j][i] for j in range(n))==1)
   check(f'fixture{seed}_origin_{i+1}_employment_flow',ss(flow[j][i] for j in range(n))==E[i])
   a=F(11+i,3);alpha=F(20+i%5,100);assets=H[i]*a;ae=alpha*assets;au=(1-alpha)*assets
   check(f'fixture{seed}_origin_{i+1}_B_wealth_split_per_s_H',E[i]*(ae/E[i])+(H[i]-E[i])*(au/(H[i]-E[i]))==assets)
   j=i;priv=ss(flow[j][k]*cp[k] for k in range(n));nonpriv=ss(flow[j][k]*cn[k] for k in range(n));other=D[j]-priv-nonpriv
   lp=ss(flow[j][k]*cp[k]*h[j][k]*eff[j][k] for k in range(n));ln=ss(flow[j][k]*cn[k]*h[j][k]*eff[j][k] for k in range(n))
   wp=1000*w[j]*lp/priv;wn=1000*w[j]*ln/nonpriv
   check(f'fixture{seed}_destination_{j+1}_coverage_heads',priv+nonpriv+other==D[j] and other>0)
   check(f'fixture{seed}_destination_{j+1}_coverage_wage_payment',priv*wp/1000+nonpriv*wn/1000==w[j]*(lp+ln))
   prov.append(dict(index=i+1,H_resident_NU=str(H[i]),E_origin_NU=str(E[i]),E_destination_NU=str(D[i]),L_destination_NU_eff=str(L[i]),net_labor_income_origin_MU=str(net[i]),w_stat_private_yuan_person_year=str(wp),w_stat_nonprivate_yuan_person_year=str(wn),assets_total_coefficient_of_s_H=str(assets),all_numbers='SYNTHETIC_FIXTURE_NOT_REAL_PROVINCE_CALIBRATION'))
  transposed=[[M[i][j] for i in range(n)] for j in range(n)]
  check(f'fixture{seed}_negative_transpose',any(ss(transposed[j][i] for j in range(n))!=1 for i in range(n)))
  check(f'fixture{seed}_negative_double_N',ss(flow[j][i]*H[i] for i in range(n) for j in range(n))!=ss(E))
  wrongtax=ss(flow[j][i]*h[j][i]*eff[j][i]*w[j]*(1-tax[i]) for i in range(n) for j in range(n))
  check(f'fixture{seed}_negative_origin_tax',wrongtax+T!=gross)
  doubletax=ss(flow[j][i]*h[j][i]*eff[j][i]*w[j]*(1-tax[j])**2 for i in range(n) for j in range(n))
  check(f'fixture{seed}_negative_double_tax',doubletax+T!=gross)
  check(f'fixture{seed}_negative_h_eff_omitted',ss(w[j]*D[j] for j in range(n))!=gross)
  check(f'fixture{seed}_negative_wage_factor_1000_omitted',1000*gross!=gross)
  check(f'fixture{seed}_negative_N_to_E_asset_replacement',ss(E[i]*F(11+i,3) for i in range(n))!=ss(H[i]*F(11+i,3) for i in range(n)))
  check(f'fixture{seed}_negative_employment_equals_firm_effective_labor',any(D[j]!=L[j] for j in range(n)))
  cases.append(dict(fixture=seed,matrix_dimension='destination_j_by_origin_i',period='SYNTHETIC_COMMON_ANNUAL_REFERENCE_PERIOD_NO_YEAR_END_TO_MEAN_INFERENCE',M=[[str(v) for v in r] for r in M],hours=[[str(v) for v in r] for r in h],efficiency=[[str(v) for v in r] for r in eff],provinces=prov,national=dict(E_origin=str(ss(E)),E_destination=str(ss(D)),gross_MU=str(gross),tax_MU=str(T),net_MU=str(ss(net))),unknown_real_HU='s_H remains symbolic; numeric fixture stores coefficients only'))
 # Hand-calculable independent two-region oracle: E=(50,50), M=[[4/5,1/10],[1/5,9/10]], efficiency=(1,2), wage=(2,3), tax=(1/10,1/5).
 check('independent_two_region_D',[F(4,5)*50+F(1,10)*50,F(1,5)*50+F(9,10)*50]==[45,55])
 check('independent_two_region_L',45+2*55==155)
 check('independent_two_region_gross_net_tax',90+330==120+225+75)
 a=dict(province='SYN_1',metric='private_wage',unit='yuan/person/year',population='URBAN_PRIVATE_UNIT',time_type='ANNUAL_AVERAGE',geographic_basis='UNIT_REPORTING',definition_version='SYNTHETIC_MATCH',year=2017,value=100,original_verified=True)
 b={**a,'year':2019,'value':121};r=interpolate(a,b);check('I_positive_geometric_110',Decimal(r['log_linear'])==110)
 negs=[('province','SYN_2','MISMATCH_province'),('metric','nonprivate_wage','MISMATCH_metric'),('time_type','YEAR_END','MISMATCH_time_type'),('geographic_basis','RESIDENCE','MISMATCH_geographic_basis'),('unit','wan_yuan','MISMATCH_unit'),('population','RESIDENT','MISMATCH_population'),('definition_version','UNKNOWN','INDETERMINATE_definition_version'),('year',2020,'ENDPOINT_YEAR_MISMATCH'),('value',None,'MISSING_ENDPOINT'),('value',0,'NONPOSITIVE_ENDPOINT'),('original_verified',False,'ORIGINAL_ENDPOINT_UNVERIFIED')]
 for k,v,expected in negs:check('I_negative_'+k+'_'+str(v),interpolate(a,{**b,k:v})['status'],expected)
 check('missing_not_zero',interpolate({**a,'value':None},b)['status'],'MISSING_ENDPOINT')
 check('survey_sample_count_not_mean_population',('RESPONDENT_SAMPLE','YEAR_END')!=('EXPANDED_TARGET_POPULATION','ANNUAL_AVERAGE'))
 assert all(s['pass_test'] for s in tests),[s for s in tests if not s['pass_test']]
 return dict(scope='SOURCE_ONLY_NONHA_SYNTHETIC_NOT_PRODUCTION_INTEGRATION',passed=len(tests),failed=0,fixtures=cases,tests=tests,independent_small_oracle=dict(H=[100,200],p=['1/2','1/4'],M=[['4/5','1/10'],['1/5','9/10']],D=[45,55],L=[45,110],w=[2,3],tax=['1/10','1/5'],gross=420,tax_total=75,net_origin=[120,225],net_total=345),science_calls=0)
if __name__=='__main__':
 sys.stdout.reconfigure(encoding='utf-8');out=run()
 with (R/'mapping_31_synthetic_oracles.json').open('x',encoding='utf-8') as f:json.dump(out,f,ensure_ascii=False,indent=2)
 print(json.dumps(dict(passed=out['passed'],failed=out['failed'],fixtures=2,science_calls=0)))
