# Synthetic classifier boundary and output contract

Input provenance is exclusively literal/generated synthetic fixtures. The library accepts bytes; it opens no file, resolves no filesystem path, performs no network requests, launches no process and executes no input text. Nested-archive tests are JSON metadata strings, not archives.

Parsing order: strict UTF-8; explicit/auto JSON containers validated by System.Text.Json; JSON string tokens decoded by the JSON parser; URI tokens validated by System.Uri; drive/UNC structure checked by character/component context. There is no regular-expression path verdict. A URI's whole span is classified before any drive decision. Ambiguous bare s:/ fragments are ordinary text, not inferred local files.

Raw JSON tokens with escapes are JSON_ESCAPED_FRAGMENT. Their parsed-string semantic candidates appear separately under tokens[].SemanticSpans. A raw escape does not prove an actual file exists or a secret has leaked. Invalid JSON/UTF-8 is UNKNOWN with FORMAT_PARSE_ERROR; no heuristic global unescape is performed.

Offsets are half-open. RawStart/RawEnd count .NET UTF-16 code units in OriginalText; ByteStart/ByteEnd count original UTF-8 bytes. DecodedStart/DecodedEnd index the decoded token string for JSON semantics. tokens[].Mapping maps each decoded UTF-16 unit to its original raw character and byte interval. Literal supplementary Unicode characters have two decoded UTF-16 units sharing the raw scalar interval. Escaped Unicode units map to their own six-character JSON escape intervals. The raw JSON token includes its quotes; unit maps exclude quotes. Original bytes, Base64, SHA256, parsed strings and raw tokens are retained.

Classification and security are distinct fields. Security policy is: UNKNOWN => BLOCK_UNKNOWN; Windows/UNC/credential candidates or traversal/ADS/local-file-URI flags => REVIEW_REQUIRED; ordinary/URI/serialization syntax without extra flags => NO_FLAG_IN_SYNTHETIC_TEXT. None of these is a leakage determination, filesystem identity claim, complete content-safety claim, or permission to publish. A credential candidate is not a verified credential.

Case-insensitive duplicate detection is lexical: separator normalization and OrdinalIgnoreCase comparison of path candidates only. It does not resolve dot segments, links, aliases or physical filesystem identity.

Metrics use per-sample, per-class label presence across raw spans and decoded semantic spans. These are multi-label TP/FP/FN/TN statistics, not span-level precision, production sensitivity or evidence that the old ZIP is safe.

Only src/PathClassifier_reliable.cs and tests/SyntheticSuite_reliable.cs were successfully compiled and used for the final suite. Earlier candidate sources, transfer/compile failure evidence and snapshots remain immutable. The original 491-member archive and all old run contents were never opened.
