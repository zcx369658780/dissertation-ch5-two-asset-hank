# 家庭—就业—企业劳动接口设计合同

状态：SOURCE_ONLY_MAPPING_PROPOSAL。方案A为下一次Owner讨论的优先建议，A/B均未采用。未修改原劳动迁移方程、家户N、HU、HA网格、工资/利率界、资产桥或任何生产算法。

## 同一期间的符号桥

在居民总体、期间、地区边界已经对齐的前提下：

\[
E_i=p_iH_i,\quad F_{ji}=M_{ji}E_i,\quad D_j=\sum_iF_{ji},\quad
L_j=\sum_iF_{ji}\tilde h_{ji}\epsilon_{ji}.
\]

H与E以NU计，M无量纲，h_tilde=该参考年实际工时/事先选定的参考年工时，epsilon为每参考工时劳动质量比，L为NU_eff。若小时本身保留hour，须把工资改为MU/(NU_eff·hour)，不能同时保留年工资再重复乘全年小时。当前真实h、epsilon、p、M均未标定。

令omega_j为税前企业有效劳动工资MU/(NU_eff·年)，tau_j为目的地劳动收入税楔，则：

\[
G_j=\omega_j L_j,\quad
Y^{net}_i=\sum_j F_{ji}\tilde h_{ji}\epsilon_{ji}\omega_j(1-\tau_j),\quad
Tax=\sum_j\tau_jG_j,\quad \sum_iY^{net}_i+Tax=\sum_jG_j.
\]

工资税仅在gross→net边扣一次。家户收入字段命名为labor_income_net；不得先传入已税后wjt又在HJB或AtTax再扣同一税楔。其他资本税、消费税、AtTax和财政净转移必须各有独立typed edge；本轮没有核准其源码字段含义，不把AtTax自动当作工资税。

统计c类平均工资需限定同一调查总体/年度平均人数：

\[
v^{stat}_{j,c}/1000=G^{covered}_{j,c}/E^{unit,avg}_{j,c}
=\omega_j\frac{\sum_iF^{covered}_{ji,c}\tilde h_{ji,c}\epsilon_{ji,c}}{\sum_iF^{covered}_{ji,c}}.
\]

最后一个等号还要求各covered劳动报酬确实按共同omega计价、无未建模加班溢价/奖金/单位支付差异。否则引入显式工资组成残差，不能反向拟合h、epsilon或HU让统计工资落进[0.8,1.3]。统计税前工资不是omega，也不是税后家庭工资。原ra[0.02,0.09]、wjt[0.8,1.3]仅作为历史标签，不在本轮重新解释为现实工资许可区间。

## A/B两种结构

|问题|A：保留居民家户尺度（建议先讨论）|B：家户仅代表就业者（仅研究）|
|---|---|---|
|家户主体|H_i居民；是否包含儿童/非就业者待定|E_i就业者；非就业者U_i必须单独建账|
|企业劳动|通过p、M、h、epsilon得到L|通过M、h、epsilon得到L；仅在E=pH同口径时与A相等|
|财富/消费|A_total=H×a_res×s_H，C同理|需要资产/消费在人群间的分配份额，不能简单把H换E|
|非就业收入|微观就业状态、共同家庭分享/转移制度须独立决定|非就业者消费、资产、转移、养老和儿童福利不能消失|
|财政转移|居民每人T转H×T×s_H|按就业者与非就业者分别分配，总财政金额必须守恒|
|K/L和产出|K/(M p H h epsilon)|仅在完全一致E映射下等于A；不是机械换人口|
|经济方程影响|新增参与/收入分布接口仍需Owner E3|代表主体及效用、资产、福利总体变动更大，不能视为纯单位纠正|

方案B的最低财富恒等式：给定居民总财富A与待定就业者资产份额eta_A，A_emp=eta_A A，A_nonemp=(1-eta_A)A；a_emp=A_emp/E，a_nonemp=A_nonemp/(H-E)。消费和福利需要各自独立份额，不能复用eta_A。实际人群资产分布和微观异质性没有被这条加总恒等式识别。

HJB未来面对的是条件于就业状态、生产率和迁移状态的微观净收入函数。p_i是加总参与率；不自动把p乘进每个HA个体工资，更不更改效用函数。可只把家户预期总收入写成上面的Ynet恒等式；其微观分布是E3未决。

## 首个未来可执行TEMP31接口草图

下一次获得Owner独立授权后，建议先只做一个不调用HA的typed adapter：

1. 接收带单位/期间/总体与O/I/S标签的H_resident_origin、E_employed_resident_origin、M_destination_origin、hours_ratio、efficiency、firm_wage_gross、labor_tax_destination。
2. 对UNKNOWN的p、h、epsilon及非可比总体返回NA/门失败，不猜补。
3. 输出head_flow_destination_origin、E_employed_workplace_destination、L_firm_eff_destination、labor_income_net_origin、labor_tax_total；单独保留原Lt_mat原件及其源码身份。
4. 先验检查列守恒、头数与效率劳动分账、gross=net+tax、覆盖总体资金桥、居民/就业者财富和转移总量。真实源迁移函数经逐字段核对前，不把这个M接入或替代Lt_mat。

本轮mapping_oracles.py只验证该建议代数，不是已获接受生产源码的实装。两套31省非对称fixture含完整有理数M、h、epsilon、人口与工资资金结果；349/349本机用例通过。真实HU始终保留符号，财富测试只比较s_H的系数。另给可手算两地区oracle：D=(45,55)、L=(45,110)、企业工资账420、税75、家庭净劳动收入345，其中来源净收入(120,225)。所有测试参数均为合成，不是省级S情景、不是宏观参数搜索。
