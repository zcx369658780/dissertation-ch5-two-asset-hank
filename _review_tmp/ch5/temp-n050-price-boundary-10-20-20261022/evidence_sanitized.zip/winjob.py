import ctypes,subprocess,time
from ctypes import wintypes as w
k=ctypes.WinDLL("kernel32",use_last_error=True);nt=ctypes.WinDLL("ntdll")
class IO(ctypes.Structure):_fields_=[(x,ctypes.c_ulonglong) for x in ["ReadOperationCount","WriteOperationCount","OtherOperationCount","ReadTransferCount","WriteTransferCount","OtherTransferCount"]]
class Basic(ctypes.Structure):_fields_=[("PerProcessUserTimeLimit",ctypes.c_longlong),("PerJobUserTimeLimit",ctypes.c_longlong),("LimitFlags",w.DWORD),("MinimumWorkingSetSize",ctypes.c_size_t),("MaximumWorkingSetSize",ctypes.c_size_t),("ActiveProcessLimit",w.DWORD),("Affinity",ctypes.c_size_t),("PriorityClass",w.DWORD),("SchedulingClass",w.DWORD)]
class Extended(ctypes.Structure):_fields_=[("BasicLimitInformation",Basic),("IoInfo",IO),("ProcessMemoryLimit",ctypes.c_size_t),("JobMemoryLimit",ctypes.c_size_t),("PeakProcessMemoryUsed",ctypes.c_size_t),("PeakJobMemoryUsed",ctypes.c_size_t)]
k.CreateJobObjectW.argtypes=[ctypes.c_void_p,w.LPCWSTR];k.CreateJobObjectW.restype=w.HANDLE
k.SetInformationJobObject.argtypes=[w.HANDLE,ctypes.c_int,ctypes.c_void_p,w.DWORD];k.SetInformationJobObject.restype=w.BOOL
k.AssignProcessToJobObject.argtypes=[w.HANDLE,w.HANDLE];k.AssignProcessToJobObject.restype=w.BOOL
k.TerminateJobObject.argtypes=[w.HANDLE,w.UINT];k.TerminateJobObject.restype=w.BOOL
k.CloseHandle.argtypes=[w.HANDLE];k.CloseHandle.restype=w.BOOL
nt.NtResumeProcess.argtypes=[w.HANDLE];nt.NtResumeProcess.restype=ctypes.c_long
class Job:
 def __init__(self):
  self.h=k.CreateJobObjectW(None,None)
  if not self.h:raise ctypes.WinError(ctypes.get_last_error())
  x=Extended();x.BasicLimitInformation.LimitFlags=0x2000|0x8;x.BasicLimitInformation.ActiveProcessLimit=1
  if not k.SetInformationJobObject(self.h,9,ctypes.byref(x),ctypes.sizeof(x)):raise ctypes.WinError(ctypes.get_last_error())
 def start(self,argv,**kw):
  p=subprocess.Popen(argv,creationflags=0x4,**kw)
  if not k.AssignProcessToJobObject(self.h,w.HANDLE(int(p._handle))):
   p.kill();p.wait();raise ctypes.WinError(ctypes.get_last_error())
  if nt.NtResumeProcess(w.HANDLE(int(p._handle)))!=0:p.kill();p.wait();raise RuntimeError("RESUME_FAILED")
  return p
 def terminate(self):
  if not k.TerminateJobObject(self.h,125):raise ctypes.WinError(ctypes.get_last_error())
 def close(self):
  if self.h:k.CloseHandle(self.h);self.h=None
