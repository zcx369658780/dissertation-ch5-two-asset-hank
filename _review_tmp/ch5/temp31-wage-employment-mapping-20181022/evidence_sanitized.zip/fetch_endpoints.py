import sys,pathlib,json,datetime,hashlib,base64,os,re
from urllib.request import Request,build_opener,HTTPRedirectHandler
from urllib.error import HTTPError
from lxml import html
R=pathlib.Path(__file__).parent;sys.stdout.reconfigure(encoding='utf-8')
class NoRedirect(HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
opener=build_opener(NoRedirect)
spec=[('FJ_PRIVATE_2019','https://tjj.fujian.gov.cn/xxgk/tjxx/gzqk/202005/t20200525_5273123.htm'),('JS_WAGES_2019','https://tj.jiangsu.gov.cn/art/2020/6/15/art_85275_10487706.html')]
for sid,url in spec:
 intent=dict(event_id='NEW-HTTP-'+sid,request_kind='official_http',request=url,source_id=sid,requested_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 with (R/(sid+'_intent.json')).open('x',encoding='utf-8') as f:json.dump(intent,f,ensure_ascii=False);f.flush();os.fsync(f.fileno())
 out=dict(intent,provider_http=None,transport_error=None,original_bytes_complete=False)
 try:
  try:q=opener.open(Request(url),timeout=18)
  except HTTPError as e:q=e
  with q:b=q.read(2000001);out['provider_http']=q.code
  out.update(length=len(b),sha256=hashlib.sha256(b).hexdigest(),content_base64=base64.b64encode(b).decode(),original_bytes_complete=len(b)<=2000000)
  if q.code==200 and len(b)<=2000000:
   try:t=b.decode('utf-8-sig')
   except UnicodeDecodeError:t=b.decode('gb18030')
   root=html.fromstring(t);[x.drop_tree() for x in root.xpath('//script|//style')];out['text']=re.sub(r'\s+',' ',root.text_content())
 except Exception as e:out['transport_error']=type(e).__name__+':'+str(e)
 out['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (R/(sid+'_outcome.json')).open('x',encoding='utf-8') as f:json.dump(out,f,ensure_ascii=False);f.flush();os.fsync(f.fileno())
 print(json.dumps({k:v for k,v in out.items() if k not in ('content_base64','text')},ensure_ascii=False))
 if 'text' in out:print(json.dumps(dict(source_id=sid,contexts=[out['text'][max(0,m.start()-80):m.end()+350] for m in list(re.finditer('57141|58322|统计范围|调查方法|税前|平均人数',out['text']))[:9]]),ensure_ascii=False))
