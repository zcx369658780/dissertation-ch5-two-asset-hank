import os,sys,time,json,pathlib
from core import ROOT,put,append,snapshot_check
from winjob import Job
bootstrap=json.loads((ROOT/"bootstrap.json").read_text("utf-8"))
snapshot_check()
assert json.loads((ROOT/"runner_qualification.json").read_text("utf-8"))["science_HA"]==0
put("science_driver_armed.json",{"run_id":bootstrap["run_id"],"driver_charged":1,"authorized_arm":"N050","max_HA":40,"max_outer":20,"unix":time.time()})
env=dict(os.environ);env["PYTHONDONTWRITEBYTECODE"]="1";env["PYTHONHASHSEED"]="0"
start=time.monotonic();job=Job();terminal=None;p=None
with open(ROOT/"science_stdout.log","xb") as stdout,open(ROOT/"science_stderr.log","xb") as stderr:
 try:
  p=job.start([sys.executable,"-B","-u",str(ROOT/"science_driver.py")],stdout=stdout,stderr=stderr,cwd=str(ROOT),env=env)
  put("science_process_identity.json",{"pid":p.pid,"suspended_assignment":True,"job_active_process_limit":1,"job_kill_on_close":True,"science_driver_starts":1})
  last=0
  while p.poll() is None:
   elapsed=time.monotonic()-start
   if elapsed>=14220 or (ROOT/"STOP_REQUEST.json").exists():
    terminal="SCIENCE_WALL_LIMIT" if elapsed>=14220 else "OWNER_LOCAL_STOP"
    job.terminate();p.wait(timeout=10);break
   if elapsed-last>=30:
    print(json.dumps({"guardian_alive":True,"science_pid":p.pid,"science_elapsed_seconds":round(elapsed,1),"stdout_bytes":(ROOT/"science_stdout.log").stat().st_size}),flush=True);last=elapsed
   time.sleep(1)
  rc=p.wait(timeout=10)
 finally:job.close()
snapshot_check()
put("SCIENCE_PROCESS_COMPLETION_EVENT.json",{"run_id":bootstrap["run_id"],"event":"OWNED_SCIENCE_PROCESS_EXIT_OBSERVED","pid":p.pid if p else None,"exit_code":rc,"observed_after_process_exit":True,"guardian_stop_reason":terminal,"science_seconds":time.monotonic()-start,"production_GLOBAL_STOP":"UNVERIFIED","OS_descendants_outside_owned_job":"UNKNOWN"})
print(json.dumps({"child_exited":True,"exit_code":rc,"guardian_stop_reason":terminal,"science_seconds":time.monotonic()-start}),flush=True)
