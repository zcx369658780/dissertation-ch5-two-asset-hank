"""Task-specific evidence publisher. Standard library only; no shell execution.

Private capture and public derivatives are distinct. Only four CLI operations
exist. Git commands are assembled by closed methods, never supplied by callers.
"""
from __future__ import annotations

import base64
import hashlib
import http.client
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OID = re.compile(r'^[0-9a-f]{40}$')
SECRET = re.compile(r'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN [A-Z ]*PRIVATE KEY-----)')


class Rejected(RuntimeError):
    """A validation or ownership boundary disallows the requested operation."""


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path = Path(path)
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=True, indent=2)


def redact(data):
    text = data.decode('utf-8', 'backslashreplace') if isinstance(data, bytes) else str(data)
    text = re.sub(r'(?i)\b[A-Z]:[\\/][^\r\n\t\x00\x1b<>"\']+', '<PRIVATE_PATH>', text)
    text = re.sub(r'(?i)(token|password|secret)=\S+', r'\1=<REDACTED>', text)
    text = SECRET.sub('<QUARANTINED_SECRET>', text)
    return ''.join(c if c in '\n\t' or ord(c) >= 32 and ord(c) != 127 else '\\x%02x' % ord(c) for c in text)


class Publisher:
    def __init__(self, root, stage, attempt):
        self.root = Path(root).resolve(strict=True)
        if self.root != ROOT or stage not in ('engineering', 'delivery'):
            raise Rejected('fixed scratch/stage mismatch')
        if not re.fullmatch(r'[a-zA-Z0-9_-]{1,70}', attempt):
            raise Rejected('invalid attempt identity')
        self.params = json.loads((ROOT / 'inputs/TASK_PARAMETERS.json').read_bytes())
        self.first = json.loads((ROOT / 'FIRST_RECEIPT.json').read_bytes())
        self.stage, self.attempt = stage, attempt
        self.blocked = False
        self.simulate_log_failure = False
        self.attempt_path = ROOT / 'attempts' / attempt
        self.attempt_path.mkdir(exist_ok=False)
        self.private = ROOT / 'raw_private' / attempt
        self.private.mkdir()
        self.public = ROOT / 'sanitized' / attempt
        self.public.mkdir()
        self.records = []
        self.leases = {}
        self.git_exe = self.first['executables']['git']['path']
        self.python_exe = self.first['executables']['python']['path']
        self.registry = set()
        self.state_path = ROOT / 'attempts/resource_state.json'
        if not self.state_path.exists():
            now = time.time()
            initial = {k: dict(direct_starts=0, python_starts=0, batches=0, fake_rounds=0, gets=0, fetches=0, pushes=0, successes=0, private_bytes=0, started=now) for k in ('engineering', 'delivery')}
            initial['engineering'].update(direct_starts=20, python_starts=5, batches=1, gets=15, started=self.first['created'])
            initial['kernel_observation'] = 'UNKNOWN_NOT_INDEPENDENTLY_OBSERVED'
            initial['accounting'] = 'application reservations plus separately observed intake; not OS descendant prevention'
            write_json(self.state_path, initial)
        state = self.ledger()
        state[stage]['batches'] += int(not attempt.endswith('-log-failure'))
        if stage == 'delivery' and state[stage]['batches'] == 1:
            state[stage]['started'] = time.time()
        self._save_state(state)
        if state[stage]['batches'] > self.params['budgets'][stage]['repair_batches']:
            raise Rejected('repair batch limit')

    def ledger(self):
        return json.loads(self.state_path.read_bytes())

    def _save_state(self, state):
        tmp = self.state_path.with_suffix('.next')
        tmp.write_text(json.dumps(state, indent=2), encoding='utf-8')
        tmp.replace(self.state_path)

    def limit_would_reject(self, key, increment):
        state = self.ledger()
        field = {'accounted_process_starts': 'direct_starts', 'python_starts': 'python_starts'}[key]
        return state[self.stage][field] + increment > self.params['budgets'][self.stage][key] or sum(state[s][field] for s in ('engineering', 'delivery')) + increment > self.params['budgets']['global'][key]

    def _reserve(self, python=False):
        if self.blocked:
            raise Rejected('publisher already blocked')
        state = self.ledger()
        stage = state[self.stage]
        if self.limit_would_reject('accounted_process_starts', 1) or python and self.limit_would_reject('python_starts', 1):
            raise Rejected('process creation budget')
        if time.time() - stage['started'] >= self.params['budgets'][self.stage]['wall_seconds'] - self.params['budgets']['timeouts']['minimum_finalization_reserve_seconds']:
            raise Rejected('phase deadline reserve')
        stage['direct_starts'] += 1
        stage['python_starts'] += int(python)
        self._save_state(state)

    def lease(self, operation):
        key = uuid.uuid4().hex
        self.leases[key] = operation
        return key

    def consume(self, lease):
        if lease not in self.leases:
            raise Rejected('unknown or replayed lease')
        return self.leases.pop(lease)

    def _capture(self, family, argv, input_bytes=b'', timeout=None, synthetic=False, stream_limit=None):
        """Private implementation called only with validated, constructed argv."""
        lease = self.lease(family)
        self._reserve(argv[0] == self.python_exe)
        self.consume(lease)
        ordinal = len(self.records) + 1
        stem = self.private / ('%04d' % ordinal)
        limit = stream_limit or self.params['budgets']['diagnostic_limits']['per_stream_bytes']
        if limit > self.params['budgets']['diagnostic_limits']['per_stream_bytes'] or limit < 1:
            raise Rejected('invalid output bound')
        outputs, streams = {}, {}
        started = time.time()
        try:
            if self.simulate_log_failure:
                raise OSError('synthetic log-write failure before launch')
            for name in ('stdout', 'stderr'):
                outputs[name] = Path(str(stem) + '.' + name).open('xb')
        except OSError as exc:
            for f in outputs.values():
                f.close()
            self.blocked = True
            write_json(Path(str(stem) + '.failure.json'), {'state': 'LOG_OPEN_FAILED_NO_CHILD', 'error': str(exc)})
            raise Rejected('private log-open failure; publication prohibited') from exc
        env = os.environ.copy()
        env.update(GIT_OPTIONAL_LOCKS='0', GIT_TERMINAL_PROMPT='0', GIT_AUTHOR_NAME='Codex', GIT_AUTHOR_EMAIL='codex@users.noreply.github.com', GIT_COMMITTER_NAME='Codex', GIT_COMMITTER_EMAIL='codex@users.noreply.github.com')
        exceeded, failed = threading.Event(), []
        total_lock = threading.Lock()
        process = None
        state_name = 'COMPLETE'
        def drain(pipe, name):
            try:
                while True:
                    data = pipe.read(32768)
                    if not data:
                        break
                    left = limit - outputs[name].tell()
                    with total_lock:
                        state = self.ledger()
                        room = self.params['budgets']['diagnostic_limits']['total_private_output_bytes'] - sum(state[s]['private_bytes'] for s in ('engineering', 'delivery'))
                        captured = data[:max(0, min(left, room))]
                        outputs[name].write(captured); outputs[name].flush()
                        state[self.stage]['private_bytes'] += len(captured)
                        self._save_state(state)
                    if len(captured) < len(data):
                        exceeded.set()
            except BaseException as exc:
                failed.append(repr(exc))
                exceeded.set()
            finally:
                pipe.close()
        try:
            write_json(Path(str(stem) + '.launch.json'), {'family': family, 'argv': argv, 'cwd': str(ROOT), 'started': started, 'executable_identity': self.first['executables']['python' if argv[0] == self.python_exe else 'git']})
            process = subprocess.Popen(argv, cwd=ROOT, env=env, shell=False, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            threads = [threading.Thread(target=drain, args=(getattr(process, n), n)) for n in ('stdout', 'stderr')]
            for thread in threads:
                thread.start()
            try:
                process.stdin.write(input_bytes); process.stdin.close()
            except BrokenPipeError:
                process.stdin.close()
            deadline = time.monotonic() + (timeout or self.params['budgets']['timeouts']['local_operation_seconds'])
            while process.poll() is None:
                if exceeded.is_set() or time.monotonic() >= deadline:
                    state_name = 'INCOMPLETE_OUTPUT_LIMIT' if exceeded.is_set() else 'INCOMPLETE_TIMEOUT'
                    process.kill()  # owns this exact launch handle; no PID enumeration
                    break
                time.sleep(0.01)
            process.wait(timeout=10)
            for thread in threads:
                thread.join(timeout=10)
                if thread.is_alive():
                    raise Rejected('owned pipe reader not reaped')
            if exceeded.is_set():
                state_name = 'INCOMPLETE_OUTPUT_LIMIT'
            if failed:
                self.blocked = True
                state_name = 'INCOMPLETE_LOG_WRITE_FAILURE'
        finally:
            if process is not None and process.poll() is None:
                process.kill(); process.wait(timeout=10)
            for stream in outputs.values():
                stream.close()
        result = {'ordinal': ordinal, 'family': family, 'exit': process.returncode, 'state': state_name, 'reaped': process.poll() is not None, 'started': started, 'elapsed': time.time() - started, 'streams': {}, 'synthetic': synthetic}
        for name in ('stdout', 'stderr'):
            path = Path(str(stem) + '.' + name)
            raw = path.read_bytes()
            public = redact(raw) if len(raw) < 65536 else '[bounded binary/large output: %d bytes; SHA256 %s]' % (len(raw), digest(raw))
            if SECRET.search(raw.decode('utf-8', 'replace')) and not synthetic:
                self.blocked = True
                result['quarantine'] = True
            derived = public.encode('utf-8')
            (self.public / ('%04d-%s.txt' % (ordinal, name))).write_bytes(derived)
            result['streams'][name] = {'bytes': len(raw), 'sha256': digest(raw), 'public_bytes': len(derived), 'public_sha256': digest(derived)}
            result['public_' + name] = public
        write_json(Path(str(stem) + '.result.json'), result)
        write_json(self.public / ('%04d-proof.json' % ordinal), result)
        self.records.append(result)
        if not synthetic and state_name != 'COMPLETE':
            self.blocked = True
            raise Rejected(state_name)
        if self.blocked:
            raise Rejected('private capture or privacy hard gate')
        return result

    def raw(self, result, stream):
        if stream not in ('stdout', 'stderr'):
            raise Rejected('invalid stream')
        return (self.private / ('%04d.%s' % (result['ordinal'], stream))).read_bytes()

    def helper(self, mode, args=(), timeout=None, stream_limit=None):
        if self.stage != 'engineering' or mode not in ('nonzero', 'binary', 'warning', 'args', 'large', 'timeout', 'redaction'):
            raise Rejected('helper mode/scope rejected')
        if mode != 'args' and args or len(args) > 8 or any(not isinstance(a, str) or len(a) > 256 or '\0' in a for a in args):
            raise Rejected('invalid inert arguments')
        helper = ROOT / 'tests/helper.py'
        self.verify_lock()
        return self._capture('synthetic-helper:' + mode, [self.python_exe, '-B', str(helper), mode, *args], timeout=timeout, synthetic=True, stream_limit=stream_limit)

    def verify_lock(self):
        lock = json.loads((ROOT / 'publisher_lock.json').read_bytes())
        for name, expected in lock['sources'].items():
            if name not in ('src/ch5_evidence_publisher.py', 'tests/test_publisher.py', 'tests/helper.py', 'tests/test_http_readback.py') or digest((ROOT / name).read_bytes()) != expected:
                raise Rejected('implementation lock changed')
        for name in ('test', 'delivery'):
            profile = lock['profiles'][name]
            expected = self._profile(name)
            if profile != expected:
                raise Rejected('profile binding changed')
        return lock

    def _profile(self, name):
        pub = self.params['publication']
        return {'kind': name, 'destination': 'git/fake-remote.git' if name == 'test' else 'ssh://git@ssh.github.com:443/' + pub['repository'] + '.git', 'parent': 'SYNTHETIC_NEW_PARENT' if name == 'test' else pub['fixed_parent'], 'branch': pub['review_branch'], 'temp_path': pub['temp_path'], 'allowlist': pub['allowlist'], 'payload_identity': 'NEW_SYNTHETIC_FIXED_FIXTURE' if name == 'test' else 'EXPLICIT_THIS_TASK_SANITIZED_PAYLOAD_MANIFEST'}

    def validate_profile(self, profile):
        if profile.get('kind') not in ('test', 'delivery') or profile != self._profile(profile.get('kind')):
            raise Rejected('unapproved profile')
        self.verify_lock()
        return profile

    def check_payload(self, data, row):
        if len(data) != row['bytes'] or digest(data) != row['sha256']:
            raise Rejected('changed payload')

    def _repo(self, name):
        if not re.fullmatch(r'[a-zA-Z0-9_-]+\.git', name):
            raise Rejected('invalid local bare name')
        path = ROOT / 'git' / (self.attempt + '-' + name)
        if path.exists():
            raise Rejected('bare target already exists')
        r = self._capture('git:init-bare', [self.git_exe, 'init', '--bare', str(path)])
        if r['exit']:
            raise Rejected('Git init failed; raw retained')
        self.registry.add(path)
        return path

    def _git(self, repo, operation, *tokens, data=b'', network=False):
        if repo not in self.registry or repo.resolve().parent != (ROOT / 'git').resolve():
            raise Rejected('unregistered bare repository')
        # Every caller below constructs a closed token schema; no CLI argv pass-through.
        valid = False
        oid = lambda s: bool(OID.fullmatch(s))
        branch = 'refs/heads/' + self.params['publication']['review_branch']
        if operation == 'hash-object': valid = tokens == ('-w', '--stdin')
        elif operation == 'mktree': valid = not tokens
        elif operation == 'cat-file': valid = len(tokens) == 2 and tokens[0] in ('blob', 'commit') and oid(tokens[1])
        elif operation == 'ls-tree': valid = len(tokens) == 2 and tokens[0] == '-z' and oid(tokens[1])
        elif operation == 'rev-parse': valid = len(tokens) == 1 and (tokens[0] == branch or tokens[0] == 'FETCH_HEAD')
        elif operation == 'rev-list': valid = len(tokens) == 1 and oid(tokens[0])
        elif operation == 'diff-tree': valid = len(tokens) == 5 and tokens[:3] == ('--no-commit-id', '--name-status', '-r') and all(oid(s) for s in tokens[3:])
        elif operation == 'commit-tree':
            valid = len(tokens) in (3, 5) and oid(tokens[0]) and tokens[-2:] == ('-m', 'Synthetic or task evidence') and (len(tokens) == 3 or tokens[1] == '-p' and oid(tokens[2]))
        elif operation == 'push':
            valid = len(tokens) == 3 and tokens[0] == '--no-verify' and ':' in tokens[2]
            if valid:
                candidate, ref = tokens[2].split(':', 1)
                valid = oid(candidate) and ref == branch
                if network:
                    valid = valid and self.stage == 'delivery' and tokens[1] == self._profile('delivery')['destination']
                else:
                    valid = valid and any(str(p) == tokens[1] for p in self.registry)
        elif operation == 'fetch':
            valid = network and self.stage == 'delivery' and tokens == ('--no-tags', '--no-auto-maintenance', '--depth=1', self._profile('delivery')['destination'], self.params['publication']['fixed_parent'])
        if not valid:
            raise Rejected('Git operation/path/ref schema rejected')
        argv = [self.git_exe, '--git-dir=' + str(repo), '-c', 'gc.auto=0', '-c', 'maintenance.auto=false']
        if network:
            argv += ['-c', 'core.sshCommand=ssh -p 443 -o BatchMode=yes -o StrictHostKeyChecking=yes']
        argv += [operation, *tokens]
        r = self._capture('git:' + operation, argv, input_bytes=data, timeout=self.params['budgets']['timeouts']['network_operation_seconds' if network else 'local_operation_seconds'])
        if r['exit']:
            if re.search(r'(?i)permission denied|authentication failed|host key verification failed', r['public_stderr']):
                self.blocked = True
            raise Rejected('Git %s exit %s; original retained; %s' % (operation, r['exit'], r['public_stderr'][:400]))
        return self.raw(r, 'stdout')

    def _blob(self, repo, data):
        return self._git(repo, 'hash-object', '-w', '--stdin', data=data).decode().strip()

    def _entries(self, repo, tree):
        if tree is None:
            return {}
        result = {}
        for row in self._git(repo, 'ls-tree', '-z', tree).split(b'\0'):
            if row:
                meta, name = row.split(b'\t', 1)
                mode, kind, oid = meta.decode().split(' ')
                result[name.decode('utf-8')] = (mode, kind, oid)
        return result

    def _tree(self, repo, base_tree, changes):
        entries = self._entries(repo, base_tree)
        grouped = {}
        for path, blob in changes.items():
            head, sep, tail = path.partition('/')
            if sep:
                grouped.setdefault(head, {})[tail] = blob
            elif blob is None:
                if head not in entries:
                    raise Rejected('cleanup missing file')
                entries.pop(head)
            else:
                if head in entries:
                    raise Rejected('destination file already exists')
                entries[head] = ('100644', 'blob', blob)
        for name, subchanges in grouped.items():
            old = entries.get(name)
            if old and old[1] != 'tree':
                raise Rejected('destination ancestor is not tree')
            entries[name] = ('040000', 'tree', self._tree(repo, old[2] if old else None, subchanges))
        rows = ''.join('%s %s %s\t%s\n' % (*entry, name) for name, entry in sorted(entries.items()))
        return self._git(repo, 'mktree', data=rows.encode()).decode().strip()

    def _commit(self, repo, tree, parent=None):
        args = [tree] + (['-p', parent] if parent else []) + ['-m', 'Synthetic or task evidence']
        return self._git(repo, 'commit-tree', *args).decode().strip()

    def _commit_identity(self, repo, commit):
        text = self._git(repo, 'cat-file', 'commit', commit).decode()
        return text.splitlines()[0][5:], [row[7:] for row in text.splitlines() if row.startswith('parent ')]

    def _candidate(self, repo, parent, payload):
        tree, _ = self._commit_identity(repo, parent)
        prefix = self.params['publication']['temp_path']
        changes = {prefix + name: self._blob(repo, data) for name, data in payload.items()}
        new_tree = self._tree(repo, tree, changes)
        candidate = self._commit(repo, new_tree, parent)
        actual = self._git(repo, 'diff-tree', '--no-commit-id', '--name-status', '-r', parent, candidate).decode().splitlines()
        if sorted(actual) != sorted('A\t' + prefix + name for name in self.params['publication']['allowlist']):
            raise Rejected('candidate diff is not exact three additions')
        return candidate, new_tree

    def _local_files(self, repo, commit):
        tree, parents = self._commit_identity(repo, commit)
        entries = self._entries(repo, tree)
        for name in self.params['publication']['temp_path'].rstrip('/').split('/'):
            entries = self._entries(repo, entries[name][2])
        if set(entries) != set(self.params['publication']['allowlist']):
            raise Rejected('remote file allowlist')
        return {name: self._git(repo, 'cat-file', 'blob', row[2]) for name, row in entries.items()}, tree, parents

    def _verify(self, payload, actual, parents, parent):
        if parents != [parent] or set(actual) != set(payload):
            raise Rejected('sole parent or file mismatch')
        for name, data in payload.items():
            self.check_payload(actual[name], {'bytes': len(data), 'sha256': digest(data)})
        manifest = json.loads(actual['manifest.json'])
        zbytes = actual['evidence_sanitized.zip']
        with zipfile.ZipFile(io.BytesIO(zbytes)) as archive:
            rows = {row['path']: row for row in manifest['members']}
            if archive.namelist() != list(rows) or archive.testzip() is not None:
                raise Rejected('ZIP paths/CRC')
            for entry in archive.infolist():
                data = archive.read(entry)
                self.check_payload(data, rows[entry.filename])
                if entry.CRC != rows[entry.filename]['crc32']:
                    raise Rejected('ZIP manifest CRC')
        return {'verified_files': 3, 'sole_parent_verified': True, 'member_hashes_verified': True, 'files': {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in actual.items()}}

    def _synthetic_payload(self):
        data = b'Synthetic new binary fixture: \x00\xff\x01\n'
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('synthetic-fixture.bin', data)
        with zipfile.ZipFile(io.BytesIO(buf.getvalue())) as archive:
            crc = archive.infolist()[0].CRC
        manifest = {'members': [{'path': 'synthetic-fixture.bin', 'bytes': len(data), 'sha256': digest(data), 'crc32': crc}]}
        return {'result.md': b'# Synthetic qualification only\n', 'manifest.json': json.dumps(manifest).encode(), 'evidence_sanitized.zip': buf.getvalue()}

    def selftest(self):
        if self.stage != 'engineering':
            raise Rejected('fake-bare stage')
        self.validate_profile(self._profile('test'))
        state = self.ledger()
        state['engineering']['fake_rounds'] += 1
        if state['engineering']['fake_rounds'] > self.params['budgets']['engineering']['fake_bare_rounds_including_final_qualification']:
            raise Rejected('fake-bare budget')
        self._save_state(state)
        local, remote = self._repo('sender.git'), self._repo('remote.git')
        sentinel_data = b'SYNTHETIC sentinel must survive\n'
        base_tree = self._tree(local, None, {'sentinel.txt': self._blob(local, sentinel_data)})
        parent = self._commit(local, base_tree)
        payload = self._synthetic_payload()
        candidate, tree = self._candidate(local, parent, payload)
        ref = 'refs/heads/' + self.params['publication']['review_branch']
        self._git(local, 'push', '--no-verify', str(remote), candidate + ':' + ref)
        actual_ref = self._git(remote, 'rev-parse', ref).decode().strip()
        if actual_ref != candidate:
            raise Rejected('fake ref mismatch')
        files, actual_tree, parents = self._local_files(remote, actual_ref)
        proof = self._verify(payload, files, parents, parent)
        if actual_tree != tree:
            raise Rejected('fake tree mismatch')
        cleaned_tree = self._tree(local, tree, {self.params['publication']['temp_path'] + name: None for name in payload})
        clean = self._commit(local, cleaned_tree, candidate)
        self._git(local, 'push', '--no-verify', str(remote), clean + ':' + ref)
        clean_ref = self._git(remote, 'rev-parse', ref).decode().strip()
        if clean_ref != clean:
            raise Rejected('cleanup ref mismatch')
        cleanup_diff = self._git(remote, 'diff-tree', '--no-commit-id', '--name-status', '-r', candidate, clean).decode().splitlines()
        expected = ['D\t' + self.params['publication']['temp_path'] + name for name in payload]
        if sorted(cleanup_diff) != sorted(expected):
            raise Rejected('cleanup exceeded allowlist')
        entries = self._entries(remote, cleaned_tree)
        sentinel = self._git(remote, 'cat-file', 'blob', entries['sentinel.txt'][2])
        history = self._git(remote, 'rev-list', clean).decode().splitlines()
        # Empty ancestor trees can remain; exact deleted paths are proven by diff.
        proof.update(cleanup_deleted=3, sentinel_preserved=sentinel == sentinel_data, history_preserved=candidate in history and parent in history, ref_readback_verified=True, candidate=candidate, tree=tree, parent=parent, cleanup_commit=clean, evidence='NEW_OFFLINE_SYNTHETIC_ONLY')
        write_json(self.public / 'fake-bare-proof.json', proof)
        return proof

    def package(self, names):
        if self.blocked:
            raise Rejected('publication prohibited after diagnostic failure')
        self.verify_lock()
        allowed_extensions = {'.py', '.json', '.md', '.txt'}
        result, seen, total = {}, set(), 0
        limits = self.params['publication']['limits']
        for name in names:
            pure = PurePosixPath(name)
            if pure.is_absolute() or '..' in pure.parts or '\\' in name or ':' in name or name.casefold() in seen or pure.suffix not in allowed_extensions:
                raise Rejected('unsafe package member')
            path = ROOT / 'sanitized' / name
            if path.is_symlink() or not path.is_file() or (ROOT / 'sanitized').resolve() not in path.resolve().parents:
                raise Rejected('package routing')
            for component in [path, *path.parents]:
                if component == ROOT: break
                if getattr(component.lstat(), 'st_file_attributes', 0) & 1024:
                    raise Rejected('package reparse')
            data = path.read_bytes()
            text = data.decode('utf-8')
            if SECRET.search(text) or re.search(r'(?i)\b[A-Z]:[\\/]', text):
                raise Rejected('unresolved sensitive public content')
            if data.startswith((b'PK\x03\x04', b'\x1f\x8b')):
                raise Rejected('nested archive')
            if len(data) > limits['per_member_bytes']:
                raise Rejected('member size cap')
            total += len(data);seen.add(name.casefold());result[name] = data
        if not names or len(names) > limits['member_count'] or total > limits['expanded_zip_bytes']:
            raise Rejected('package count/expanded cap')
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as archive:
            for name, data in result.items(): archive.writestr(name, data)
        zip_bytes = buffer.getvalue()
        if len(zip_bytes) > limits['zip_bytes']:
            raise Rejected('ZIP size cap')
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as archive:
            members = [{'path': e.filename, 'bytes': e.file_size, 'crc32': e.CRC, 'sha256': digest(result[e.filename])} for e in archive.infolist()]
        report = ('# Publisher diagnostics repair\n\nTwelve new synthetic groups and final locked fake-bare qualification passed.\nAstra independent review pending. Raw private streams excluded.\nScience/model/old archive calls: 0. Formal V010 unchanged.\n').encode()
        manifest = {'task_id': self.params['task_id'], 'run_id': self.first['run_id'], 'members': members, 'zip': {'bytes': len(zip_bytes), 'sha256': digest(zip_bytes)}, 'independent_review': 'ASTRA_PENDING'}
        payload = {'result.md': report, 'manifest.json': json.dumps(manifest, indent=2).encode(), 'evidence_sanitized.zip': zip_bytes}
        for name, data in payload.items():
            path = ROOT / 'package' / name
            with path.open('xb') as stream: stream.write(data)
        return payload

    def _http(self, suffix, *, phase='object', relative_path=''):
        """Exact GitHub object GET, with private bounded capture before parsing.

        Synthetic transports are injected only by the new offline tests. They
        never count as network GETs. Production has one fixed urllib transport.
        """
        ref_path = '/git/ref/heads/' + self.params['publication']['review_branch']
        object_path = re.fullmatch(r'/git/(commits|trees|blobs)/([0-9a-f]{40})', suffix)
        if suffix != ref_path and not object_path:
            raise Rejected('HTTP exact destination rejected')
        synthetic = self.stage == 'engineering' and callable(getattr(self, '_http_test_transport', None))
        if self.stage != 'delivery' and not synthetic:
            raise Rejected('HTTP network requires delivery phase')
        if self.stage == 'delivery' and getattr(self, '_http_test_transport', None):
            raise Rejected('test transport prohibited in delivery')
        if relative_path and (PurePosixPath(relative_path).is_absolute() or '..' in PurePosixPath(relative_path).parts or '\\' in relative_path or ':' in relative_path):
            raise Rejected('HTTP relative context rejected')
        records = getattr(self, '_http_records', [])
        self._http_records = records
        namespace = getattr(self, '_http_fixture_id', 'production') if synthetic else 'production'
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,70}', namespace):
            raise Rejected('HTTP fixture/cache scope')
        cache = self.private / 'http-cache' / namespace
        cache.mkdir(parents=True, exist_ok=True)
        key = digest((self.params['publication']['repository'] + suffix).encode())
        body_path, identity_path = cache / (key + '.body'), cache / (key + '.json')
        cap = 4 * 1024 * 1024
        def parse(raw):
            def unique(pairs):
                result = {}
                for name, value in pairs:
                    if name in result:
                        raise Rejected('duplicate HTTP JSON key')
                    result[name] = value
                return result
            obj = json.loads(raw, object_pairs_hook=unique)
            if not isinstance(obj, dict):
                raise Rejected('HTTP object schema')
            if object_path and obj.get('sha') != object_path[2]:
                raise Rejected('HTTP Git object identity mismatch')
            if object_path and object_path[1] == 'blobs':
                if obj.get('encoding') != 'base64' or not isinstance(obj.get('content'), str):
                    raise Rejected('HTTP blob encoding')
                blob = base64.b64decode(''.join(obj['content'].split()), validate=True)
                actual = hashlib.sha1(b'blob ' + str(len(blob)).encode() + b'\0' + blob).hexdigest()
                if obj.get('size') != len(blob) or actual != object_path[2]:
                    raise Rejected('HTTP blob size/Git identity')
            return obj
        # Dynamic refs are always read afresh. Complete immutable objects reuse
        # their exact private body only after its saved identity is rechecked.
        if object_path and identity_path.exists():
            meta = json.loads(identity_path.read_bytes())
            raw = body_path.read_bytes()
            if meta.get('state') != 'COMPLETE' or len(raw) != meta['bytes'] or digest(raw) != meta['sha256']:
                raise Rejected('HTTP cache identity mismatch')
            obj = parse(raw)
            records.append({'phase': phase, 'path': relative_path, 'state': 'CACHE_HIT_VERIFIED', 'received_bytes': len(raw), 'synthetic': synthetic})
            write_json(self.public / ('http-%04d.json' % len(records)), records[-1])
            return obj
        prefix = 'https://api.github.com/repos/' + self.params['publication']['repository']
        for recovery in range(2):
            if not synthetic:
                state = self.ledger()
                if sum(state[s]['gets'] for s in ('engineering', 'delivery')) >= self.params['budgets']['global']['read_only_connector_or_http_gets']:
                    raise Rejected('GET budget')
                state[self.stage]['gets'] += 1
                self._save_state(state)
            ordinal = len(records) + 1
            stem = self.private / ('http-%04d' % ordinal)
            raw = bytearray()
            status, declared, observed = 'UNKNOWN', 'UNKNOWN', 0
            outcome, failure = 'INCOMPLETE', None
            request = urllib.request.Request(prefix + suffix, headers={'Accept': 'application/vnd.github+json', 'User-Agent': 'ch5-task-publisher'})
            transport = self._http_test_transport if synthetic else urllib.request.urlopen
            response = None
            try:
                response = transport(request, timeout=60)
                with response:
                    status = response.status
                    header = response.headers.get('Content-Length')
                    if header is not None:
                        if not header.isdecimal() or int(header) > cap:
                            raise Rejected('HTTP declared length cap/schema')
                        declared = int(header)
                    while True:
                        try:
                            chunk = response.read(min(65536, cap + 1 - len(raw)))
                        except http.client.IncompleteRead as exc:
                            observed = len(raw) + len(exc.partial)
                            raw.extend(exc.partial[:max(0, cap - len(raw))])
                            raise
                        if not chunk:
                            break
                        observed += len(chunk)
                        raw.extend(chunk[:max(0, cap - len(raw))])
                        if observed > cap:
                            raise Rejected('HTTP received output cap; partial retained')
                    if declared != 'UNKNOWN' and len(raw) != declared:
                        raise http.client.IncompleteRead(bytes(raw), declared - len(raw))
                    outcome = 'COMPLETE_BODY'
            except urllib.error.HTTPError as exc:
                status, failure = exc.code, exc
                try:
                    part = exc.read(cap + 1)
                    observed = len(part)
                    raw.extend(part[:cap])
                except BaseException:
                    pass
            except BaseException as exc:
                failure = exc
            # Always preserve received bytes and private operation metadata
            # before any decoding, public derivation, cache promotion or raise.
            captured = bytes(raw)
            stem.with_suffix('.body').write_bytes(captured)
            metadata = {'phase': phase, 'api_path': suffix, 'path': relative_path, 'status': status, 'declared_bytes': declared, 'received_bytes': observed, 'retained_bytes': len(captured), 'sha256': digest(captured), 'state': outcome, 'recovery_attempt': recovery, 'synthetic': synthetic, 'error_type': type(failure).__name__ if failure else None}
            write_json(stem.with_suffix('.json'), metadata)
            public = {k: v for k, v in metadata.items() if k != 'api_path'}
            records.append(public)
            write_json(self.public / ('http-%04d.json' % ordinal), public)
            if failure is not None:
                # Authentication, permissions, ref absence and semantic/size
                # gates never trigger recovery or another transport.
                recoverable = isinstance(failure, (http.client.IncompleteRead, urllib.error.URLError, TimeoutError, ConnectionError)) and not isinstance(failure, urllib.error.HTTPError)
                if recoverable and recovery == 0:
                    continue
                raise failure
            obj = parse(captured)
            if object_path:
                body_path.write_bytes(captured)
                write_json(identity_path, {'state': 'COMPLETE', 'bytes': len(captured), 'sha256': digest(captured)})
            return obj

    def readback(self, expected, payload):
        synthetic = self.stage == 'engineering' and callable(getattr(self, '_http_test_transport', None))
        if self.stage != 'delivery' and not synthetic:
            raise Rejected('readback stage')
        pub = self.params['publication']
        if expected.get('parent', pub['fixed_parent']) != pub['fixed_parent'] or any(not OID.fullmatch(expected.get(n, '')) for n in ('candidate', 'tree')):
            raise Rejected('fixed expected commit/tree/parent')
        if set(payload) != set(pub['allowlist']):
            raise Rejected('local readback payload allowlist')
        ref = self._http('/git/ref/heads/' + pub['review_branch'], phase='ref')
        if ref.get('ref') != 'refs/heads/' + pub['review_branch'] or ref.get('object', {}).get('type') != 'commit' or ref['object']['sha'] != expected['candidate']:
            raise Rejected('conflicting remote ref')
        self._http('/git/commits/' + pub['fixed_parent'], phase='fixed-parent')
        commit = self._http('/git/commits/' + expected['candidate'], phase='candidate')
        parents = [p['sha'] for p in commit['parents']]
        tree = commit['tree']['sha']
        if tree != expected['tree'] or parents != [pub['fixed_parent']]:
            raise Rejected('remote commit tree/sole parent mismatch')
        def entries(oid, relative):
            obj = self._http('/git/trees/' + oid, phase='directory', relative_path=relative)
            if obj.get('truncated') is not False or not isinstance(obj.get('tree'), list):
                raise Rejected('tree truncated or completeness UNKNOWN')
            rows, seen = {}, set()
            for row in obj['tree']:
                name = row.get('path', '')
                if not name or name in ('.', '..') or '/' in name or '\\' in name or '\0' in name or name.casefold() in seen or not OID.fullmatch(row.get('sha', '')):
                    raise Rejected('tree name/path/case collision')
                if (row.get('type'), row.get('mode')) not in (('tree', '040000'), ('blob', '100644'), ('blob', '100755'), ('blob', '120000'), ('commit', '160000')):
                    raise Rejected('tree path type/mode')
                rows[name] = row
                seen.add(name.casefold())
            wire = b''
            for name, row in sorted(rows.items(), key=lambda item: (item[0] + ('/' if item[1]['type'] == 'tree' else '')).encode('utf-8')):
                wire += row['mode'].lstrip('0').encode() + b' ' + name.encode('utf-8') + b'\0' + bytes.fromhex(row['sha'])
            if hashlib.sha1(b'tree ' + str(len(wire)).encode() + b'\0' + wire).hexdigest() != oid:
                raise Rejected('Git tree byte identity')
            return rows
        parts = PurePosixPath(pub['temp_path'].rstrip('/')).parts
        if not parts or any(n in ('.', '..') for n in parts):
            raise Rejected('fixed directory path')
        relative = ''
        for component in parts:
            rows = entries(tree, relative)
            row = rows.get(component)
            if row is None or row['type'] != 'tree':
                raise Rejected('missing directory or wrong path type')
            tree = row['sha']
            relative = (relative + '/' + component).lstrip('/')
        selected = entries(tree, relative)
        if set(selected) != set(pub['allowlist']) or any(row['type'] != 'blob' or row['mode'] != '100644' for row in selected.values()):
            raise Rejected('remote directory exact three-file allowlist')
        actual = {}
        for name in pub['allowlist']:
            row = selected[name]
            blob = self._http('/git/blobs/' + row['sha'], phase='file', relative_path=relative + '/' + name)
            data = base64.b64decode(''.join(blob['content'].split()), validate=True)
            if row.get('size') != len(data):
                raise Rejected('tree/blob byte length mismatch')
            self.check_payload(data, {'bytes': len(payload[name]), 'sha256': digest(payload[name])})
            actual[name] = data
        manifest = json.loads(actual['manifest.json'])
        if 'zip' in manifest:
            self.check_payload(actual['evidence_sanitized.zip'], manifest['zip'])
        with zipfile.ZipFile(io.BytesIO(actual['evidence_sanitized.zip'])) as archive:
            infos = archive.infolist()
            names = [e.filename for e in infos]
            limits = pub['limits']
            if len(names) != len(set(n.casefold() for n in names)) or len(names) > limits['member_count'] or sum(e.file_size for e in infos) > limits['expanded_zip_bytes']:
                raise Rejected('HTTP ZIP collision/count/expanded bound')
            for entry in infos:
                path = PurePosixPath(entry.filename)
                if path.is_absolute() or '..' in path.parts or '\\' in entry.filename or ':' in entry.filename or entry.is_dir() or entry.file_size > limits['per_member_bytes'] or (entry.external_attr >> 16) & 0o170000 == 0o120000:
                    raise Rejected('HTTP ZIP unsafe member')
                if archive.read(entry).startswith((b'PK\x03\x04', b'\x1f\x8b')):
                    raise Rejected('HTTP ZIP nested archive')
        return self._verify(payload, actual, parents, pub['fixed_parent'])

    def publish(self):
        if self.stage != 'delivery': raise Rejected('publish stage')
        self.validate_profile(self._profile('delivery'))
        qualification = json.loads((ROOT / 'attempts/qualification/test_results.json').read_bytes())
        if len(qualification) < self.params.get('qualification_min_groups', 12) or any(row['status'] != 'PASS' for row in qualification): raise Rejected('qualification not passed')
        payload = {name: (ROOT / 'package' / name).read_bytes() for name in self.params['publication']['allowlist']}
        sealed = json.loads((ROOT / 'package/PAYLOAD_LOCK.json').read_bytes())
        for name, data in payload.items(): self.check_payload(data, sealed[name])
        ref_suffix = '/git/ref/heads/' + self.params['publication']['review_branch']
        try:
            self._http(ref_suffix)
        except urllib.error.HTTPError as exc:
            if exc.code != 404: raise
        else:
            raise Rejected('review ref already exists')
        repo = self._repo('production.git')
        pub = self.params['publication'];remote = self._profile('delivery')['destination']
        state = self.ledger();state['delivery']['fetches'] += 1;self._save_state(state)
        self._git(repo, 'fetch', '--no-tags', '--no-auto-maintenance', '--depth=1', remote, pub['fixed_parent'], network=True)
        if self._git(repo, 'rev-parse', 'FETCH_HEAD').decode().strip() != pub['fixed_parent']: raise Rejected('parent identity mismatch')
        candidate, tree = self._candidate(repo, pub['fixed_parent'], payload)
        expected = {'candidate': candidate, 'tree': tree, 'parent': pub['fixed_parent']}
        write_json(self.attempt_path / 'candidate.json', expected)
        state = self.ledger();state['delivery']['pushes'] += 1;self._save_state(state)
        try:
            self._git(repo, 'push', '--no-verify', remote, candidate + ':refs/heads/' + pub['review_branch'], network=True)
        except BaseException:
            # No retry write. Reserved read-only reconciliation of this candidate.
            try:
                proof = self.readback(expected, payload)
            except BaseException:
                raise
        else:
            proof = self.readback(expected, payload)
        state = self.ledger();state['delivery']['successes'] += 1;self._save_state(state)
        return {**expected, 'readback': proof, 'status': 'DELIVERY_VERIFIED'}


def main():
    if len(sys.argv) != 3 or sys.argv[1] not in ('selftest', 'package', 'publish', 'readback'):
        raise SystemExit('Only selftest, package, publish, readback plus bounded attempt ID')
    operation, attempt = sys.argv[1:]
    stage = 'engineering' if operation in ('selftest', 'package') else 'delivery'
    publisher = Publisher(ROOT, stage, attempt)
    receipt = {'task_id': publisher.params['task_id'], 'run_id': publisher.first['run_id'], 'actual_phase': operation, 'status': 'DELIVERY_BLOCKED', 'candidate': 'UNKNOWN', 'cleanup': 'NOT_APPLICABLE_NO_CANDIDATE', 'planned_stop': publisher.params['stop'], 'science_calls': 0, 'model_calls': 0, 'old_archive_reads': 0, 'formal': publisher.params['formal_state']}
    try:
        if operation == 'selftest':
            receipt['qualification'] = publisher.selftest()
        elif operation == 'package':
            names = json.loads((ROOT / 'sanitized/PUBLIC_PAYLOAD.json').read_bytes())
            payload = publisher.package(names)
            write_json(ROOT / 'package/PAYLOAD_LOCK.json', {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in payload.items()})
            receipt['status'] = 'PACKAGE_PREPARED'
        elif operation == 'publish':
            receipt.update(publisher.publish())
            receipt['cleanup'] = 'ASTRA_PENDING_REVIEW_ARCHIVE_READBACK'
        else:
            raise Rejected('readback is available only inside bounded candidate reconciliation')
    except BaseException as exc:
        raw = repr(exc).encode('utf-8', 'backslashreplace')
        (publisher.private / 'controller-error.bin').write_bytes(raw)
        receipt['first_error'] = redact(raw)
        receipt['first_error_sha256'] = digest(raw)
    finally:
        receipt['resources'] = publisher.ledger()
        receipt['external_controller_completion'] = 'RETURNED_SEPARATELY_AFTER_EXIT'
        path = publisher.attempt_path / 'DELIVERY_FINAL_RECEIPT.json'
        write_json(path, receipt)
        data = path.read_bytes()
        print(json.dumps({'status': receipt['status'], 'bytes': len(data), 'sha256': digest(data), 'base64': base64.b64encode(data).decode()}))


if __name__ == '__main__':
    main()
