import sys,json,pathlib,csv,re,hashlib
from decimal import Decimal
from unit_validator import validate,numeric_tokens
R=pathlib.Path(__file__).parent;sys.stdout.reconfigure(encoding='utf-8')
texts=json.loads((R/'source_texts_v2.json').read_text(encoding='utf-8'));tables=json.loads((R/'xls_tables.json').read_text(encoding='utf-8'))
orig={s['source_id']:s for s in [json.loads(l) for l in (R/'reused/official_origin_bytes.jsonl').read_text(encoding='utf-8').splitlines()]}
ext={s['source_id']:s for s in [json.loads(l) for l in (R/'reused/official_connector_extracts.jsonl').read_text(encoding='utf-8').splitlines()]}
rows=list(csv.DictReader((R/'reused/wage_source_ledger.csv').read_text(encoding='utf-8-sig').splitlines()))
reposts={'AH_NP_RELAY':'OFFICIAL_GOV_HOST_NEWS_REPUBLICATION','HB_W':'OFFICIAL_GOV_REPUBLICATION_RETROSPECTIVE','HE_W':'OFFICIAL_FEDERATION_HOST_NEWSPAPER_REPUBLICATION','SX_P':'OFFICIAL_GOV_REPUBLICATION','SX_NP_RELAY':'OFFICIAL_GOV_REPUBLICATION_RETROSPECTIVE','JS_W_RELAY':'OFFICIAL_GOV_REPUBLICATION_RETROSPECTIVE','NX_NP':'OFFICIAL_GOV_REPUBLICATION','SC_WE':'OFFICIAL_GOV_PUBLIC_SERVICE_REPUBLICATION','GS_E':'OFFICIAL_COUNTY_GOV_REPUBLICATION','JX_E':'OFFICIAL_GOV_HOST_NEWSPAPER_REPUBLICATION','HB_E':'OFFICIAL_GOV_HOST_MEDIA_REPUBLICATION','GD_E':'OFFICIAL_GOV_HOST_REPORT_REPUBLICATION'}
ledger=[]
province_registry=json.loads((R/'source_province_registry.json').read_text(encoding='utf-8'))
for r in rows:
 p,metric,sid=r['province'],r['measure'],r['source_id'];t=texts.get(sid,'');v=r['value']
 z=dict(province=p,year=2018,metric=metric,previous_value=v,source_id=sid,url=r['url'],SOURCE_CLASS=reposts.get(sid,'STATISTICAL_AGENCY_ORIGINAL'),DOC_VINTAGE=r['vintage'],SOURCE_SHA=orig.get(sid,ext.get(sid,{})).get('sha256',ext.get(sid,{}).get('extract_sha256','')),SOURCE_BYTE_STATUS='ORIGINAL_BYTES_VERIFIED' if sid in orig else 'EXTRACT_ONLY_NOT_ORIGINAL_BYTES_VERIFIED' if sid in ext else 'MISSING',OLD_PROVIDER_HTTP=r['provider_http'],RAW_VALUE='',RAW_UNIT='',NORMALIZED_VALUE='',TRANSFORM_EXACTNESS='NOT_EVALUATED',PRECISION='',STAT_POPULATION='',TIME_TYPE='UNKNOWN',GEOGRAPHIC_AXIS='PROVINCE',GEOGRAPHIC_BASIS='UNKNOWN',PUBLICATION_YEAR=r['vintage'][:4] if re.match(r'^20\d\d',r['vintage']) else 'UNKNOWN',TABLENAME_ROW='',VALIDATION_STATUS='MISSING_OFFICIAL_SOURCE',EXCEPTION_REASON='',mean_wage_weight_eligible=False)
 if not sid:ledger.append(z);continue
 if sid.startswith('GS_') and 'CANDIDATE' in sid:z['SOURCE_CLASS']='ATTRIBUTED_PUBLIC_INSTITUTION_RELAY_NOT_STATISTICS_ORIGINAL'
 if sid in ('JS_P','XJ_NP'):z['SOURCE_CLASS']='STATISTICAL_AGENCY_LATER_YEARBOOK_2018_ROW'
 wage=metric.startswith('wage_');nonp='nonprivate' in metric
 pop=('URBAN_NONPRIVATE_WAGE' if nonp else 'URBAN_PRIVATE_WAGE') if wage else {'N_employed_total_wan':'TOTAL_EMPLOYED','N_employed_urban_wan':'URBAN_EMPLOYED','N_wage_covered_nonprivate_wan':'URBAN_NONPRIVATE_UNIT_EMPLOYED','N_wage_covered_private_wan':'URBAN_PRIVATE_UNIT_EMPLOYED','N_resident_wan':'RESIDENT'}[metric]
 time='ANNUAL_AVERAGE' if wage else 'YEAR_END' if 'YEAR_END' in r['time'] else 'UNKNOWN'
 if sid=='LN_COV':time='UNKNOWN' # actual table header does not establish annual average or year-end
 basis='WORKPLACE_UNIT_REPORTING' if wage or 'wage_covered' in metric else 'RESIDENCE' if pop=='RESIDENT' else 'UNKNOWN'
 raw_expected=Decimal(v)*10000 if sid=='JL_COV' else Decimal(v)
 tt=re.sub(r'(?<=\d)\.\s+(?=\d)','. ',t) if False else re.sub(r'(?<=\d)\.\s+(?=\d)真','.',t)
 # layout whitespace is handled explicitly only for a documented decimal point
 tt=re.sub(r'(?<=\d)\.\s+(?=\d)','. ',t).replace('. ','.')
 matches=[(a,i,j) for a,i,j in numeric_tokens(tt) if Decimal(a.replace(',',''))==raw_expected]
 if sid=='LN_E':
  ri=4 if metric=='N_employed_total_wan' else 9;tr=tables[sid][0]['rows'];raw=tr[ri][12];quote='5-1 就业基本情况; 2018年列; '+tr[ri][0]+'; 单位万人; '+raw
 elif sid=='LN_COV':
  tr=tables[sid][0]['rows'];raw=tr[7][13];quote='5-4 各地区城镇非私营单位就业人员;2018年/单位全部就业人员;全省;单位万人;'+raw
 elif matches:
  a,i,j=matches[0];raw=a.replace(',','');quote=tt[max(0,i-180):min(len(tt),j+180)]
 else:
  z.update(VALIDATION_STATUS='INDETERMINATE_SOURCE_VALUE_LOCATOR',EXCEPTION_REASON='no exact numeric token at available evidence precision');ledger.append(z);continue
 unit='yuan/person/year' if wage else 'people' if sid=='JL_COV' else 'wan_people'
 source=dict(province=province_registry.get(sid,'UNKNOWN'),year=2018,geographic_axis='PROVINCE',population=pop,time_type=time,geographic_basis=basis,value=raw,unit=unit,locator=quote,source_sha256=z['SOURCE_SHA'])
 target={**source,'province':p,'value':v,'unit':'yuan/person/year' if wage else 'wan_people'}
 # year and metric identity are reviewed using page title/table/year column, not the token alone.
 year_context='2018' in t
 province_context=p in t or sid in ('JL_COV','LN_E','LN_COV','JL_NP','JS_P','XJ_NP')
 status=validate(source,target)
 if not year_context or not province_context:status='INDETERMINATE_YEAR_OR_PROVINCE_LOCATOR'
 if status=='PASS_UNIT_AND_SCOPE_MATCH' and z['SOURCE_BYTE_STATUS'].startswith('EXTRACT'):status='VALUE_UNIT_SCOPE_MATCH__EXTRACT_ONLY'
 if sid in ('GS_NP_CANDIDATE','GS_P_CANDIDATE'):status='VALUE_UNIT_MATCH__SOURCE_CLASS_NOT_PRIMARY'
 z.update(RAW_VALUE=raw,RAW_UNIT=unit,NORMALIZED_VALUE=str(Decimal(raw)*(Decimal('0.0001') if unit=='people' else 1)),TRANSFORM_EXACTNESS='DECIMAL_EXACT',PRECISION=str(Decimal(raw).as_tuple().exponent),STAT_POPULATION=pop,TIME_TYPE=time,GEOGRAPHIC_BASIS=basis,TABLENAME_ROW=quote,VALIDATION_STATUS=status,EXCEPTION_REASON=('time/geographic basis unknown; cannot adopt as employment scale' if status.startswith('INDETERMINATE') else 'extract grade preserved' if 'EXTRACT' in status else 'mean-period denominator not established' if 'wage_covered' in metric else ''))
 ledger.append(z)
def writecsv(n,rs):
 with (R/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
writecsv('prior_validation_ledger.csv',ledger)
from collections import Counter
print(json.dumps(dict(rows=len(ledger),observations=sum(bool(r['source_id']) for r in ledger),statuses=Counter(r['VALIDATION_STATUS'] for r in ledger),jl=[r for r in ledger if r['source_id']=='JL_COV'],unlocated=[{k:r[k] for k in ('province','metric','previous_value','source_id','VALIDATION_STATUS')} for r in ledger if r['source_id'] and 'LOCATOR' in r['VALIDATION_STATUS']],js_private_text=texts['JS_P'][:1800]),ensure_ascii=False))
