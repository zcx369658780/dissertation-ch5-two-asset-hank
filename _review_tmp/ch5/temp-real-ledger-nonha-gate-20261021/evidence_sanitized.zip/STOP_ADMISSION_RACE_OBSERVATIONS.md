# STOP admission: separate counters and entry

T5 pre-created STOP: original guard denied entry; begin_ha nevertheless incremented
its in-memory HA counter and active marker before event's guard raised. Persistent
HA remained0, no charged event was appended and the inert entry marker was not
called. This is not a real HA call or successful persistent debit.

The synchronized race used one task-owned STOP publisher thread. An inert OS
wrapper pauses at checkpoint's replace boundary, after the original event guard
and append. The publisher writes STOP and signals completion before replace can
return. Original checkpoint and begin_ha then returned, and a harmless dummy entry
marker ran. The event append preceded STOP; persistent checkpoint commit and
dummy entry followed STOP. Thus the observed defect is a bounded admission window,
not a claim that the raw event was first appended after STOP.

A subsequent original guard denied entry. The publisher thread was joined. The
initial harness assertion used a strict monotonic_ns ordering; this Windows Python
uses GetTickCount64 with 15.625ms resolution, so sub-tick ordering is unsupported.
Those first timestamp values were not persisted and remain UNKNOWN. Attempt2 uses
QueryPerformanceCounter timestamps, saves them before asserting nondecreasing
order, and primarily relies on the explicit publish/ack synchronization.

The actual supervisor/reader and price-bridge bodies are outside scope. The test
does NOT establish global STOP atomicity, real HA admission safety, or production
readiness. Its dummy entry and original ledger's HA fields are synthetic counters;
all actual scientific imports/calls are zero.
