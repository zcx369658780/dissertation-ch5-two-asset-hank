import os,json,hashlib,pathlib,ast,stat,sys
root=pathlib.Path(__file__).parent
def put(name,data):
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True)
 if not isinstance(data,bytes):data=json.dumps(data,ensure_ascii=False,separators=(",",":"),allow_nan=False).encode()
 with open(p,"xb") as f:f.write(data);f.flush();os.fsync(f.fileno())
 assert p.read_bytes()==data
def blob(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+bytes([0])+b).hexdigest()
def get(name):return json.loads((root/name).read_text("utf-8"))
checks=[]
for p in sorted(root.glob("*source.json"))+sorted(root.glob("model_*.json"))+sorted(root.glob("intake_*.json")):
 x=get(p.name);b=x["content"].encode()
 assert blob(b)==x["sha"],"SOURCE_IDENTITY_MISMATCH:"+p.name
 checks.append({"receipt":p.name,"blob":x["sha"],"sha256":hashlib.sha256(b).hexdigest(),"length":len(b)})
m=json.loads(get("intake_5.json")["content"])
for f in m["files"]:
 x=next(get("intake_"+str(i)+".json") for i in range(7) if get("intake_"+str(i)+".json")["path"]==f["path"])
 assert x["sha"]==f["git_blob"]
assert get("fixture_source.json")["sha"]==m["source_pins"]["fixture_blob"]
assert get("blackbox_source.json")["sha"]==m["source_pins"]["blackbox_blob"]
assert get("intake_6.json")["sha"]==m["source_pins"]["roadmap_blob"]
blackbox=get("blackbox_source.json")["content"].encode()
assert hashlib.sha256(blackbox).hexdigest()=="b92f6efc59d9398f89f8fb6ee67bf6c5f947282d76895051bec194967ec9c3e3"
fixture=json.loads(get("fixture_source.json")["content"])
assert fixture["population_N"]==[100,160] and fixture["Zt"]==[6,6.2] and fixture["initial_GovInv"]==[100,120]
assert fixture["grid"]["shape_b_a_z"]==[20,20,2]
trial=json.loads(json.dumps(fixture));trial["population_N"]=[50,80]
assert [k for k in fixture if fixture[k]!=trial[k]]==["population_N"]
put("fixture_baseline.json",get("fixture_source.json")["content"].encode())
put("fixture_trial.json",trial)
put("exports/__init__.py",b"")
put("exports/matlab_faithful_two_asset_ha.py",blackbox)
put("postloop.py",get("postloop_source.json")["content"].encode())
for p in root.glob("model_*.json"):
 x=get(p.name);name=p.name[len("model_"):-len(".json")]
 put("model/"+name,x["content"].encode())
put("model/__init__.py",b"")
source=get("model_one_turn.py.json")["content"];tree=ast.parse(source)
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=="run_mainline_one_turn")
edits=[]
body=[]
for n in fn.body:
 if isinstance(n,ast.If) and ast.unparse(n.test).startswith("not all(batch.converged)"):
  edits.append("remove intermediate strict_qualified/converged pre-rejection");continue
 body.append(n)
fn.body=body
class ChangeConvergent(ast.NodeTransformer):
 def visit_keyword(self,node):
  if node.arg=="convergent" and isinstance(node.value,ast.Constant) and node.value.value is True:
   edits.append("convergent=True -> bool(batch.converged[i])")
   node.value=ast.parse("bool(batch.converged[i])",mode="eval").body
  return self.generic_visit(node)
fn=ChangeConvergent().visit(fn);ast.fix_missing_locations(fn)
assert len(edits)==2
bridge="import numpy as np\nfrom .firm import evaluate_firm\nfrom .monetary import taylor_assignment\n"+ast.unparse(fn)+"\n"
put("model/temp_bridge.py",bridge.encode())
emp=get("empirical_source.json")["content"];et=ast.parse(emp)
defs=[n for n in et.body if isinstance(n,ast.FunctionDef) and n.name in {"_source_labor_root","_source_initial_arrays"}]
assert len(defs)==2
initial="from typing import Mapping\nimport numpy as np\nfrom scipy.optimize import brentq\nfrom exports.matlab_faithful_two_asset_ha import EconomicParams,MatlabFaithfulHJBGrid,matlab_faithful_illiquid_return\n"+"\n\n".join(ast.get_source_segment(emp,n) for n in defs)+"\n"
put("initializer.py",initial.encode())
protected=[]
b=get("bootstrap.json")
for s in b["protected_metadata"]:
 p=pathlib.Path(s["path"]);ss=p.stat();protected.append({"path":str(p),"size":ss.st_size,"mtime_ns":ss.st_mtime_ns,"inode":ss.st_ino,"attributes":ss.st_file_attributes})
for g in b["git_metadata"][:2]:
 p=pathlib.Path(g);ss=p.stat()
 assert not ss.st_file_attributes&stat.FILE_ATTRIBUTE_REPARSE_POINT
 protected.append({"path":str(p),"size":ss.st_size,"mtime_ns":ss.st_mtime_ns,"inode":ss.st_ino,"attributes":ss.st_file_attributes})
p=pathlib.Path(b["git_metadata"][1])/"index";ss=p.stat()
protected.append({"path":str(p),"size":ss.st_size,"mtime_ns":ss.st_mtime_ns,"inode":ss.st_ino,"attributes":ss.st_file_attributes})
put("protected_before.json",protected)
put("source_identity_checks.json",{"checks":checks,"all_match":True,"bridge_edits":edits,"initializer":"two original source functions extracted unchanged; effective_return_squared and original consumption preserved","numerics":{"delta":1000,"convergence_tolerance":1e-7,"max_iterations":100,"drift_tolerance":1e-12},"qualification":"SOURCE_IDENTITY_AND_N_ONLY_INPUT_PASS","science_calls":0})
print(json.dumps({"source_checks":len(checks),"N_only_change":True,"blackbox_exact":True,"bridge_edits":edits,"protected_metadata_objects":len(protected),"science_calls":0}))
