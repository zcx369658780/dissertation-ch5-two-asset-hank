import sys,pathlib,json,datetime,hashlib,base64,re,os
from urllib.request import Request,build_opener,HTTPRedirectHandler
from urllib.error import HTTPError
from urllib.parse import urljoin
from lxml import html
R=pathlib.Path(__file__).parent;sys.stdout.reconfigure(encoding='utf-8')
class NoRedirect(HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
opener=build_opener(NoRedirect)
spec=json.loads((R/sys.argv[1]).read_text(encoding='utf-8'));out=R/'new_fetches.jsonl'
old=[json.loads(l) for l in out.read_text(encoding='utf-8').splitlines()] if out.exists() else [];seen={s['url'] for s in old};count=len(old)
for s in spec:
 assert s['url'] not in seen,'DUPLICATE_SOURCE_REQUEST';assert count<80,'RESERVE_FOR_WEB_120_TOTAL';seen.add(s['url'])
 r={**s,'requested_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'transport_error':None,'provider_http':None,'http_attempts':1,'original_bytes_available':False}
 try:
  try:q=opener.open(Request(s['url']),timeout=18)
  except HTTPError as e:q=e
  with q:b=q.read(2500001);r.update(provider_http=q.code,headers={k:q.headers[k] for k in ('Content-Type','Last-Modified','Location') if k in q.headers})
  r.update(length=len(b),sha256=hashlib.sha256(b).hexdigest(),encoding='base64',content_base64=base64.b64encode(b).decode());assert len(b)<=2500000,'SOURCE_SIZE_LIMIT'
  r['original_bytes_available']=r['provider_http']==200
  if r['original_bytes_available']:
   try:
    try:t=b.decode('utf-8-sig');r['text_encoding']='utf-8'
    except UnicodeDecodeError:t=b.decode('gb18030');r['text_encoding']='gb18030'
    root=html.fromstring(t);r['links']=[{'text':' '.join(a.text_content().split()),'url':urljoin(s['url'],a.get('href'))} for a in root.xpath('//a[@href]')]
    r['frames']=[urljoin(s['url'],a.get('src')) for a in root.xpath('//frame[@src]')]
    [e.drop_tree() for e in root.xpath('//script|//style')];r['text']=re.sub(r'\s+',' ',root.text_content())
   except Exception as e:r['parse_status']=type(e).__name__+':'+str(e)
 except Exception as e:r['transport_error']=type(e).__name__+':'+str(e)
 count+=1
 with out.open('a',encoding='utf-8') as f:f.write(json.dumps(r,ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno())
 print(json.dumps({k:v for k,v in r.items() if k not in ('content_base64','text','links')},ensure_ascii=False))
 if r.get('links'):print(json.dumps({'id':s['source_id'],'links':[a for a in r['links'] if any(k in a['text'] for k in ('工资','就业','劳动','2018','2019','人口'))][:65]},ensure_ascii=False))
 if r.get('text'): print(json.dumps({'id':s['source_id'],'text':r['text'][:700]},ensure_ascii=False))
