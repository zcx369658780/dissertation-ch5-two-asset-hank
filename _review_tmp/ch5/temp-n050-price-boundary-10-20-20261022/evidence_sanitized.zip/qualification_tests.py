import sys,json,time,subprocess,hashlib,pathlib,types,importlib,os
import numpy as np
from core import ROOT,put,Ledger,Halt,trend_gate,snapshot_check
from winjob import Job
def namespace():
 m=types.ModuleType("mp");m.__path__=[str(ROOT/"model")];sys.modules["mp"]=m
namespace()
from mp.stationary_runtime import mainline_initial_states
from mp.one_turn import run_mainline_one_turn,prepare_mainline_household_states,PreFrozenHouseholdOutputBatch
from mp.temp_bridge import run_mainline_one_turn as bridge
f=json.loads((ROOT/"fixture_trial.json").read_text("utf-8"))
states=prepare_mainline_household_states(mainline_initial_states(f),f)
batch=PreFrozenHouseholdOutputBatch(np.array([4.,4.2]),np.array([.8,.9]),np.array([2.,2.4]),np.array([1.,1.1]),np.array([.001,.002]),(True,True),({"strict_qualified":True},{"strict_qualified":True}))
a=run_mainline_one_turn(states,batch,f);b=bridge(states,batch,f)
for x,y in zip(a["states"],b["states"]):
 assert x.keys()==y.keys()
 for k in x:
  if isinstance(x[k],(int,float)):assert np.isclose(x[k],y[k],rtol=1e-13,atol=1e-13),(k,x[k],y[k])
  else:assert x[k]==y[k]
np.testing.assert_allclose(a["shares"],b["shares"],rtol=0,atol=0)
batch2=PreFrozenHouseholdOutputBatch(batch.ct,batch.household_lt,batch.at,batch.bt,batch.at_tax,(False,True),({},{}))
c=bridge(states,batch2,f)
assert c["states"][0]["convergent"] is False and c["states"][1]["convergent"] is True
stub=[{"max_KN_gap":1.,"max_Y_gap":1.,"both_provinces_any_raw_outside":False} for _ in range(10)]
assert trend_gate(stub)["decision"]=="TREND_NOT_OBVIOUS_AT_10"
for i in range(5,10):stub[i]["both_provinces_any_raw_outside"]=True
for i in range(7,10):stub[i]["max_KN_gap"]=1.2;stub[i]["max_Y_gap"]=1.2
assert trend_gate(stub)["decision"]=="EARLY_STOP_OBVIOUS_WORSENING_10"
ledger=Ledger("qualification")
ledger.begin(0,1);ledger.terminal("INJECTED_STUB_FAILURE")
charged=ledger.c["HA_attempts"]
try:ledger.begin(1,1);raise AssertionError("ADMITTED_AFTER_FAILURE")
except Halt:pass
assert ledger.c["HA_attempts"]==charged
limits=Ledger("qualification_limits");limits.c["HA_attempts"]=40
try:limits.begin(0,21);raise AssertionError("OVER_LIMIT")
except Halt:pass
stop=ROOT/"STOP_REQUEST.json";put("STOP_REQUEST.json",{"scope":"stub_only"})
try:
 try:Ledger("qualification_stop").begin(0,1);raise AssertionError("STOP_IGNORED")
 except Halt:pass
finally:stop.rename(ROOT/"qualification_STOP_RETAINED.json")
child=ROOT/"stub_child.py"
put("stub_child.py",b"import time\nprint('STUB_READY',flush=True)\ntime.sleep(120)\n")
job=Job();p=job.start([sys.executable,"-B",str(child)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,cwd=str(ROOT))
assert p.stdout.readline().strip()=="STUB_READY"
job.terminate();rc=p.wait(timeout=5);job.close();assert rc!=0
snapshot_check()
put("runner_qualification.json",{"verdict":"PASS_TASK_OWNED_COOPERATING_RUNNER_ONLY","tests":["macro_bridge_same_values_all_fields","truthful_unconverged_flag","ten_round_gold_early_stop_gate","failure_latch_prevents_new_charge","HA40_and_outer20_limits","local_STOP_denies_admission","Windows_job_suspended_assignment_and_termination","protected_metadata_unchanged"],"stub_child_pid":p.pid,"stub_child_exit_code":rc,"stub_HA":0,"science_HA":0,"production_GLOBAL_STOP":"UNVERIFIED","OS_descendants_outside_owned_job":"UNKNOWN"})
print(json.dumps({"qualification":"PASS","tests":8,"science_HA":0,"child_exit":rc}))
