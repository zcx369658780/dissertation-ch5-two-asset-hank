|ID|事项|证据与限制|所需后续决定|影响|
|---|---|---|---|---|
|U01|a/b household grid currency|No formally adopted currency per grid unit|Owner/advisor must freeze source-backed economic unit|BLOCKS_HA|
|U02|asset_bridge coefficient|No formally adopted coefficient mapping grid*population to macro capital|Freeze explicit coefficient, units and provenance; no implicit 1/100/10000|BLOCKS_HA|
|U03|Ct/Bt/AtTax/Tt and labor units|Household stocks/flows, transfers and fiscal aggregation need coherent normalization|Freeze units and multiply-by-N semantics for each field|DOWNSTREAM_UNRESOLVED|
|U04|wage and return bounds comparability|Wage bounds unreconciled to 2018 flow units; rah reference not independent clip|Freeze comparable units without tuning/widening price bounds|BLOCKS_HA|
|Q01|31x31 labor/capital oracles|NOT_RUN_UNIT_GATE_BLOCKED|Only after economic unit authority is established|NOT_A_NUMERICAL_FAILURE|
|Q02|isolated STOP/budget runner qualification|NOT_RUN_UNIT_GATE_BLOCKED|New task gate required before science; production GLOBAL_STOP remains UNVERIFIED|NOT_A_RUNTIME_CERTIFICATION|
