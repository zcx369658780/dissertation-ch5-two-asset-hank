# Authenticated original methods, bounded execution

The archive was located at one of exactly four frozen candidates. Original bytes:
1,214,713; SHA256 f3e8984fe4d2ef4be65692c27fa7594d96b870d372a8c45d029899f7891841d8.
Its 278-entry directory was inspected only after identity verification. Exactly six
allowlisted text members (37,853 decoded bytes) were read. No nested archive or
scientific array was read. The original archive and old journals were not changed.

The two frozen modules were parsed, never imported. The factorial module has a
top-level exec of a runtime file, plus a scientific run/main; all are excluded.
temp_driver contains dynamic loaders and real scientific dependencies; it was
static-only. Its observer orders begin_ha before initializer/household work.
Neither observer nor production run was compiled or called.

The public extractor compiles ONLY the original Budget class and its pure limits
function, after source SHA and AST/symbol checks. Eight methods plus limits have
per-function AST and source-segment hashes and original line numbers. Copying AST
nodes does not change their bodies. A single pure E2_ comparison is separately
compiled; the surrounding catch/run is static-only. Every successful test process
re-ran this gate before creating its disposable Budget.

Explicit runtime bindings are stdlib filesystem, msvcrt locking, clock, native
owned-process working-set measurement, JSON/SHA and disposable STOP fixtures.
The NumPy-like asarray/tobytes input interface is a two-scalar struct.pack('<dd')
wrapper, NOT production NumPy verification. The ha binding is an inert file-name
sentinel and is never imported. No observer, HA or solver body is called.

The harness audit rejects writes outside its task scratch, unapproved reads,
unknown non-stdlib imports and unrelated subprocess commands. This is a bounded
defense for reviewed source, not a general-purpose hostile-code sandbox. Original
methods are trusted only after the frozen byte and dependency gate.

Source private bytes, extracted full method text, raw fixture journals and native
stderr remain private. This package exposes new harness code, AST identities,
sanitized observations and raw-retention identities only. Astra has not thereby
received the old private original source bytes. Production runtime remains
UNVERIFIED, including the absent supervisor, reader and actual price bridge.
