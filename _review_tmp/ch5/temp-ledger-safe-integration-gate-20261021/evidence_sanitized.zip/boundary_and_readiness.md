# Bounded result and readiness

REAL_CONTROLLER_SOURCE_NOT_AVAILABLE.
RUN_TYPED_WIRING_SOURCE_GAP.
COOPERATING_CROSS_PROCESS_FIXTURE_PASS.
GLOBAL_SUPERVISOR_READER_UNVERIFIED.
PRODUCTION_RUNTIME_UNVERIFIED.
PATCH_NOT_DEPLOYED. HA/HJB/KFE/GE/IRF/scientific-driver calls=0.

X1 mapped authenticated run/main/Budget static paths; no original run executed.
X2 used two separate writer/publisher processes for each of two inert cases.
X3 used three separate writer/publisher/reader processes. The publisher had actual
OS byte-lock contention while the Budget writer was paused at checkpoint replace.
All attached actors validated the same descriptor, owner and fence file identity.
Only the writer called the accepted exclusive RepairProtocol constructor. Other
actors opened their own handles to the existing lock; they did not create another
RepairProtocol or substitute an in-process thread lock for the OS lock.

Each sequence demonstrates STOP_ATTEMPT and lock contention, observed durable
charge, inert entry return, STOP_DURABLE, then STOP_ACK. The reader observed validated
STOP and ACK afterward. Subsequent admission was denied without new charge or entry.
Explicit lock/handshake ordering supports the timeline, rather than relying only
on timestamps. Durability means file fsync plus atomic replacement and readback;
directory/power-loss durability is not certified.

X4 preserved the original PermissionError object through finish, produced typed
hard classification, kept unrelated E1 non-hard and recovered a verified stage.
X5 rejected corrupt STOP, unknown partial stage and wrong attachment identity;
duplicate STOP left ACK bytes unchanged. Two native owned-current-reader sharing
modes produced observed results, with verified recovery after handle closure.
An owned worker exited23 after charge and before inert entry, was reaped, and its
OS lock was reacquired without resuming the original one-shot journal.

X6 kept the private candidate and all accepted method ASTs/support bytes unchanged.
The new runtime fence binding is explicitly fixture-only. The accepted prior eight
groups are reused at their frozen provenance, not claimed to have been rerun here.

No real supervisor or reader was supplied by the bounded census. The new actors
are test fixtures, not substitutes for missing production source. Uncoordinated
STOP writers, production dispatch, actual HA observer entry, hostile filesystem
mutation, all possible process-crash intervals and power-loss remain unqualified.
Original production sources, private historical journals and model equations were
not changed. The old pending review candidates are retained.
