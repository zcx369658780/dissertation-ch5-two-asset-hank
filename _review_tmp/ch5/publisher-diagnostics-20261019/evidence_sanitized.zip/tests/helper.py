"""New inert synthetic child. Never reads external files or launches children."""
import json
import os
import sys
import threading
import time

mode = sys.argv[1]
private_path = bytes([67, 58, 92]) + b'SYNTHETIC_PRIVATE' + bytes([92])
if mode == 'nonzero':
    os.write(2, b'fatal: synthetic repository ' + private_path + b'repo not found\n')
    sys.exit(7)
elif mode == 'binary':
    os.write(1, bytes(range(256)))
    os.write(2, b'\xff\x00\x1bsynthetic\n')
elif mode == 'warning':
    os.write(2, b'warning: synthetic harmless message\n')
elif mode == 'args':
    os.write(1, json.dumps(sys.argv[2:], ensure_ascii=False).encode())
elif mode == 'large':
    a = threading.Thread(target=lambda: os.write(1, b'A' * 262144))
    b = threading.Thread(target=lambda: os.write(2, b'B' * 262144))
    a.start(); b.start(); a.join(); b.join()
elif mode == 'timeout':
    os.write(1, b'synthetic partial before sleep\n')
    time.sleep(30)
elif mode == 'redaction':
    os.write(2, b'error: ' + private_path + b'folder/file token=FAKE_SYNTHETIC_CREDENTIAL_123\n')
else:
    raise ValueError('unknown synthetic mode')
