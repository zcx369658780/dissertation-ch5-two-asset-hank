"""New bounded support for a private patch of the authenticated original Budget.
No solver, production module, historical journal, or general resume interface.
"""
import contextlib
import hashlib
import json
import msvcrt
import os
from pathlib import Path
import stat
import threading
import time

class LedgerFault(RuntimeError):
    def __init__(self, code, stage):
        self.code=code;self.stage=stage;self.shared_hard=True
        super().__init__(code+'@'+stage)

def classify(exc, stage):
    if isinstance(exc,LedgerFault):return {'hard':True,'code':exc.code,'stage':exc.stage}
    if isinstance(exc,PermissionError) and stage.startswith(('checkpoint','event','finish')):
        return {'hard':True,'code':'CHECKPOINT_ACCESS_DENIED','stage':stage}
    if isinstance(exc,OSError) and stage.startswith(('checkpoint','event','finish')):
        return {'hard':True,'code':'LEDGER_IO_UNCERTAIN','stage':stage}
    if stage.startswith(('checkpoint','event','finish','prefix','admission')):
        return {'hard':True,'code':'LEDGER_STATE_UNCERTAIN','stage':stage}
    return {'hard':False,'code':'ORDINARY_E1','stage':stage}

def strict(raw):
    def pairs(items):
        out={}
        for k,v in items:
            if k in out:raise LedgerFault('DUPLICATE_JSON_KEY','prefix')
            out[k]=v
        return out
    try:return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
    except LedgerFault:raise
    except (ValueError,UnicodeError) as exc:raise LedgerFault('INVALID_JSON','prefix') from exc

class RepairProtocol:
    def __init__(self, root):
        self.root=Path(root);self.mutex=threading.RLock();self.local=threading.local()
        self.primary={};self.blocked=set();self.staged={};self.trace=[]
        self.fence_path=self.root/'admission.fence'
        with self.fence_path.open('xb',buffering=0) as f:f.write(b'1');os.fsync(f.fileno())
    def fault(self,code,stage):return LedgerFault(code,stage)
    def mark(self,kind,**data):self.trace.append({'kind':kind,'qpc_ns':time.perf_counter_ns(),**data})
    @contextlib.contextmanager
    def fence(self):
        with self.mutex:
            depth=getattr(self.local,'depth',0)
            if depth:
                self.local.depth+=1
                try:yield
                finally:self.local.depth-=1
                return
            f=self.fence_path.open('r+b',buffering=0);deadline=time.monotonic()+3
            try:
                while True:
                    try:f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1);break
                    except OSError:
                        if time.monotonic()>=deadline:raise LedgerFault('FENCE_OCCUPIED','admission')
                        time.sleep(.01)
                self.local.depth=1
                try:yield
                finally:self.local.depth=0;f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
            finally:f.close()
    @contextlib.contextmanager
    def admission(self,b):
        with self.fence():
            b.guard()
            if id(b) in self.blocked:self.raise_primary(b)
            self.mark('ADMISSION_BEGIN')
            yield
            self.mark('ADMISSION_RETURN')
    def admit_and_enter(self,b,inputs,entry):
        # The entry is a task-owned inert callback. No actual HA is permitted.
        with self.fence():
            b.guard();path=b.begin_ha(inputs['round'],inputs['province_index'],inputs)
            b.guard();entry();self.mark('INERT_ENTRY_RETURN');return path
    def publish_stop(self):
        self.mark('STOP_ATTEMPT')
        with self.fence():
            p=self.root/'PARENT_STOP_REQUEST.json'
            if not p.exists():
                with p.open('xb',buffering=0) as f:f.write(b'{"inert":true}\n');os.fsync(f.fileno())
            self.mark('STOP_ACK');return self.trace[-1]['qpc_ns']
    def capture(self,b,exc,stage):
        key=id(b);self.blocked.add(key)
        if key not in self.primary:
            record={'type':type(exc).__name__,'stage':stage,'message':str(exc),
                    'winerror':getattr(exc,'winerror',None),'errno':getattr(exc,'errno',None),
                    'classification':classify(exc,stage),'seq_memory':b.seq}
            self.primary[key]={'exception':exc,'record':record,'diagnostic_errors':[]}
            try:
                with (b.path/'primary_error.private.json').open('xb') as f:
                    f.write((json.dumps(record,sort_keys=True)+'\n').encode());f.flush();os.fsync(f.fileno())
            except BaseException as secondary:
                self.primary[key]['diagnostic_errors'].append({'type':type(secondary).__name__,'message':str(secondary)})
        else:self.primary[key]['diagnostic_errors'].append({'type':type(exc).__name__,'stage':stage,'message':str(exc)})
    def raise_primary(self,b):
        if id(b) in self.blocked:raise self.primary[id(b)]['exception']
    def owner(self,b):
        for path,handle in [(b.path/'writer.lock',b.lock),(b.path/'events.jsonl',b.events)]:
            st=path.lstat();fd=os.fstat(handle.fileno())
            if getattr(st,'st_file_attributes',0)&1024 or stat.S_ISLNK(st.st_mode) or (st.st_ino,st.st_dev)!=(fd.st_ino,fd.st_dev):
                raise LedgerFault('WRITER_IDENTITY','prefix')
    def view(self,b):
        self.owner(b);raw=(b.path/'events.jsonl').read_bytes();rows=[];heads={0:'0'*64};chain=heads[0]
        if raw and not raw.endswith(b'\n'):raise LedgerFault('PARTIAL_EVENT','prefix')
        for line in raw.splitlines(keepends=True):
            row=strict(line)
            if not isinstance(row,dict) or type(row.get('seq')) is not int or row.get('seq')!=len(rows)+1 or row.get('previousEventSHA256')!=chain:
                raise LedgerFault('EVENT_PREFIX_MISMATCH','prefix')
            if not isinstance(row.get('counts'),dict) or 'activeHA' not in row:raise LedgerFault('EVENT_SCHEMA','prefix')
            if set(row['counts'])!=set(b.counts) or any(type(v) is not int or v<0 for v in row['counts'].values()):raise LedgerFault('COUNTER_SCHEMA','prefix')
            rows.append(row);chain=hashlib.sha256(line).hexdigest();heads[len(rows)]=chain
        if b.seq!=len(rows) or b.chain!=chain:raise LedgerFault('MEMORY_PREFIX_MISMATCH','prefix')
        def expected(seq):
            row=rows[seq-1]
            return {'seq':seq,'counts':row['counts'],'activeHA':row['activeHA'],'eventHeadSHA256':heads[seq]}
        path=b.path/'current.json';current=None
        if path.exists():
            st=path.lstat()
            if getattr(st,'st_file_attributes',0)&1024:raise LedgerFault('CHECKPOINT_REDIRECTION','prefix')
            current=strict(path.read_bytes());seq=current.get('seq') if isinstance(current,dict) else None
            if type(seq) is not int or not 1<=seq<=len(rows) or current!=expected(seq):raise LedgerFault('CHECKPOINT_PREFIX_MISMATCH','prefix')
            if len(rows)-seq>1:raise LedgerFault('CHECKPOINT_GAP_AMBIGUOUS','prefix')
        elif len(rows)>1:raise LedgerFault('MISSING_CHECKPOINT','prefix')
        return rows,current,(expected(len(rows)) if rows else None)
    def pre_event(self,b):
        self.raise_primary(b);rows,current,head=self.view(b)
        if (b.path/'current.next').exists() or (head is not None and current!=head):
            raise LedgerFault('UNCOMMITTED_PREFIX_BEFORE_APPEND','event')
    def checkpoint_plan(self,b):
        rows,current,head=self.view(b)
        if head is None:raise LedgerFault('EMPTY_CHECKPOINT','checkpoint')
        if head['counts']!=b.counts or head['activeHA']!=b.active:raise LedgerFault('MEMORY_COUNT_MISMATCH','checkpoint')
        path=b.path/'current.next'
        if path.exists():
            proof=self.staged.get(id(b));st=path.lstat()
            if not proof or stat.S_ISLNK(st.st_mode) or getattr(st,'st_file_attributes',0)&1024 or (st.st_ino,st.st_dev)!=(proof['ino'],proof['dev']):
                raise LedgerFault('UNTRUSTED_STAGE','checkpoint')
            data=path.read_bytes()
            if hashlib.sha256(data).hexdigest()!=proof['sha256']:
                raise LedgerFault('UNTRUSTED_STAGE','checkpoint')
            if strict(data)!=head:raise LedgerFault('STAGE_PREFIX_MISMATCH','checkpoint')
            self.mark('VERIFIED_STAGED_PREFIX',seq=head['seq']);return 'STAGED'
        if current==head:self.mark('ALREADY_COMMITTED',seq=head['seq']);return 'COMMITTED'
        return 'NEW'
    def remember_stage(self,b,path):
        st=path.lstat()
        if stat.S_ISLNK(st.st_mode) or getattr(st,'st_file_attributes',0)&1024:raise LedgerFault('STAGE_REDIRECTION','checkpoint')
        data=path.read_bytes();self.staged[id(b)]={'ino':st.st_ino,'dev':st.st_dev,'sha256':hashlib.sha256(data).hexdigest()}
        # Validate against authenticated event head before any replacement.
        if self.checkpoint_plan(b)!='STAGED':raise LedgerFault('STAGE_NOT_PROVEN','checkpoint')
    def committed(self,b):
        rows,current,head=self.view(b)
        if current!=head:raise LedgerFault('COMMIT_NOT_PROVEN','checkpoint')
        self.staged.pop(id(b),None);self.blocked.discard(id(b));self.mark('CHECKPOINT_COMMITTED',seq=head['seq'])
