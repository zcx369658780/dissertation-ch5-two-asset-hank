import sys,os,json,csv,pathlib,hashlib,base64,zipfile,zlib,re,datetime,io
from decimal import Decimal
from collections import Counter
from unit_validator import validate,numeric_tokens
R=pathlib.Path(__file__).parent;sys.stdout.reconfigure(encoding='utf-8')
P=R/'public_review';M=R/'delivery_members';P.mkdir();M.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+bytes([0])+b).hexdigest()
def jb(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def put(n,b):
 with (M/n).open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
def csb(rs):
 f=io.StringIO(newline='');w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs);return ('\ufeff'+f.getvalue()).encode()
boot=json.loads((R/'bootstrap.json').read_text(encoding='utf-8-sig'));run=boot['run_id']
auth=json.loads((R/'authority_received.json').read_text(encoding='utf-8'));commits=json.loads((R/'authority_commits.json').read_text(encoding='utf-8'))
assert commits['0']['sha']=='9a53b2960ee1b088ac12c2815eb0a6debdf2aa19'
assert [p['sha'] for p in commits['0']['parents']]==['34c3c0371fa9b17a129f67ecefef0f7bfd83876c']
assert [p['sha'] for p in commits['1']['parents']]==['f3e2e1bb148c001c714db7ae42072d7f820e1aed']
orig=[json.loads(l) for l in (R/'reused/official_origin_bytes.jsonl').read_text(encoding='utf-8').splitlines()]
ext=[json.loads(l) for l in (R/'reused/official_connector_extracts.jsonl').read_text(encoding='utf-8').splitlines()]
for e in ext:assert sha(e['text'].encode())==e['extract_sha256'],e['source_id']
om={s['source_id']:s for s in orig};em={s['source_id']:s for s in ext}
texts=json.loads((R/'source_texts_v2.json').read_text(encoding='utf-8'));ledger=list(csv.DictReader((R/'prior_validation_ledger.csv').read_text(encoding='utf-8-sig').splitlines()))
extra=json.loads((R/'additional_observations.json').read_text(encoding='utf-8'))
for e in extra:
 sid=e['source_id'];v=e['raw_value'];assert any(Decimal(a.replace(',',''))==Decimal(v) for a,i,j in numeric_tokens(texts[sid]))
 old=next(r for r in ledger if r['province']==e['province'] and r['metric']==e['metric'])
 q={**old};q.update(previous_value='MISSING_OFFICIAL_SOURCE',source_id=sid,url=om[sid]['url'],SOURCE_CLASS='OFFICIAL_GOV_STATISTICAL_BULLETIN',DOC_VINTAGE='2019 bulletin / 2020 URL migration',SOURCE_SHA=om[sid]['sha256'],SOURCE_BYTE_STATUS='ORIGINAL_BYTES_VERIFIED',OLD_PROVIDER_HTTP='200',RAW_VALUE=v,RAW_UNIT='wan_people',NORMALIZED_VALUE=v,TRANSFORM_EXACTNESS='DECIMAL_EXACT',PRECISION=str(Decimal(v).as_tuple().exponent),STAT_POPULATION=e['stat_population'],TIME_TYPE='YEAR_END',GEOGRAPHIC_AXIS='PROVINCE',GEOGRAPHIC_BASIS='UNKNOWN',PUBLICATION_YEAR='2019',TABLENAME_ROW=e['source_year_locator'],VALIDATION_STATUS='INDETERMINATE_GEOGRAPHIC_BASIS',EXCEPTION_REASON='exact value/unit/year-end confirmed; workplace/residence basis not independently established',mean_wage_weight_eligible=False)
 ledger.append(q)
put('source_value_normalization_ledger.csv',csb(ledger))
priorpanel=list(csv.DictReader((R/'reused/wage_employment_2018_31.csv').read_text(encoding='utf-8-sig').splitlines()))
metrics=['wage_private_yuan_year','wage_nonprivate_yuan_year','N_employed_total_wan','N_employed_urban_wan','N_wage_covered_private_wan','N_wage_covered_nonprivate_wan','N_resident_wan']
panel=[];summary=[];counts={m:Counter() for m in metrics}
for p in priorpanel:
 q={'province':p['province'],'year':'2018','panel_qualification':'INCOMPLETE_NOT_ADOPTED'};md=[]
 for m in metrics:
  r=[x for x in ledger if x['province']==p['province'] and x['metric']==m][-1]
  v=r['NORMALIZED_VALUE'] or p[m];q[m]=v;q[m+'_status']=r['VALIDATION_STATUS'];q[m+'_source_id']=r['source_id'];q[m+'_time']=r['TIME_TYPE'];q[m+'_geographic_basis']=r['GEOGRAPHIC_BASIS']
  if r['source_id']:counts[m]['observed']+=1
  if r['VALIDATION_STATUS']=='PASS_UNIT_AND_SCOPE_MATCH':counts[m]['full_scope_origin_bytes']+=1
  if r['VALIDATION_STATUS']=='VALUE_UNIT_SCOPE_MATCH__EXTRACT_ONLY':counts[m]['extract_only_scope']+=1
  md.append('MISSING' if not r['source_id'] else v+('✓' if r['VALIDATION_STATUS']=='PASS_UNIT_AND_SCOPE_MATCH' else 'E' if 'EXTRACT_ONLY' in r['VALIDATION_STATUS'] else '?'))
 panel.append(q);summary.append('|'+p['province']+'|'+'|'.join(md)+'|')
put('wage_employment_2018_31_verified.csv',csb(panel))
provenance=[]
for s in orig+ext:
 sid=s['source_id'];uses=[r for r in ledger if r['source_id']==sid];provenance.append(dict(source_id=sid,url=s['url'],bytes_kind='ORIGINAL_BYTES' if sid in om else 'CONNECTOR_EXTRACT',length=s.get('length',len(s.get('text','').encode())),sha256=s.get('sha256',s.get('extract_sha256','')),old_fixed_commit='d3bb242ed531e749d96aaea24151cb0133b625aa',old_zip_git_blob='fdeaed7d0335c65b5f00954aba87a44f61e2c77e',source_class=uses[0]['SOURCE_CLASS'] if uses else 'DEFINITION_OR_CONTEXT_ONLY',vintage=uses[0]['DOC_VINTAGE'] if uses else 'SEE_SOURCE_RECORD',role='OBSERVATION' if uses else 'CONTEXT_OR_DEFINITION'))
new=[json.loads(l) for l in (R/'new_fetches.jsonl').read_text(encoding='utf-8').splitlines()]
public_new=[]
for s in new:
 d={k:v for k,v in s.items() if k not in ('content_base64','links','text')};d['source_class']='OFFICIAL_STATISTICAL_CATALOG' if s['original_bytes_available'] else 'SOURCE_UNAVAILABLE_OR_REDIRECT'
 if s['original_bytes_available']:d['content_base64']=s['content_base64'];d['text']=s.get('text','')
 public_new.append(d);provenance.append(dict(source_id=s['source_id'],url=s['url'],bytes_kind='NEW_ORIGINAL_BYTES' if s['original_bytes_available'] else 'NEW_REQUEST_OUTCOME',length=s.get('length',''),sha256=s.get('sha256',''),old_fixed_commit='',old_zip_git_blob='',source_class=d['source_class'],vintage=s['vintage'],role=s['role']))
put('official_source_provenance_2018.csv',csb(provenance));put('new_official_sources.jsonl',b''.join((json.dumps(s,ensure_ascii=False)+'\n').encode() for s in public_new))
web=[];request_count=len(new)
def texts_in(x):
 if isinstance(x,dict):
  if x.get('type')=='text' and 'text' in x:yield x['text']
  else:
   for v in x.values():yield from texts_in(v)
 elif isinstance(x,list):
  for v in x:yield from texts_in(v)
for f in sorted(R.glob('web_*.json')):
 b=f.read_bytes();x=json.loads(b);args=x.get('args');num=len(args.get('system2_search_query',args.get('open',[]))) if isinstance(args,dict) else 1;request_count+=num
 st=list(texts_in(x));official=[]
 for t in st:
  for section in re.split(r'-{20,}',t):
   first=section.strip().split('\n')[0]
   if re.search(r'https?://[^\s)]*gov\.cn',first):official.append(section[:2400])
 web.append(dict(receipt=f.name,receipt_sha256=sha(b),request=x.get('query',x.get('args',x.get('url'))),request_count=num,official_discovery_sections=official,adoption='DISCOVERY_ONLY_NO_VALUES_FROM_SEARCH_SNIPPETS',provider_http='UNKNOWN_UNLESS_EXPLICITLY_STATED',not_original_site_bytes=True))
assert request_count==58,(request_count,len(web),len(new))
put('official_search_and_unavailable_receipts.jsonl',b''.join((json.dumps(s,ensure_ascii=False)+'\n').encode() for s in web))
reuse=json.loads((R/'reuse_integrity.json').read_text(encoding='utf-8'))
put('source_reuse_and_new_fetch_ledger.json',jb(dict(old_fixed_commit='d3bb242ed531e749d96aaea24151cb0133b625aa',old_zip_path='_review_tmp/ch5/temp31-wage-employed-2018-20261022/evidence_sanitized.zip',old_zip_sha256=reuse['zip_sha256'],old_zip_git_blob=reuse['git_blob'],old_member_checks=reuse['members'],reused_originals=31,reused_extracts=15,reused_previous_observations=58,newly_located_old_source_observations=2,new_official_requests=request_count,web_query_or_open_attempts=request_count-len(new),direct_official_http_attempts=len(new),redownload_of_verified_31_sources=0,new_value_adoption_from_search_snippets=0,new_http_outcomes=[{k:s.get(k) for k in ('source_id','url','requested_utc','provider_http','transport_error','length','sha256','original_bytes_available')} for s in new])))
put('jl_oracle_original.html',base64.b64decode(om['JL_COV']['content_base64']))
for n in ['unit_validator.py','unit_validator_tests.json','source_province_registry.json','audit_prior.py','extract_v2.py','fetch_official_v2.py','additional_observations.json']:
 put(n,(R/n).read_bytes())
put('validator_recovery_evidence.json',jb(dict(batch1=json.loads((R/'first_error_engineering.json').read_text(encoding='utf-8')),batch2=json.loads((R/'engineering_recovery_batch2.json').read_text(encoding='utf-8')),batch3=json.loads((R/'engineering_recovery_batch3.json').read_text(encoding='utf-8')),unmodified_source_bytes=True,recovery_batches=3,remaining=0,first_source_error='web_015.json: connector timeout; no known origin HTTP status',first_raw_transport_error='GX_2019_PUBLICATIONS_INDEX TLS handshake failed; provider HTTP UNKNOWN',real_origin_http_denial='HLJ_2020_TOC HTTP403; no retry, proxy, credential or TLS-verification change')))
aid=[dict(path=p,git_blob=x['sha'],bytes=len(x['content'].encode()),sha256=sha(x['content'].encode())) for p,x in auth.items()]
put('authority_verified_sanitized.json',jb(dict(task_id='CH5_TEMP31_2018_WAGE_EMPLOYMENT_UNIT_NORMALIZED_RECOVERY_20261022',revision='ISSUED_20261022_R1',live_head=commits['0']['sha'],issue_commit=commits['1']['sha'],review_fixed_parent=commits['2']['sha'],review_parent_tree=commits['2']['tree']['sha'],files=aid,status='EXACT_BLOB_BYTES_AND_MANIFEST_MATCH',subagents=0)))
budget=dict(as_of='PREPUBLICATION_SNAPSHOT',started_utc=boot['started_utc'],snapshot_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),wall_seconds=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(boot['started_utc'].replace('Z','+00:00'))).total_seconds(),python_starts=12,direct_process_starts=32,new_official_source_queries_or_fetches=request_count,E1_batches=3,E1_max=3,old_budget_carry=0,git_write_api_used=0,git_write_api_reserved=6,max_git_write_api=8,science={k:0 for k in ('HA','HJB','KFE','roots','science_driver','outer','GE','IRF')},OS_descendants='UNKNOWN',first_runtime_error='ModuleNotFoundError: requests; chunk d73436 exit1; 0 source requests attempted by that failed process',engineering_errors_preserved=True)
put('first_error_and_budget.json',jb(budget))
cover='# 2018年31省工资就业核验覆盖\n\nSOURCE_BYTES_INTEGRITY_PASS；VALUE_UNIT_VALIDATED_SUBSET；COMPLETE_31_PROVINCE_WAGE_EMPLOYMENT_PANEL=NOT_PASS。\n\n观察值不等于可采纳值。✓表示本机原字节、精确单位及所声明范围检查通过；E为仅摘录支持；?为时间、地理口径或来源等级未决；MISSING为本轮未取得可核官方值。政府转载保留来源分级，✓也不代表统计局原站、Owner采用或Astra独立验收。\n\n|省份|私营工资 元/人/年|非私营工资 元/人/年|全社会就业 万人|城镇就业 万人|私营调查人数 万人|非私营调查人数 万人|常住人口 万人|\n|---|---:|---:|---:|---:|---:|---:|---:|\n'+'\n'.join(summary)+'\n\n|指标|观察覆盖|原字节单位范围通过|仅摘录单位范围匹配|\n|---|---:|---:|---:|\n'+'\n'.join('|'+m+'|'+str(counts[m]['observed'])+'/31|'+str(counts[m]['full_scope_origin_bytes'])+'/31|'+str(counts[m]['extract_only_scope'])+'/31|' for m in metrics)+'\n\n两个工资口径的同范围年度平均就业分母均未核准（0/31），不能机械合并工资。就业数报告工作地/居住地未知时保留UNKNOWN，未用于替换居民人口N。\n'
put('verified_coverage_2018.md',cover.encode())
unresolved='# 缺失、冲突与未解决事项\n\n'+ '\n'.join('- '+p['province']+'：'+', '.join(m+'='+p[m+'_status'] for m in metrics if p[m+'_status']!='PASS_UNIT_AND_SCOPE_MATCH') for p in panel)+'\n\n上海官方2019稿140270与非官方140400的修订关系未核；保留140270旧摘录等级。新疆75457为后年年鉴2018行摘录，原站404，不升级。浙江88883原表行轴未核；辽宁67324就业人员口径未证，均继续MISSING。甘肃两工资为署名事业单位转载，不升级为统计局原表。2020年之后重估就业口径未与2018统一。\n\n吉林2793233人=279.3233万人是2018年末城镇非私营单位就业人数；不是年度平均人数，也不是全社会就业。辽宁5-4单位本来为万人，501.6267不再次除以10000；表内未独立证明时点，保持UNKNOWN。\n\n本轮新定位天津896.56、714.21万人的年末和数值已核，居住地/工作地仍UNKNOWN。新官方年鉴目录确认就业工资章节没有直接31省双工资表；工商登记私营/个体人数不是工资调查人数。检索失效并不证明统计机构未发布。\n\nHOUSEHOLD_HU参考64.8906755511未采纳；就业人口与家庭居民人口桥、年度平均调查人数和单位/地域边界待Owner裁决。正式V010、HU、a/b、价格界、N和asset_bridge均未改。Results=FALSE；V011=NOT_STARTED；生产GLOBAL_STOP=UNVERIFIED。\n'
put('missing_and_conflicts_2018.md',unresolved.encode())
mapping='# 来源与单位映射\n\n工资面板保持元/人/年；SOURCE_ONLY宏观MU=10万元、NU=100人时工资转MU/NU/年除以1000。人数面板为万人，转NU乘100；人→万人除10000，全程Decimal精确比较，未使用容差掩盖1人差异。原表出版小数位单列，Excel浮点仅读取字符串后Decimal，未据低精度推导工资分母。\n\n原值位置逐项保存于source_value_normalization_ledger.csv，source_province_registry.json是从标题、发布机构和表轴人工核准的省份映射；数值令牌用于定位，不独自证明年份和范围。年度工资期、私营/非私营单位范围须由同表标题/说明核准；后年回溯2018行和政府媒体转载单独分级。UNKNOWN并未通过采纳门。\n\n已核旧原件均引用固定历史commit d3bb242ed531e749d96aaea24151cb0133b625aa 下 _review_tmp/ch5/temp31-wage-employed-2018-20261022/evidence_sanitized.zip，SHA256 962d1f789ccd6f61fccbad503ab1a4d780c30abdb8af38c9730a03321bdfcca2，Git Blob fdeaed7d0335c65b5f00954aba87a44f61e2c77e。仅JL关键原表完整重封，其余不变31源不重复封装。新官方目录字节和请求失败证据随包。\n\n工资的WORKPLACE_UNIT_REPORTING表示单位调查/报告所在地的统计对象，不证明实际通勤工作地与家庭居住地映射；用于跨省劳动矩阵仍需独立经济口径桥接。家庭居民N未被任何就业统计替换。\n'
put('unit_and_model_mapping.md',mapping.encode())
integrity=[]
for f in sorted(M.iterdir()):
 b=f.read_bytes();integrity.append(dict(path=f.name,bytes=len(b),sha256=sha(b),crc32=f'{zlib.crc32(b):08x}'))
put('member_integrity.json',jb(dict(scope='all preceding payload members; self and privacy indexed by external manifest',members=integrity)))
patterns=[('private_absolute_path',rb'(?i)(?:[A-Z]:\\(?:Users|ProjectTemp|ResearchCode|Zotero)|/(?:Users|home)/)'),('credential_token',rb'(?:gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{30,}|sk-[A-Za-z0-9]{35,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)')]
privacy=[]
def check(n,b):
 hits=[name for name,rx in patterns if re.search(rx,b)]
 if n.endswith('.jsonl'):
  for line in b.decode('utf-8').splitlines():
   s=json.loads(line)
   if s.get('content_base64'):
    raw=base64.b64decode(s['content_base64']);hits.extend(name+'_decoded' for name,rx in patterns if re.search(rx,raw))
 return dict(path=n,status='PASS' if not hits else 'FAIL',hits=hits,public_official_urls_allowed=True)
for f in sorted(M.iterdir()):privacy.append(check(f.name,f.read_bytes()))
assert all(s['status']=='PASS' for s in privacy),[s for s in privacy if s['status']!='PASS']
put('privacy_check.json',jb(dict(status='PASS',scanned_members=privacy,decoded_base64_checked=True,private_workbooks_included=False,private_HA_arrays_included=False,credentials_included=False,limitations='rule-based local scan plus manual member inventory; public official website contacts are not user credentials')))
members=[]
with zipfile.ZipFile(P/'evidence_sanitized.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(M.iterdir()):
  b=f.read_bytes();z.writestr(f.name,b);members.append(dict(path=f.name,bytes=len(b),sha256=sha(b),crc32=f'{zlib.crc32(b):08x}',privacy=check(f.name,b)['status']))
assert len(members)<=40 and sum(s['bytes'] for s in members)<=16777216
with zipfile.ZipFile(P/'evidence_sanitized.zip') as z:
 assert z.testzip() is None
 for s in members:
  b=z.read(s['path']);assert sha(b)==s['sha256'] and len(b)==s['bytes'] and f'{zlib.crc32(b):08x}'==s['crc32']
terminal='PASS_BOUNDED_VERIFIED_SUBSET__INCOMPLETE_PANEL'
result='# 2018年31省工资就业来源单位核验——本轮Review候选\n\nrun_id='+run+'\nactual_terminal='+terminal+'\n\n吉林2793233人→279.3233万人精确通过；2793232人负例拒绝。258/258正反oracle通过，涵盖31省非对称工资和人数、跨年、错单位、错省、城市冒省及年末/年度平均错配。本轮为Codex本机报告，未代替Astra独立验收。\n\n旧ZIP17/17及31份原始来源完整性通过，58个旧观察逐项复核。20项原字节/单位/已声明范围通过、11项仅摘录匹配、25项时点或地理基准未决、2项来源等级不足；159个旧缺失单元原样保留，另附2项天津年末就业新定位。未发现可采纳的新省级工资，未用检索摘要或非官方均值补数。\n\n新来源查询/页面尝试58次（含5次标准TLS原站请求）。新原站成功仅为国家统计局2019年鉴入口与目录；广西TLS错误无HTTP状态、内蒙古候选URL302、黑龙江年鉴HTTP403均如实保留。网页工具timeout/不可取并非已知原站HTTP拒绝；无换凭据、账号、代理或关闭TLS验证。\n\n工程恢复3/3批：HTML显式字符编码、缺requests改用标准库、PowerShell结果管道语法修复；所有首错保留，未继承旧额度。预算为发布前快照，后续精确写入/回读和回执资源在外置最终JSON结算。无科学调用，未修改正式源码或历史证据。\n\n'+cover+'\n'+unresolved+'\nReview固定parent=f3e2e1bb148c001c714db7ae42072d7f820e1aed；仅本目录result.md、manifest.json、evidence_sanitized.zip。当前文件描述预发布事实，候选commit/tree/parent、三件完整远端回读、最终JSON原件身份在外置回执。等待Astra独立审查与Owner后续经济单位决定，不清理候选、不自动开始下个任务。\n'
with (P/'result.md').open('xb') as f:f.write(result.encode())
zb=(P/'evidence_sanitized.zip').read_bytes()
manifest=dict(schema='ch5.source_unit_recovery.review.v1',run_id=run,actual_terminal=terminal,authority_head=commits['0']['sha'],review_branch='review/ch5-temp31-wage-employed-unit-recovery-20261022',fixed_parent='f3e2e1bb148c001c714db7ae42072d7f820e1aed',temp_path='_review_tmp/ch5/temp31-wage-employed-unit-recovery-20261022/',only_three_files=['result.md','manifest.json','evidence_sanitized.zip'],zip=dict(bytes=len(zb),sha256=sha(zb),git_blob=blob(zb),members=members,expanded_bytes=sum(s['bytes'] for s in members),crc_length_sha_check='PASS'),result=dict(bytes=len(result.encode()),sha256=sha(result.encode()),git_blob=blob(result.encode())),coverage={k:dict(v) for k,v in counts.items()},panel_complete=False,annual_mean_wage_denominator_qualified_provinces=0,science=budget['science'],privacy='PASS_ALL_MEMBERS_AND_NESTED_SOURCE_BYTES',cleanup='ASTRA_ONLY_AFTER_ARCHIVE_REMOTE_READBACK',adoption='NONE_PENDING_INDEPENDENT_REVIEW',Results=False,V011='NOT_STARTED',GLOBAL_STOP='UNVERIFIED',budget_prepublication=budget)
with (P/'manifest.json').open('xb') as f:f.write(jb(manifest))
files=[]
for f in sorted(P.iterdir()):
 b=f.read_bytes();assert check(f.name,b)['status']=='PASS';files.append(dict(name=f.name,bytes=len(b),sha256=sha(b),git_blob=blob(b)))
assert sum(s['bytes'] for s in files)<=6291456
with (R/'local_delivery_identity.json').open('xb') as f:f.write(jb(dict(files=files,members=members,coverage=manifest['coverage'],actual_terminal=terminal,budget_prepublication=budget)))
print(json.dumps(dict(run_id=run,terminal=terminal,files=files,zip_members=len(members),zip_expanded=sum(s['bytes'] for s in members),coverage=manifest['coverage'],requests=request_count),ensure_ascii=False))
