namespace PathReviewV19 {
using System;using System.Text;using System.Text.Json;using System.Collections.Generic;using System.Linq;using System.Globalization;using System.Security.Cryptography;
public sealed class UnitMap {public int DecodedIndex{get;set;}public int RawStart{get;set;}public int RawEnd{get;set;}public int ByteStart{get;set;}public int ByteEnd{get;set;}}
public sealed class Finding {
 public string Kind{get;set;}public string Context{get;set;}public string RuleId{get;set;}public string Confidence{get;set;}public string Reason{get;set;}public bool NeedsReview{get;set;}public string Decision{get;set;}
 public int RawStart{get;set;}public int RawEnd{get;set;}public int ByteStart{get;set;}public int ByteEnd{get;set;}public int DecodedStart{get;set;}public int DecodedEnd{get;set;}
 public string ParsedValue{get;set;}public string[] Flags{get;set;}public string DuplicateOf{get;set;}public string Id{get;set;}
}
public sealed class Token {
 public string Id{get;set;}public int RawStart{get;set;}public int RawEnd{get;set;}public string RawToken{get;set;}public string ParsedString{get;set;}public bool HasEscapes{get;set;}public string PropertyContext{get;set;}
 public List<UnitMap> Mapping{get;set;}=new List<UnitMap>();public List<Finding> SemanticSpans{get;set;}=new List<Finding>();
}
public sealed class Result {
 public string SampleId{get;set;}public string OriginalText{get;set;}public string RawBytesBase64{get;set;}public string InputSHA256{get;set;}public string Container{get;set;}public string Decision{get;set;}public string Error{get;set;}
 internal int NextId;public List<Finding> Spans{get;set;}=new List<Finding>();public List<Token> Tokens{get;set;}=new List<Token>();
}
public static class Classifier {
 static readonly UTF8Encoding Utf=new UTF8Encoding(false,true);
 static bool AsciiLetter(char c)=>(c>='a'&&c<='z')||(c>='A'&&c<='Z');
 static bool SecretKey(string s)=>new[]{"password","passwd","token","api_key","apikey","secret","authorization","private_key"}.Contains(s.ToLowerInvariant());
 static bool Traversal(string s)=>s.Replace('\\','/').Split('/').Contains("..");
 static int ByteAt(string s,int c)=>Utf.GetByteCount(s.AsSpan(0,c));
 static void MapChar(Token t,string original,int rawStart,int rawEnd,int decoded){t.Mapping.Add(new UnitMap{DecodedIndex=decoded,RawStart=rawStart,RawEnd=rawEnd,ByteStart=ByteAt(original,rawStart),ByteEnd=ByteAt(original,rawEnd)});}
 static Finding Make(Result r,Token t,string value,int start,int end,string kind,string rule,string context,string reason,params string[] flags){
  int a,b;if(t==null){a=start;b=end;}else if(start==end){a=t.RawStart+1;b=a;}else{a=t.Mapping[start].RawStart;b=t.Mapping[end-1].RawEnd;}
  bool review=kind=="UNKNOWN"||kind=="WINDOWS_DRIVE_PATH"||kind=="UNC_PATH"||kind=="CREDENTIAL_CANDIDATE"||flags.Length>0;
  return new Finding{Id="f"+(r.NextId++).ToString(CultureInfo.InvariantCulture),Kind=kind,Context=context,RuleId=rule,Confidence=kind=="UNKNOWN"?"UNRESOLVED":"SYNTAX_CLASSIFICATION",Reason=reason,NeedsReview=review,Decision=kind=="UNKNOWN"?"BLOCK_UNKNOWN":review?"REVIEW_REQUIRED":"NO_FLAG_IN_SYNTHETIC_TEXT",RawStart=a,RawEnd=b,ByteStart=ByteAt(r.OriginalText,a),ByteEnd=ByteAt(r.OriginalText,b),DecodedStart=start,DecodedEnd=end,ParsedValue=value.Substring(start,end-start),Flags=flags};
 }
 static void Add(Result r,Token t,string value,int a,int b,string kind,string rule,string context,string reason,params string[] flags){var f=Make(r,t,value,a,b,kind,rule,context,reason,flags);if(t==null)r.Spans.Add(f);else t.SemanticSpans.Add(f);}
 static void One(Result r,Token t,string value,int a,int b,string context,bool credential=false){
  string s=value.Substring(a,b-a);if(s.Length==0)return;
  if(credential){Add(r,t,value,a,b,"CREDENTIAL_CANDIDATE","ASSIGNMENT_OR_FIELD_CONTEXT",context,"Synthetic value under credential-bearing syntax; candidate only");return;}
  var flags=new List<string>();if(Traversal(s))flags.Add("TRAVERSAL_CANDIDATE");
  int colon=s.IndexOf(':');bool scheme=colon>1&&AsciiLetter(s[0])&&s.Take(colon).All(c=>Char.IsLetterOrDigit(c)||c=='+'||c=='-'||c=='.');
  if(scheme&&(s.Substring(colon).StartsWith("://",StringComparison.Ordinal)||s.StartsWith("mailto:",StringComparison.OrdinalIgnoreCase))){
   Uri uri;if(!s.Any(Char.IsControl)&&!s.Any(Char.IsWhiteSpace)&&Uri.TryCreate(s,UriKind.Absolute,out uri)&&(uri.Scheme=="mailto"||uri.IsFile||!String.IsNullOrEmpty(uri.Host))){
    if(uri.IsFile)flags.Add("LOCAL_FILE_URI_CANDIDATE");
    if(Traversal(Uri.UnescapeDataString(uri.AbsolutePath)))flags.Add("TRAVERSAL_CANDIDATE");
    Add(r,t,value,a,b,"URI","SYSTEM_URI_ABSOLUTE_STRUCTURED",context,"URI parsed before any drive/path classification",flags.Distinct().ToArray());
    if(!String.IsNullOrEmpty(uri.UserInfo)){int p=s.IndexOf("//",StringComparison.Ordinal)+2;int q=s.IndexOf('@',p);if(q>p)Add(r,t,value,a+p,a+q,"CREDENTIAL_CANDIDATE","URI_USERINFO_CONTEXT",context,"User-info candidate; no leakage conclusion");}
   }else Add(r,t,value,a,b,"UNKNOWN","URI_PARSE_ERROR",context,"Scheme-like token is not a valid complete URI");
   return;
  }
  if(s.Length>=3&&AsciiLetter(s[0])&&s[1]==':'&&(s[2]=='\\'||s[2]=='/')){
   if(s.Length==3){Add(r,t,value,a,b,"ORDINARY_TEXT","AMBIGUOUS_BARE_DRIVE_FRAGMENT",context,"Bare s:/-style fragment is insufficient path structure");return;}
   if(s.Any(c=>Char.IsControl(c)||"<>\u0022|?*".Contains(c))){Add(r,t,value,a,b,"UNKNOWN","DRIVE_STRUCTURE_INVALID",context,"Invalid character in drive candidate");return;}
   if(s.IndexOf(':',2)>=0)flags.Add("ADS_CANDIDATE");
   Add(r,t,value,a,b,"WINDOWS_DRIVE_PATH","DRIVE_TOKEN_BOUNDARY_AND_COMPONENTS",context,"Drive-qualified candidate; no filesystem lookup",flags.ToArray());return;
  }
  if(s.StartsWith("\\\\",StringComparison.Ordinal)){
   string[] p=s.Substring(2).Split('\\');
   bool valid=p.Length>=2&&p[0].Length>0&&p[1].Length>0&&p[0]!="."&&p[0]!="?"&&p.Take(2).All(x=>x.All(c=>!Char.IsControl(c)&&!"<>:\"/|?*".Contains(c)));
   if(valid)Add(r,t,value,a,b,"UNC_PATH","UNC_SERVER_SHARE_COMPONENTS",context,"UNC server/share syntax; no filesystem lookup",flags.ToArray());
   else Add(r,t,value,a,b,"UNKNOWN","UNC_STRUCTURE_INCOMPLETE",context,"Double-backslash fragment lacks a valid server/share");
   return;
  }
  if(flags.Contains("TRAVERSAL_CANDIDATE")){Add(r,t,value,a,b,"UNKNOWN","RELATIVE_TRAVERSAL_CANDIDATE",context,"Traversal requires surrounding archive/path policy",flags.ToArray());return;}
  Add(r,t,value,a,b,"ORDINARY_TEXT","NO_STRUCTURED_CANDIDATE",context,"No absolute path, URI or credential syntax");
 }
 static void Lex(Result r,Token t,string value,int begin,int end,string context,string field=null){
  if(SecretKey(field??"")&&end>begin){One(r,t,value,begin,end,context,true);return;}
  bool pending=false;int i=begin;
  while(i<end){
   if(Char.IsWhiteSpace(value[i])||"(),;=".Contains(value[i])){i++;continue;}
   if(value.AsSpan(i,end-i).StartsWith("-----BEGIN ",StringComparison.Ordinal)){int mark=value.IndexOf("PRIVATE KEY-----",i,StringComparison.Ordinal);if(mark>=0){int q=mark+"PRIVATE KEY-----".Length;One(r,t,value,i,q,context,true);i=q;continue;}}
   if(value[i]=='"'||value[i]=='\''){char quote=value[i];int q=value.IndexOf(quote,i+1);if(q<0||q>=end){Add(r,t,value,i,end,"UNKNOWN","UNTERMINATED_TEXT_QUOTE",context,"Quoted text has no closing delimiter");return;}One(r,t,value,i+1,q,context,pending);pending=false;i=q+1;continue;}
   if(t==null&&(value[i]=='{'||value[i]=='[')){
    int q=JsonEnd(value,i,end);if(q<0){Add(r,t,value,i,end,"UNKNOWN","FORMAT_PARSE_ERROR",context,"Incomplete embedded JSON; not heuristically unescaped");return;}
    Json(r,value.Substring(i,q-i),i);i=q;continue;
   }
   bool uriLead=false;int lead=value.IndexOf("://",i,StringComparison.Ordinal);if(lead>i&&lead<end&&value.Substring(i,lead-i).All(c=>Char.IsLetterOrDigit(c)||c=='+'||c=='-'||c=='.'))uriLead=true;
   int j=i;while(j<end&&!Char.IsWhiteSpace(value[j])&&value[j]!='"'&&value[j]!='\''&&(uriLead||!"(){}[]".Contains(value[j])))j++;
   if(j==i){Add(r,t,value,i,i+1,"ORDINARY_TEXT","PUNCTUATION",context,"Text delimiter");i++;continue;}
   while(j>i&&".,;".Contains(value[j-1]))j--;
   if(j==i){i++;continue;}
   string word=value.Substring(i,j-i);int eq=word.IndexOf('=');
   if(eq>0&&!word.Contains("://",StringComparison.Ordinal)){
    string key=word.Substring(0,eq);One(r,t,value,i,i+eq,context);pending=SecretKey(key);
    if(eq+1<word.Length){One(r,t,value,i+eq+1,j,context,pending);pending=false;}
   }else if(word.Equals("Bearer",StringComparison.OrdinalIgnoreCase)){One(r,t,value,i,j,context);pending=true;}
   else{One(r,t,value,i,j,context,pending);pending=false;}
   i=j;if(i<end&&".,;".Contains(value[i]))i++;
  }
 }
 static int JsonEnd(string s,int start,int end){int depth=0;bool str=false,escape=false;for(int i=start;i<end;i++){char c=s[i];if(str){if(escape)escape=false;else if(c=='\\')escape=true;else if(c=='"')str=false;}else{if(c=='"')str=true;else if(c=='{'||c=='[')depth++;else if(c=='}'||c==']'){depth--;if(depth==0)return i+1;}}}return -1;}
 static Token MapToken(Result r,string raw,int globalStart,string parsed,string property){
  var t=new Token{Id="t"+r.Tokens.Count,RawStart=globalStart,RawEnd=globalStart+raw.Length,RawToken=raw,ParsedString=parsed,PropertyContext=property,HasEscapes=raw.Contains('\\')};
  var b=new StringBuilder();int i=1,k=0;
  while(i<raw.Length-1){int a=i;char c=raw[i++];string decoded;
   if(c=='\\'){char e=raw[i++];if(e=='u'){decoded=((char)Int32.Parse(raw.Substring(i,4),NumberStyles.HexNumber,CultureInfo.InvariantCulture)).ToString();i+=4;}else decoded=e switch{'"'=>"\"",'\\'=>"\\",'/'=>"/",'b'=>"\b",'f'=>"\f",'n'=>"\n",'r'=>"\r",'t'=>"\t",_=>throw new FormatException("JSON_ESCAPE_MAPPING")};}
   else if(Char.IsHighSurrogate(c)&&i<raw.Length-1&&Char.IsLowSurrogate(raw[i])){decoded=new string(new[]{c,raw[i++]});}
   else decoded=c.ToString();
   b.Append(decoded);foreach(char unused in decoded)MapChar(t,r.OriginalText,globalStart+a,globalStart+i,k++);
  }
  if(b.ToString()!=parsed||t.Mapping.Count!=parsed.Length)throw new FormatException("PARSER_MAPPING_DIVERGENCE");
  return t;
 }
 static void Json(Result r,string json,int globalStart){
  try{
   byte[] bytes=Utf.GetBytes(json);using(var document=JsonDocument.Parse(bytes)){}
   var reader=new Utf8JsonReader(bytes);string property=null;
   while(reader.Read())if(reader.TokenType==JsonTokenType.String||reader.TokenType==JsonTokenType.PropertyName){
    int bs=(int)reader.TokenStartIndex,be=bs+reader.ValueSpan.Length+2;int cs=Utf.GetString(bytes,0,bs).Length,ce=Utf.GetString(bytes,0,be).Length;
    string parsed=reader.GetString();bool key=reader.TokenType==JsonTokenType.PropertyName;
    var token=MapToken(r,json.Substring(cs,ce-cs),globalStart+cs,parsed,key?"PROPERTY_NAME":property);r.Tokens.Add(token);
    if(parsed.Length==0)Add(r,token,parsed,0,0,"ORDINARY_TEXT","EMPTY_JSON_STRING","JSON_PARSED_STRING","Empty parsed string");else Lex(r,token,parsed,0,parsed.Length,key?"JSON_PROPERTY_NAME":"JSON_PARSED_STRING",key?null:property);
    if(token.HasEscapes){var f=new Finding{Id="serialized"+token.Id,Kind="JSON_ESCAPED_FRAGMENT",Context="JSON_RAW_TOKEN",RuleId="JSON_PARSER_VALIDATED_SERIALIZATION",Confidence="SYNTAX_CLASSIFICATION",Reason="Serialized token only; decoded semantics reported separately",Decision="NO_AUTOMATIC_PATH_OR_LEAKAGE_CONCLUSION",NeedsReview=false,RawStart=token.RawStart,RawEnd=token.RawEnd,ByteStart=ByteAt(r.OriginalText,token.RawStart),ByteEnd=ByteAt(r.OriginalText,token.RawEnd),DecodedStart=0,DecodedEnd=parsed.Length,ParsedValue=parsed,Flags=Array.Empty<string>()};r.Spans.Add(f);}
    else r.Spans.AddRange(token.SemanticSpans);
    if(key)property=parsed;
   }
  }catch(Exception e)when(e is JsonException||e is FormatException||e is InvalidOperationException){
   Add(r,null,r.OriginalText,globalStart,globalStart+json.Length,"UNKNOWN","FORMAT_PARSE_ERROR","JSON_CONTAINER","JSON parser/mapping failed; no fallback unescape");
   r.Error="FORMAT_PARSE_ERROR:"+e.GetType().Name;
  }
 }
 public static IEnumerable<Finding> All(Result r)=>r.Spans.Concat(r.Tokens.SelectMany(t=>t.SemanticSpans)).Distinct();
 public static string[] Labels(Result r)=>All(r).Select(x=>x.Kind).Distinct().OrderBy(x=>x,StringComparer.Ordinal).ToArray();
 public static Result Analyze(string sampleId,byte[] bytes,string format="auto"){
  var r=new Result{SampleId=sampleId,RawBytesBase64=Convert.ToBase64String(bytes),InputSHA256=Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant(),Container=format};
  try{r.OriginalText=Utf.GetString(bytes);}catch(DecoderFallbackException){r.Error="FORMAT_PARSE_ERROR:INVALID_UTF8";r.Spans.Add(new Finding{Kind="UNKNOWN",RuleId="FORMAT_PARSE_ERROR",Context="BYTE_CONTAINER",RawStart=0,RawEnd=0,ByteStart=0,ByteEnd=bytes.Length,NeedsReview=true,Decision="BLOCK_UNKNOWN",Flags=Array.Empty<string>()});r.Decision="BLOCK_UNKNOWN";return r;}
  string text=r.OriginalText;string trim=text.TrimStart();
  if(bytes.Length>65536){Add(r,null,text,0,text.Length,"UNKNOWN","INPUT_CAP","BYTE_CONTAINER","Synthetic input cap exceeded");}
  else if(format!="text"&&format!="auto"&&format!="json"){Add(r,null,text,0,text.Length,"UNKNOWN","UNKNOWN_CONTAINER_HINT","CONTAINER","Unsupported container hint");}
  else if(format=="json"||(format=="auto"&&trim.Length>0&&"{[\"".Contains(trim[0])))Json(r,text,0);
  else Lex(r,null,text,0,text.Length,"PLAIN_TEXT");
  if(!r.Spans.Any()&&!r.Tokens.Any())Add(r,null,text,0,text.Length,"ORDINARY_TEXT","EMPTY_OR_WHITESPACE","PLAIN_TEXT","No structured token");
  var seen=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
  foreach(var f in All(r)){if(f.Kind=="WINDOWS_DRIVE_PATH"||f.Kind=="UNC_PATH"){string key=f.Kind+"|"+f.ParsedValue.Replace('\\','/');if(seen.TryGetValue(key,out var first)){f.DuplicateOf=first;f.Flags=f.Flags.Concat(new[]{"CASE_INSENSITIVE_DUPLICATE"}).ToArray();}else seen.Add(key,f.Id);}}
  r.Decision=All(r).Any(f=>f.Kind=="UNKNOWN")?"BLOCK_UNKNOWN":All(r).Any(f=>f.NeedsReview)?"REVIEW_REQUIRED":"NO_FLAG_IN_SYNTHETIC_TEXT";
  return r;
 }
}
}
