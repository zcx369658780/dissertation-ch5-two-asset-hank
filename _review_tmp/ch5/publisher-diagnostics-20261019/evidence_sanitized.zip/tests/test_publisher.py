"""Twelve required behavioral groups; all fixtures are newly synthetic."""
import hashlib
import json
import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from ch5_evidence_publisher import Publisher, Rejected, redact


class PublisherTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p = Publisher(ROOT, 'engineering', sys.argv[1] if len(sys.argv) > 1 else 'qualification')

    def test_T01_nonzero_keeps_raw_and_readable_public(self):
        r = self.p.helper('nonzero')
        self.assertEqual(r['exit'], 7)
        self.assertIn(bytes([67, 58, 92]) + b'SYNTHETIC_PRIVATE', self.p.raw(r, 'stderr'))
        self.assertIn('fatal: synthetic repository', r['public_stderr'])
        self.assertNotIn('SYNTHETIC_PRIVATE', r['public_stderr'])

    def test_T02_binary_and_control_bytes(self):
        r = self.p.helper('binary')
        self.assertEqual(self.p.raw(r, 'stdout'), bytes(range(256)))
        self.assertIn('\\x00', r['public_stderr'])
        self.assertNotIn('\x1b', r['public_stderr'])

    def test_T03_zero_with_stderr(self):
        r = self.p.helper('warning')
        self.assertEqual(r['exit'], 0)
        self.assertGreater(r['streams']['stderr']['bytes'], 0)
        self.assertEqual(r['state'], 'COMPLETE')

    def test_T04_tokenized_unicode_spaces_quotes(self):
        args = ['a b', '\u4e2d\u6587', '"inert quoted"', 'literal;$(no shell)']
        r = self.p.helper('args', args)
        self.assertEqual(json.loads(self.p.raw(r, 'stdout')), args)

    def test_T05_dual_stream_no_deadlock_and_limit(self):
        r = self.p.helper('large')
        self.assertEqual(self.p.raw(r, 'stdout'), b'A' * 262144)
        self.assertEqual(self.p.raw(r, 'stderr'), b'B' * 262144)
        limited = self.p.helper('large', stream_limit=4096)
        self.assertEqual(limited['state'], 'INCOMPLETE_OUTPUT_LIMIT')
        self.assertTrue(limited['reaped'])
        self.assertLessEqual(limited['streams']['stdout']['bytes'], 4096)

    def test_T06_owned_timeout_partial_reaped(self):
        r = self.p.helper('timeout', timeout=0.5)
        self.assertEqual(r['state'], 'INCOMPLETE_TIMEOUT')
        self.assertIn(b'partial', self.p.raw(r, 'stdout'))
        self.assertTrue(r['reaped'])

    def test_T07_log_failure_blocks_publication(self):
        p = Publisher(ROOT, 'engineering', self.p.attempt + '-log-failure')
        p.simulate_log_failure = True
        with self.assertRaises(Rejected):
            p.helper('warning')
        self.assertTrue(p.blocked)
        with self.assertRaises(Rejected):
            p.package([])

    def test_T08_redaction_preserves_private_identity(self):
        r = self.p.helper('redaction')
        raw = self.p.raw(r, 'stderr')
        self.assertIn(b'FAKE_SYNTHETIC_CREDENTIAL', raw)
        self.assertNotIn('FAKE_SYNTHETIC_CREDENTIAL', r['public_stderr'])
        self.assertIn('error:', r['public_stderr'])
        self.assertEqual(hashlib.sha256(raw).hexdigest(), r['streams']['stderr']['sha256'])

    def test_T09_config_lease_and_payload_rejected(self):
        for config in ({}, {'destination': 'https://invalid.example/repo'}, {'branch': 'main'}):
            with self.assertRaises(Rejected):
                self.p.validate_profile(config)
        lease = self.p.lease('synthetic-check')
        self.p.consume(lease)
        with self.assertRaises(Rejected):
            self.p.consume(lease)
        with self.assertRaises(Rejected):
            self.p.check_payload(b'changed', {'bytes': 3, 'sha256': '0' * 64})
        with self.assertRaises(Rejected):
            self.p.helper('../outside')
        with self.assertRaises(Rejected):
            self.p.package(['../raw_private/not-allowed'])

    def test_T10_fake_binary_roundtrip(self):
        self.__class__.fake = self.p.selftest()
        self.assertEqual(self.fake['verified_files'], 3)
        self.assertTrue(self.fake['sole_parent_verified'])
        self.assertTrue(self.fake['member_hashes_verified'])

    def test_T11_cleanup_preserves_sentinel_and_history(self):
        r = self.__class__.fake
        self.assertEqual(r['cleanup_deleted'], 3)
        self.assertTrue(r['sentinel_preserved'])
        self.assertTrue(r['history_preserved'])
        self.assertTrue(r['ref_readback_verified'])

    def test_T12_lock_profiles_stage_resources(self):
        lock = self.p.verify_lock()
        self.assertEqual(set(lock['profiles']), {'test', 'delivery'})
        self.assertTrue(self.p.limit_would_reject('accounted_process_starts', 100000))
        self.assertGreater(self.p.ledger()['engineering']['direct_starts'], 0)
        changed = json.loads(json.dumps(lock['profiles']['delivery']))
        changed['parent'] = '0' * 40
        with self.assertRaises(Rejected):
            self.p.validate_profile(changed)


if __name__ == '__main__':
    attempt = sys.argv[1] if len(sys.argv) > 1 else 'qualification'
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(PublisherTests)
    class Results(unittest.TextTestResult):
        rows = []
        def addSuccess(self, test):
            self.rows.append({'test': test.id(), 'status': 'PASS'})
            super().addSuccess(test)
        def addFailure(self, test, err):
            self.rows.append({'test': test.id(), 'status': 'FAIL', 'error': self._exc_info_to_string(err, test)})
            super().addFailure(test, err)
        def addError(self, test, err):
            self.rows.append({'test': test.id(), 'status': 'ERROR', 'error': self._exc_info_to_string(err, test)})
            super().addError(test, err)
    outcome = unittest.TextTestRunner(verbosity=2, resultclass=Results).run(suite)
    path = ROOT / 'attempts' / attempt
    path.mkdir(exist_ok=True)
    (path / 'test_results.json').write_text(json.dumps(Results.rows, indent=2), encoding='utf-8')
    raise SystemExit(0 if outcome.wasSuccessful() else 1)
