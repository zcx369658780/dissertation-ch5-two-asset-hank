## firm.py:evaluate_firm

def evaluate_firm(
    province: Mapping[str, float],
    kt_supply: float,
    lt_supply: float,
    params: Mapping[str, float],
    *, mainline: bool = False,
) -> FirmResult:
    """Evaluate the MATLAB steady-state branch without solving any model.

    ``lt_supply`` is destination firm labor.  Household aggregate ``Lt`` is
    intentionally not read from ``province``.
    """

    kt_supply = float(kt_supply)
    lt = float(lt_supply)
    if not isfinite(kt_supply) or not isfinite(lt):
        raise ValueError("Kt_supply and Lt_supply must be finite")
    gov_inv = _finite(province, "GovInv")
    kt = kt_supply + gov_inv  # HANK_firm.m:14
    if kt <= 0.0 or lt <= 0.0:
        raise ValueError("firm Kt and destination Lt_supply must be positive")

    alpha = _finite(province, "alpha")
    zt = _finite(province, "Zt")
    if not 0.0 < alpha < 1.0 or zt <= 0.0:
        raise ValueError("firm alpha must be in (0,1) and Zt must be positive")
    epsilon = _finite(params, "epsilon")
    theta = _finite(params, "theta")
    delta = _finite(params, "delta")
    if epsilon == 0.0:
        raise ValueError("epsilon must be nonzero")

    pit = _finite(province, "pit")
    kt_previous = _finite(province, "Kt_prev")
    lt_previous = _finite(province, "Lt_prev")
    zt_previous = _finite(province, "Zt_1")
    pit_previous = _finite(province, "pit_1")
    prior_rk = _finite(province, "rk")
    corptau = _finite(province, "corptau")
    at_tax = _finite(province, "AtTax")
    tau = _finite(province, "tau")
    transfer = _finite(province, "Tt")

    yt = zt * kt**alpha * lt ** (1.0 - alpha)  # line 30
    mstar = 1.0 - 1.0 / epsilon
    mt = (
        (
            prior_rk
            - (zt_previous - zt) / zt
            - alpha * (kt_previous - kt) / kt
            - (1.0 - alpha) * (lt_previous - lt) / lt
        )
        * pit
        * theta
        / epsilon
        + mstar
        - (pit - pit_previous) * theta / epsilon
    )  # line 35, steady-state branch
    knratio = kt / lt
    wt0 = mt * (1.0 - alpha) * zt * knratio**alpha
    rk = mt * alpha / (kt / yt)
    thetat = theta / 2.0 * pit**2 * yt
    investment = kt - kt_previous + delta * kt
    profit = (1.0 - mt) * yt - thetat
    if profit < 0.0:  # lines 48-51
        profit = 0.0
    corporate_tax = profit * corptau
    ra0 = rk - delta + profit * (1.0 - corptau) / kt

    ramin = _finite(province, "ramin")
    ramax = _finite(province, "ramax")
    wjtmin = _finite(province, "wjtmin")
    wjtmax = _finite(province, "wjtmax")
    if ramin > ramax or wjtmin > wjtmax:
        raise ValueError("firm clipping minima must not exceed maxima")
    if ra0 > ramax:  # preserve lines 57-65 ordering
        corporate_tax += (ra0 - ramax) * kt
        ra = ramax
    elif ra0 < ramin:
        corporate_tax -= (ramin - ra0) * kt
        ra = ramin
    else:
        ra = ra0
    if wt0 < wjtmin:  # preserve lines 66-74 ordering
        corporate_tax -= (wjtmin - wt0) * lt
        wjt = wjtmin
    elif wt0 > wjtmax:
        corporate_tax += (wt0 - wjtmax) * lt
        wjt = wjtmax
    else:
        wjt = wt0

    if mainline:
        population = _finite(province, "N")
        if population <= 0:
            raise ValueError("mainline fiscal population must be positive")
        govinc = corporate_tax + tau * wt0 * lt + population * at_tax + gov_inv * ra - population * transfer
    else:
        govinc = corporate_tax + lt * tau + at_tax + gov_inv * ra - transfer
    result = FirmResult(
        Kt=kt, Lt=lt, Yt=yt, mt=mt, KNratio=knratio, wt0=wt0, wjt=wjt,
        rk=rk, Thetat=thetat, It=investment, PIt=profit, Corptax=corporate_tax,
        ra0=ra0, ra=ra, Govinc=govinc,
    )
    if not all(isfinite(value) for value in asdict(result).values()):
        raise ValueError("firm arithmetic produced a non-finite output")
    return result

## migration_labor.py:reconstruct_mainline_labor

def reconstruct_mainline_labor(*, consumption, population, gross_wages, destination_taxes,
                               phi, sigma, gamma_c, phi_l):
    """Original average-Ct reconstruction, corrected destination tax and no extra N."""
    c, n, w, tax = (np.asarray(x, dtype=float) for x in
                    (consumption, population, gross_wages, destination_taxes))
    phi, sigma = np.asarray(phi, dtype=float), np.asarray(sigma, dtype=float)
    count = len(c)
    if (c.shape != (count,) or n.shape != c.shape or w.shape != c.shape or tax.shape != c.shape
            or phi.shape != (count,count) or sigma.shape != phi.shape
            or not all(np.isfinite(x).all() for x in (c,n,w,tax,phi,sigma))
            or np.any(c <= 0) or np.any(n <= 0) or np.any(phi <= 0)):
        raise ValueError('mainline labor axes/domain invalid')
    q = w[:,None] * (1-tax[:,None]-sigma)
    if np.any(q < 0) or gamma_c <= 0 or phi_l <= 0:
        raise ValueError('mainline labor net price/domain invalid')
    matrix = c[None,:]**(-gamma_c/phi_l) * (q/phi)**(1/phi_l) * n[None,:]
    if not np.isfinite(matrix).all():
        raise ValueError('nonfinite mainline labor')
    return MigrationLaborResult(matrix, np.sum(matrix,axis=1))

## wage.py:composite_household_wages

def composite_household_wages(
    provinces: Sequence[Mapping[str, float]],
    firm_wages: Sequence[float],
    phi_mat: Sequence[Sequence[float]],
    sigmau_mat: Sequence[Sequence[float]],
    *,
    phi_l: float,
    alphal: float,
) -> tuple[float, ...]:
    """Return one composite wage per origin household province.

    Rows are destinations and columns are origins.  The MATLAB wage formula
    intentionally indexes ``tau`` by destination, unlike ``Lt_seperate``.
    """

    count = len(provinces)
    if count < 1 or len(firm_wages) != count:
        raise ValueError("provinces and firm_wages must have the same nonzero length")
    phi = np.asarray(phi_mat, dtype=float)
    sigma = np.asarray(sigmau_mat, dtype=float)
    wages = np.asarray(firm_wages, dtype=float)
    if phi.shape != (count, count) or sigma.shape != (count, count):
        raise ValueError("phi_mat and sigmau_mat must have shape (destination, origin)")
    if not np.isfinite(phi).all() or not np.isfinite(sigma).all() or not np.isfinite(wages).all():
        raise ValueError("wage inputs must be finite")
    if np.any(phi <= 0.0):
        raise ValueError("phi_mat labor-disutility entries must be positive")
    phi_l = float(phi_l)
    alphal = float(alphal)
    if not isfinite(phi_l) or phi_l <= 0.0 or not isfinite(alphal) or alphal <= 0.0:
        raise ValueError("phi_l and alphal must be finite and positive")
    taxes = []
    for province in provinces:
        try:
            tax = float(province["tau"])
        except KeyError as exc:
            raise ValueError("every province requires destination tau") from exc
        if not isfinite(tax):
            raise ValueError("destination tau must be finite")
        taxes.append(tax)

    exponent = 1.0 + 1.0 / phi_l
    outer_exponent = phi_l / (1.0 + phi_l)
    output: list[float] = []
    for origin in range(count):
        total = 0.0
        for destination in range(count):
            divisor = phi[destination, origin]
            base = (
                wages[destination]
                * (1.0 - taxes[destination] - sigma[destination, origin])
                / divisor
            )
            if base < 0.0:
                raise ValueError("wage_caculate source power base would be negative/non-real")
            term = divisor * base**exponent
            if not isfinite(term):
                raise ValueError("wage_caculate term must be finite")
            total += term
        if total < 0.0:
            raise ValueError("wage_caculate outer power base would be negative/non-real")
        value = alphal ** (-outer_exponent) * total**outer_exponent
        if not isfinite(value) or value < 0.0:
            raise ValueError("wage_caculate produced an invalid composite wage")
        output.append(value)
    return tuple(output)

## wage.py:mainline_phi

def mainline_phi(pgdp_reference):
    """Frozen reference, destination rows/origin columns, richer destination preferred."""
    p = np.asarray(pgdp_reference, dtype=float)
    if p.ndim != 1 or not np.isfinite(p).all() or np.any(p <= 0):
        raise ValueError('pgdp reference must be a positive finite vector')
    return 1.0 + 0.3 * (p[None, :] - p[:, None]) / (p[None, :] + p[:, None])

## wage.py:mainline_effective_wages

def mainline_effective_wages(gross_wages, destination_taxes, phi, sigma, *, phi_l, alphal):
    """Net composite wage; feed to HA with tau_HA=0 (no second deduction)."""
    wages, taxes = np.asarray(gross_wages, dtype=float), np.asarray(destination_taxes, dtype=float)
    provinces = tuple({'tau': float(t)} for t in taxes)
    return np.asarray(composite_household_wages(provinces, wages, phi, sigma,
                                               phi_l=phi_l, alphal=alphal))

## steady_state.py:_adapt

def _adapt(
    states: list[dict[str, object]], max_nk_gap: float, steady_state: bool
) -> tuple[list[dict[str, object]], tuple[AdaptiveAction, ...]]:
    actions: list[AdaptiveAction] = []
    allow = max_nk_gap < 0.1 and steady_state
    for state in states:
        zt_before = float(state["Zt"])
        gov_before = float(state["GovInv"])
        zt_after = zt_before
        gov_after = gov_before
        gov_action = "NONE"
        zt_adjusted = False
        if allow:
            discrepancy = float(state["Yt"]) / float(state["Yt0"]) - 1.0
            if discrepancy > 0.01 or discrepancy < -0.01:
                zt_after = (
                    float(state["Yt0"])
                    * float(state["Kt"]) ** (-float(state["alpha"]))
                    * float(state["Lt"]) ** (float(state["alpha"]) - 1.0)
                )
                state["Zt"] = zt_after
                zt_adjusted = True
            if float(state["ra"]) < float(state["ramin"]) + 0.02:
                gov_after = gov_before * 0.9
                gov_action = "LOW_RA_DECREASE_0P9"
                state["GovInv"] = gov_after
            elif float(state["ra"]) > float(state["ramax"]) - 0.02:
                gov_after = gov_before * 1.1
                gov_action = "HIGH_RA_INCREASE_1P1"
                state["GovInv"] = gov_after
        actions.append(AdaptiveAction(
            province=str(state["name"]), zt_adjusted=zt_adjusted,
            zt_before=zt_before, zt_after=zt_after, govinv_action=gov_action,
            govinv_before=gov_before, govinv_after=gov_after,
        ))
    return states, tuple(actions)

## steady_state.py:mainline_outer_diagnostics

def mainline_outer_diagnostics(states, tkn_previous, reg_threshold=1e-9):
    """Outer iteration convergence is distinct from data-target verification."""
    nk = np.array([abs(s['KNratio']/tkn_previous[i]-1) for i,s in enumerate(states)])
    yt = np.array([abs(s['Yt']/s['Yt_1']-1) for s in states])
    target = np.array([abs(s['Yt']/s['Yt0']-1) for s in states])
    finite = np.isfinite(nk).all() and np.isfinite(yt).all() and np.isfinite(target).all()
    boundary = any(s['ra'] <= s['ramin'] or s['ra'] >= s['ramax'] for s in states)
    passed = bool(finite and np.max(nk)<reg_threshold and np.max(yt)<reg_threshold
                  and all(s['convergent'] for s in states) and not boundary)
    return {'OUTER_ITERATION_CONVERGED':passed,'nk_gap':nk.tolist(),'yt_gap':yt.tolist(),
            'target_gap':target.tolist(),'ra_boundary':boundary,
            'TARGET_CALIBRATION_VERIFIED':False}

## stationary_runtime.py:mainline_initial_states

def mainline_initial_states(fixture):
    """Only the frozen synthetic fixture; no cache or annual-data reader."""
    from .wage import mainline_phi, mainline_effective_wages
    p=fixture['parameters']
    wages=mainline_effective_wages(fixture['firm_gross_wage_initial'],fixture['destination_tax_tau'],
        mainline_phi(fixture['pgdp_reference']),fixture['migration_wedge_destination_origin'],
        phi_l=p['phi_l'],alphal=p['alphal'])
    states=[]
    mapping={'N':'population_N','tau':'destination_tax_tau','corptau':'corporate_tax_rate',
        'GovInv':'initial_GovInv','At':'initial_private_assets_At_per_person',
        'Bt':'initial_liquid_assets_Bt_per_person','Ct':'initial_consumption_Ct_per_person',
        'Lt_HA':'initial_household_Lt_per_person','Kt_prev':'initial_firm_Kt_previous',
        'Lt_prev':'initial_firm_Lt_previous','Yt':'initial_Yt_previous','Yt0':'synthetic_target_Yt0',
        'alpha':'alpha','Zt':'Zt','Zt_1':'Zt_previous','pit':'pit','pit_1':'pit_previous',
        'rk':'initial_rk','Tt':'transfer_Tt_per_person','rb_gap':'borrowing_rate_gap',
        'rah':'initial_household_rah','ra':'initial_ra_used','wjt_gross':'firm_gross_wage_initial',
        'ra0_raw_previous':'initial_lagged_raw_ra0_by_destination'}
    for i,name in enumerate(fixture['province_order']):
        state={key:float(fixture[field][i]) for key,field in mapping.items()}
        state.update(name=name,rb=float(fixture['initial_rb']),w_eff=float(wages[i]),
            Lt=float(fixture['initial_firm_Lt_previous'][i]),Kt=float(fixture['initial_firm_Kt_previous'][i]),
            Lt_firm_ss=float(fixture['initial_firm_Lt_previous'][i]),
            ramin=0.02,ramax=0.09,wjtmin=0.8,wjtmax=1.3)
        states.append(state)
    return tuple(states)

## capital_network.py:build_bilateral_capital_network

def build_bilateral_capital_network(
    inputs: BilateralCapitalNetworkInputs,
) -> BilateralCapitalNetworkResult:
    """Build one conserved K1 portfolio matrix without calling any model runtime."""

    n = len(inputs.province_order)
    foreign = foreign_conditional_shares(ForeignConditionalShareInputs(
        province_order=inputs.province_order,
        distance_score_destination_origin=inputs.distance_score_destination_origin,
        lagged_return_score_by_destination=inputs.lagged_return_score_by_destination,
        beta_distance=inputs.beta_distance,
        beta_return=inputs.beta_return,
        lagged_return_provenance=inputs.lagged_return_provenance,
    ))
    theta = inputs.total_foreign_share_theta_by_origin
    shares = foreign.foreign_conditional_shares_destination_origin * theta[None, :]
    diagonal = np.arange(n)
    shares[diagonal, diagonal] = 1.0 - theta
    share_sums = np.sum(shares, axis=0)
    if not np.allclose(share_sums, 1.0, rtol=0.0, atol=CONSERVATION_TOLERANCE):
        raise RuntimeError("full portfolio shares do not conserve each origin column")

    with np.errstate(over="ignore", invalid="ignore"):
        wealth = inputs.illiquid_assets_per_capita_by_origin * inputs.population_by_origin
    if not np.all(np.isfinite(wealth)):
        raise ValueError("origin private wealth must remain finite")
    with np.errstate(over="ignore", invalid="ignore"):
        flows = shares * wealth[None, :]
    if not np.all(np.isfinite(flows)):
        raise ValueError("bilateral private-capital flows must remain finite")
    capital_sums = np.sum(flows, axis=0)
    destination_private = np.sum(flows, axis=1)
    domestic = np.diag(flows).copy()
    foreign_outflow = capital_sums - domestic
    foreign_inflow = destination_private - domestic
    with np.errstate(over="ignore", invalid="ignore"):
        rah = inputs.portfolio_return_by_destination @ shares
    if not np.all(np.isfinite(rah)):
        raise ValueError("household portfolio returns must remain finite")
    national_residual = float(np.sum(destination_private) - np.sum(wealth))

    scale = max(1.0, float(np.sum(wealth)))
    if not np.allclose(capital_sums, wealth, rtol=0.0, atol=CONSERVATION_TOLERANCE * scale):
        raise RuntimeError("bilateral capital does not conserve each origin wealth column")
    if abs(national_residual) > CONSERVATION_TOLERANCE * scale:
        raise RuntimeError("bilateral capital does not conserve national private wealth")
    expected_domestic = (1.0 - theta) * wealth
    expected_foreign = theta * wealth
    if not np.allclose(domestic, expected_domestic, rtol=0.0, atol=CONSERVATION_TOLERANCE * scale):
        raise RuntimeError("domestic retained private capital identity failed")
    if not np.allclose(foreign_outflow, expected_foreign, rtol=0.0, atol=CONSERVATION_TOLERANCE * scale):
        raise RuntimeError("foreign private-capital outflow identity failed")

    return BilateralCapitalNetworkResult(
        province_order=inputs.province_order,
        foreign_conditional_shares_destination_origin=foreign.foreign_conditional_shares_destination_origin,
        portfolio_shares_destination_origin=shares,
        origin_private_wealth=wealth,
        bilateral_private_capital_destination_origin=flows,
        destination_private_productive_capital=destination_private,
        domestic_retained_capital_by_origin=domestic,
        foreign_outflow_by_origin=foreign_outflow,
        foreign_inflow_by_destination=foreign_inflow,
        household_portfolio_return_by_origin=rah,
        share_column_sums=share_sums,
        capital_column_sums=capital_sums,
        national_private_capital_conservation_residual=national_residual,
        lagged_return_provenance=inputs.lagged_return_provenance,
    )
