"""Pure formula oracle. No production imports, HA, solver or historical trajectory access."""
import json, math
from pathlib import Path

def shares(raw, theta, dist, bd=2.0, br=.5):
    n=len(raw); offset=math.fsum(x-raw[0] for x in raw)/n; mean=raw[0]+offset; sd=math.sqrt(math.fsum(((x-raw[0])-offset)**2 for x in raw)/n)
    score=[0.0 if sd==0 else (x-mean)/sd for x in raw]
    S=[[0.0]*n for _ in range(n)]
    for i in range(n):
        js=[j for j in range(n) if j!=i]
        logits=[-bd*dist[j][i]+br*score[j] for j in js]; peak=max(logits)
        ex=[math.exp(x-peak) for x in logits]
        for j,v in zip(js,ex): S[j][i]=theta[i]*v/sum(ex)
        S[i][i]=1-theta[i]
    return S,score

def wage(w,tau,phi,sigma,phi_l=5.,alphal=1.):
    p=1+1/phi_l; q=phi_l/(1+phi_l)
    out=[]
    for i in range(len(w)):
        bases=[w[j]*(1-tau[j]-sigma[j][i])/phi[j][i] for j in range(len(w))]
        if min(bases)<0: raise ValueError("negative net power base")
        out.append(alphal**(-q)*sum(phi[j][i]*bases[j]**p for j in range(len(w)))**q)
    return out

def main():
    results=[]
    def near(a,b): assert math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12),(a,b)
    raw=[.384584,.427239]; S=[[.9,.2],[.1,.8]]
    rah=[sum(raw[j]*S[j][i] for j in range(2)) for i in range(2)]
    near(rah[0],.3888495);near(rah[1],.418708)
    results.append(dict(case="R1_report_rounded_same_S",tier="PURE_ALGEBRA_FROM_REVIEW_ROUNDED_INPUTS_NOT_NEW_TRAJECTORY",inputs=dict(raw=raw,S=S),rah=rah,used_payoff=[.09,.09]))
    raw3=[.1,.3,.6];theta=[.1,.2,.3];dist=[[0,1,2],[1,0,1],[2,1,0]]
    st,score=shares(raw3,theta,dist);W=[20,60,120]
    K=[sum(st[j][i]*W[i] for i in range(3)) for j in range(3)]
    r=[sum(raw3[j]*st[j][i] for j in range(3)) for i in range(3)]
    for i in range(3):near(sum(st[j][i] for j in range(3)),1)
    near(sum(K),sum(W));near(sum(W[i]*r[i] for i in range(3)),sum(K[j]*raw3[j] for j in range(3)))
    next_raw=[.6,.2,.1];sn,_=shares(next_raw,theta,dist)
    post=[sum(next_raw[j]*st[j][i] for j in range(3)) for i in range(3)]
    prepared=[sum(next_raw[j]*sn[j][i] for j in range(3)) for i in range(3)]
    assert any(abs(a-b)>1e-8 for a,b in zip(post,prepared))
    _,used_score=shares([.09]*3,theta,dist);assert used_score==[0,0,0]
    results.append(dict(case="R2_synthetic_same_S_conservation_lagged_rebind",S=st,score_raw=score,W=W,Kprivate=K,rah=r,post_turn_display_rah=post,next_prepare_rah=prepared,used_score_negative_control=used_score))
    tau=[.2,.25];phi=[[1,1.1],[.9,1]];sigma=[[0,.03],[.02,0]]
    wr=wage([4,5],tau,phi,sigma);wu=wage([1.3,1.3],tau,phi,sigma)
    scaled=wage([8,10],tau,phi,sigma)
    for a,b in zip(scaled,wr):near(a,2*b)
    single=wage([4],[.2],[[1]],[[0]])[0];near(single,3.2);assert not math.isclose(single*(1-.2),single)
    try:wage([1],[.8],[[1]],[[.3]])
    except ValueError:negative="EXPECTED_REJECTION"
    else:raise AssertionError("negative wedge accepted")
    results.append(dict(case="R3_synthetic_wage_homogeneity_once_tax",raw_w_eff=wr,used_w_eff=wu,single_destination_net=single,double_tax_wrong=single*.8,negative_base=negative,net_index_may_exceed_individual_wage="NON_NORMALIZED_CES_STYLE_INDEX_NOT_AUTOMATIC_UNIT_BUG"))
    for rawr,raw_w in [(.4,4),(-.2,.5),(.05,1.1)]:
        used=min(.09,max(.01,rawr));uw=min(1.3,max(1.,raw_w));K,L=100.,10.
        compensation=(rawr-used)*K+(raw_w-uw)*L
        baseline_tax=2.;N,AtTax,T,G=5.,.2,.1,20.;tax=.2*raw_w*L
        gov=baseline_tax+compensation+tax+N*AtTax+G*used-N*T
        near(gov,(baseline_tax+compensation)+tax+N*AtTax+G*used-N*T)
        results.append(dict(case="R4_synthetic_clip_compensation_fiscal",raw_ra=rawr,used_ra=used,raw_wt0=raw_w,wjt=uw,compensation=compensation,wageTax=tax,GovInc=gov))
    alpha,m,Y,delta,cap=.35,1.1,1500.,.025,.09
    req=m*alpha*Y/(cap+delta);near(m*alpha*Y/req-delta,cap)
    adaptation=[dict(max_KN_gap=g,allowed=g<.1,GovInv_next=110 if g<.1 else 100) for g in [.099,.1,.101]]
    z=1500*(2000**(-alpha))*(100**(alpha-1));near(z*2000**alpha*100**(1-alpha),1500)
    results.append(dict(case="R5_synthetic_fixed_others_Kreq_and_controller_gate",Kreq=req,ceteris_paribus_only=True,adaptation=adaptation,Zt_target=z))
    output={"status":"PURE_FORMULA_ORACLES_PASS","imports_production":False,"science_calls":0,"fixture_type":"EXPLICIT_ARBITRARY_ALGEBRA_CONSTANTS_EXCEPT_R1_REVIEW_ROUNDED_VALUES","results":results}
    Path(__file__).with_name("formula_oracle_results.json").write_text(json.dumps(output,indent=2),encoding="utf-8")
    print(json.dumps({"status":output["status"],"cases":len(results)}))
if __name__=="__main__":main()
