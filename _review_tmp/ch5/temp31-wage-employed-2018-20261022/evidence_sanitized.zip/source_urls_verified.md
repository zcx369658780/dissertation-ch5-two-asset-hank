# 来源可用性记录

**AH_NP_RELAY** [人社部中国就业网转载中工网](https://chinajob.mohrss.gov.cn/h5/c/2020-06-18/215688.shtml)；vintage=2020-06-18,2018基期；原站字节=True；HTTP=200；SHA256=942d2d57d86eb1826bcae1f901bf4df98598e5f66e7f075d58483c677b5fe8e9

**BJ_E** [北京市统计局](https://tjj.beijing.gov.cn/tjsj_31433/sjjd_31444/202002/t20200216_1639681.html)；vintage=2019成就报告/2020迁移；原站字节=False；HTTP=403；SHA256=UNAVAILABLE

**BJ_W** [北京市统计局](https://www.beijing.gov.cn/gongkai/shuju/sjjd/201905/t20190531_1837979.html)；vintage=2019-05-30；原站字节=False；HTTP=403；SHA256=UNAVAILABLE

**CQ_NP** [重庆市统计局](https://tjj.cq.gov.cn/zwgk_233/fdzdgknr/tjxx/sjzl_55471/tjgb_55472/202002/t20200219_5274457.html)；vintage=2019-05；原站字节=True；HTTP=200；SHA256=846b3819597da63654fe3467aba5dd104c9ce5d68f990ea381cca02d48e499d7

**CQ_W** [重庆市统计局](https://tjj.cq.gov.cn/zwgk_233/fdzdgknr/tjxx/sjzl_55471/tjgb_55472/202002/t20200219_5274459.html)；vintage=2019-05-29；原站字节=True；HTTP=200；SHA256=16a3dd434264db28eab05abf2dd3aed37518e55260e29c38bdf8b621d6f2b06e

**FJ_E** [福建省统计局](https://tjj.fujian.gov.cn/ztzl/xzg70/201909/t20190910_5021688.htm)；vintage=2019-09；原站字节=True；HTTP=200；SHA256=cc357a6e956efcfc481631146cf8bab8b2771fe33883d036854784401cd119f5

**FJ_NP** [福建省统计局](https://tjj.fujian.gov.cn/xxgk/tjxx/gzqk/201905/t20190523_4882127.htm)；vintage=2019-05-23；原站字节=True；HTTP=200；SHA256=0abd3df77c94c5d044869577dd05226529c04d4aaf56e20a46ad98f95811310f

**FJ_P** [福建省统计局](https://tjj.fujian.gov.cn/xxgk/tjxx/gzqk/201905/t20190523_4883071.htm)；vintage=2019-05-23；原站字节=True；HTTP=200；SHA256=d6f65af9692dbd57b6b9c017d3b3ecec39ebae9c040558861774ff32376bf8f8

**GD_E** [广东省政府转载统计局成就报告](https://www.gd.gov.cn/zwgk/zdlyxxgkzl/jycy/content/post_2595470.html)；vintage=2019-09；原站字节=False；HTTP=404；SHA256=UNAVAILABLE

**GS_E** [康乐县政府转载甘肃省统计公报](https://www.gskanglexian.gov.cn/klx/zfxxgk/fdzdgknr/GMJJHSHFZGH/art/2022/art_02ebc626e7c14b349a18229827decabf.html)；vintage=2019公报/2022页面；原站字节=True；HTTP=200；SHA256=10ef486a9742fbfa47db6c55b16f1fabb5cbf273c41aff4a909191d7211c4f02

**GS_NP_CANDIDATE** [甘肃经济信息网来源省统计局，需核主办](https://www.gsei.com.cn/html/1286/2019-11-25/content-259710.html)；vintage=2019-11-25；原站字节=True；HTTP=200；SHA256=6d0a2db7976e2c639c8340e2b88889a3702ba874d1e7a3b15d08cc1bc2771f57

**GS_P_CANDIDATE** [甘肃经济信息网来源省统计局，需核主办](https://www.gsei.com.cn/html/1286/2019-11-25/content-259649.html)；vintage=2019-11-25；原站字节=True；HTTP=200；SHA256=eecb21cf61012bd0b41a0c6e40388e5b9797d7516d38aaf386b1817d39dbdc6b

**GS_SPONSOR** [甘肃省经济研究院（甘肃省信息中心）](https://www.gsei.com.cn/)；vintage=现行主办身份；原站字节=True；HTTP=200；SHA256=83792031b68b9d699a6fe21eed66f81c28134ed8b00019a6529c62071646d104

**HB_E** [湖北卫健委转载人民网](https://wjw.hubei.gov.cn/bmdt/mtjj/mtgz/201910/t20191030_163456.shtml)；vintage=2019-10；原站字节=False；HTTP=412；SHA256=UNAVAILABLE

**HB_W** [国家发改委转载河北日报/省统计局](https://www.ndrc.gov.cn/fggz/jyysr/dfjx/202006/t20200617_1231432.html)；vintage=2020-06-17，2018基期；原站字节=True；HTTP=200；SHA256=778d2f6a554ed287851e26e17955bc3d8b60a25d516839cfb210ff99d56db50c

**HE_W** [河南妇联转载河南日报/省统计局](https://m.hnflw.gov.cn/2019/06-06/51130.html)；vintage=2019-06-06；原站字节=True；HTTP=200；SHA256=a05de6f1e8341a06251f791f3b44921462f717623d2bbe07f1cc4496801b03d3

**HI_E** [海南省统计局](https://stats.hainan.gov.cn/tjj/tjgb/fzgb/n_71782/201901/t20190128_2282048.html)；vintage=2019-01-28；原站字节=True；HTTP=200；SHA256=ad49b674847dd8c905a0527094168435742bceebfd2170259741a6ef40ecea63

**HLJ_BULLETIN** [黑龙江省统计局](https://tjj.hlj.gov.cn/tjj/c106779/201903/c00_30324948.shtml)；vintage=2019-03-29；原站字节=False；HTTP=403；SHA256=UNAVAILABLE

**HN_E** [湖南省统计局](https://tjj.hunan.gov.cn/tjsj/hnsq/hunan70/201909/t20190918_5485139.html)；vintage=2019-09-17；原站字节=True；HTTP=200；SHA256=86f89d5f2d2ed174d1e0ab15b200bad432cfc4ab5c4513fef6c255695be4a8a6

**HN_NP** [湖南省统计局](https://tjj.hunan.gov.cn/tjfx/jmxx/2019jmxx/201905/t20190516_5334865.html)；vintage=2019-05-16；原站字节=True；HTTP=200；SHA256=09e96d363bd5907492f83e1c12ac820dcadd36d9678121dc4b0b94a157e6f751

**HN_P** [湖南省统计局](https://tjj.hunan.gov.cn/m/tjsj/201905/t20190516_5335128.html)；vintage=2019-05-16；原站字节=True；HTTP=200；SHA256=9a033b64237d0d350ff6ad7128e830f8197542b71f21af9c036536c83392f9f5

**JL_COV** [吉林省统计局](https://tjj.jl.gov.cn/tjsj/tjnj/2019/2019/B4_2.htm)；vintage=2019年鉴2018年末；原站字节=True；HTTP=200；SHA256=7b6e9bdce3315c1e75358ff2a83ac3768df3577db91f86aaa3c854dfea74b86f

**JL_NP** [吉林省统计局](https://tjj.jl.gov.cn/tjsj/tjnj/2019/2019/B4_7.htm)；vintage=2019年鉴；原站字节=False；HTTP=502；SHA256=UNAVAILABLE

**JL_P** [吉林省统计局](https://tjj.jl.gov.cn/tjsj/qwfb/201905/t20190517_5879168.html)；vintage=2019-05-17；原站字节=False；HTTP=403；SHA256=UNAVAILABLE

**JS_E** [江苏省统计局](https://tj.jiangsu.gov.cn/art/2019/3/8/art_85764_10520822.html)；vintage=2019-03-08；原站字节=False；HTTP=403；SHA256=UNAVAILABLE

**JS_P** [江苏省统计局](https://tj.jiangsu.gov.cn/2024/nj03/nj0321.htm)；vintage=2024年鉴历史2018列；原站字节=False；HTTP=403；SHA256=UNAVAILABLE

**JS_W_RELAY** [泰州公安局官方访谈](https://gaj.taizhou.gov.cn/jlhd/zxft/art/2020/art_79ba4a59648d431fb74077d960169cf3.html)；vintage=2020；原站字节=True；HTTP=200；SHA256=8cfc9e69f92200225b31fa1a13dec06902c2f93990e170055d60ad953c89fb1a

**JX_E** [南昌市政府转载江西统计公报](https://www.nc.gov.cn/ncszf/jrnc/201903/60cae395eb1d414ba06d11a4f1fc52ea.shtml)；vintage=2019-03；原站字节=False；HTTP=403；SHA256=UNAVAILABLE

**LN_COV** [辽宁省统计局](https://tjj.ln.gov.cn/tjj/tjsj/otherpages/2019/zk/html/05-04.xls)；vintage=2019年鉴2018年末；原站字节=True；HTTP=200；SHA256=a43961fb8c01301580bef013545db2f55abd3dfad51026faa1a8e75912506671

**LN_E** [辽宁省统计局](https://tjj.ln.gov.cn/tjj/tjsj/otherpages/2019/zk/html/05-01.xls)；vintage=2019年鉴表5-1；原站字节=True；HTTP=200；SHA256=6f36da4621de710d5d12f6e909bb2d4f9e10b3e288c54968e72aa01e91d9b8f5

**NBS_E** [国家统计局](https://www.stats.gov.cn/xxgk/sjfb/tjgb2020/201902/t20190228_1768642.html)；vintage=2019-02-28；原站字节=False；HTTP=None；SHA256=UNAVAILABLE

**NBS_NP** [国家统计局](https://www.stats.gov.cn/sj/zxfb/202302/t20230203_1900311.html)；vintage=2019-05-14；原站字节=True；HTTP=200；SHA256=469aaecdbacbf44f373261128b61a8067db82624cd45a34b3198686586e79781

**NBS_P** [国家统计局](https://www.stats.gov.cn/sj/zxfb/202302/t20230203_1900312.html)；vintage=2019-05-14；原站字节=True；HTTP=200；SHA256=1bf818eb3039994c88141cbb593b3e1e45ce7660dc72ae0ec8505c62e2650085

**NBS_SCOPE1** [国家统计局](https://www.stats.gov.cn/hd/lyzx/zxgk/202508/t20250807_1960621.html)；vintage=2025答复；原站字节=True；HTTP=200；SHA256=286e16acc9a0a43f8fb12f0382c78242d5ea7203556782a67f7c8eaed2c7063e

**NBS_SCOPE2** [国家统计局](https://www.stats.gov.cn/hd/lyzx/zxgk/202408/t20240829_1956132.html)；vintage=2024答复；原站字节=True；HTTP=200；SHA256=658d0a2d95c3e3cb5763df7a0bc651a1e9d80dc40c7183afb40242760d375770

**NBS_SCOPE3** [国家统计局](https://www.stats.gov.cn/hd/lyzx/zxgk/202407/t20240719_1955719.html)；vintage=2024答复；原站字节=True；HTTP=200；SHA256=6ac06999a1f286ccbd092118976ddd104568616b8df32a46f3dfd99af9b82d31

**NX_NP** [银川市人社局转载宁夏工资发布](https://www.yinchuan.gov.cn/xxgk/bmxxgkml/srsj_2124/xxgkml_2127/ldgx/202009/t20200921_2238742.html)；vintage=2019原稿/2020迁移；原站字节=True；HTTP=200；SHA256=4d539b50e5217ed0765410f608dbaa9f158141b5a39fdc909e949ccd86df8ec0

**SC_WE** [四川省国防科工办转载人社统计公报](https://www.scjg.gov.cn/news/2589.html)；vintage=2019-08-04；原站字节=True；HTTP=200；SHA256=533eaf6a54a2d526badae08b921066c5ca33e94afda12467fc7c0cb31b25de2d

**SH_W** [上海市统计局](https://tjj.sh.gov.cn/tjxw/20190621/0014-1003597.html)；vintage=2019-06-21；原站字节=False；HTTP=403；SHA256=UNAVAILABLE

**SN_E_PDF** [陕西省统计局](https://tjj.shaanxi.gov.cn/sy/ztzl/lhfw/2020lhtjzxfw/202006/P020200620516158259832.pdf)；vintage=70年成就报告/2020公开；原站字节=False；HTTP=None；SHA256=UNAVAILABLE

**SX_NP_RELAY** [吕梁市政府转载山西统计局](https://www.lvliang.gov.cn/zfxxgk/ggsj/ndsj/202008/t20200828_1428124.html)；vintage=2020-08-28明确2018基期；原站字节=False；HTTP=None；SHA256=UNAVAILABLE

**SX_P** [吕梁政府转载山西省统计局](https://www.lvliang.gov.cn/zfxxgk/ggsj/ndsj/201906/t20190621_1296611.html)；vintage=2019-06-21；原站字节=True；HTTP=200；SHA256=b2a1b8c8644bd6273e7719aa1857832c6c6f99b578502f4af1d5a203fa2489e4

**TJ_BULLETIN** [天津市政府/统计局](https://www.tj.gov.cn/sq/tjgb/202005/t20200520_2468077.html)；vintage=2019公报/2020迁移；原站字节=True；HTTP=200；SHA256=aaebddf93e880e0d475c63873499ca9f6d0afebbc7e6273545c1aca5be30ea91

**XJ_NP** [新疆统计局](https://tjj.xinjiang.gov.cn/tjj/rkjyug/202203/72389d7fc1064ca9aa188eedf8f08c36.shtml)；vintage=2021年鉴历史2018列；原站字节=False；HTTP=404；SHA256=UNAVAILABLE

**YN_E** [云南省统计局](https://stats.yn.gov.cn/zwgk/zfxxgk/fdzdgknr/tjsj/sjjd/201909/t20190924_1204004.html)；vintage=2019-09-24；原站字节=True；HTTP=200；SHA256=446a5a7716fbd6d25757003967320dbce267ad8db5f73f041199520a52c59430

**YN_NP** [云南省统计局](https://stats.yn.gov.cn/zwgk/zfxxgk/fdzdgknr/tjsj/sjjd/201906/t20190611_1203898.html)；vintage=2019-06-11；原站字节=True；HTTP=200；SHA256=6b3ca8e0aeeab983b36b281a1bab9605be200ff2d7be76c75df913557f66e862

URL可观察不代表原站当前可访问或全部数值通过验证。
