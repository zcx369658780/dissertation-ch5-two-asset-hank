import sys,pathlib,json,hashlib,zipfile,base64,csv,zlib,io
R=pathlib.Path(__file__).parent;sys.stdout.reconfigure(encoding='utf-8')
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+bytes([0])+b).hexdigest()
def write(n,x):
 with (R/n).open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2)
def canonical(request):
 if isinstance(request,str):return [('open' if request.startswith(('https://','http://')) else 'search_query',request)]
 if isinstance(request,dict):
  if 'q' in request:return [('search_query',request)]
  out=[]
  for k,kind in [('system2_search_query','search_query'),('open','open'),('click','click'),('find','find')]:
   if k in request:
    if not isinstance(request[k],list):raise ValueError('NON_LIST_REQUEST_BATCH')
    out.extend((kind,v) for v in request[k])
  if out:return out
 raise ValueError('UNKNOWN_REQUEST_SCHEMA')
def tests():
 cases=[({'q':'one'},1),({'system2_search_query':[{'q':str(i)} for i in range(4)]},4),({'open':[{'ref_id':'https://a'},{'ref_id':'https://b'}]},2),('query string',1),('https://official.gov.cn',1),({'system2_search_query':[{'q':'a'}],'open':[{'ref_id':'https://b'}]},2)]
 results=[dict(input=x,expected=n,actual=len(canonical(x))) for x,n in cases]
 for x in ({'bad':[]},None,[],{'open':'not_a_list'}):
  try:canonical(x);ok=False
  except ValueError:ok=True
  results.append(dict(input=x,expected='REJECT',actual='REJECT' if ok else 'BAD_ACCEPT'))
 assert all(s['expected']==s['actual'] for s in results)
 return results
if __name__=='__main__':
 a=json.loads((R/'authority.json').read_text(encoding='utf-8'));boot=json.loads((R/'bootstrap.json').read_text(encoding='utf-8-sig'));assert boot['run_id']
 for p,s in a['files'].items():assert blob(s['content'].encode())==s['sha'],p
 manifest=json.loads(next(s['content'] for p,s in a['files'].items() if p.endswith('ISSUE_MANIFEST.json')))
 for s in manifest['contract_files']:assert a['files'][s['path']]['sha']==s['git_blob']
 zpath=pathlib.Path('FROZEN_SOURCE_PATH_REDACTED');b=zpath.read_bytes();assert len(b)==220081 and sha(b)=='14746e539ce792189dc85d207ec148e97bad27f8101a4c598c475d49a05008fc' and blob(b)=='87b3173fc12f4ec3bec34dbde785f27ad627e37f'
 dest=R/'prior';dest.mkdir();members=[]
 with zipfile.ZipFile(io.BytesIO(b)) as z:
  assert len(z.infolist())==26 and z.testzip() is None
  for s in z.infolist():
   assert pathlib.PurePosixPath(s.filename).name==s.filename and '\\' not in s.filename
   v=z.read(s);(dest/s.filename).write_bytes(v);members.append(dict(path=s.filename,bytes=len(v),sha256=sha(v),crc32=f'{zlib.crc32(v):08x}'))
 write('prior_integrity.json',dict(zip_sha256=sha(b),blob=blob(b),members=members,all_pass=True))
 write('canonical_event_tests.json',tests())
 rows=[json.loads(l) for l in (dest/'official_discovery_receipts.jsonl').read_text(encoding='utf-8').splitlines()];events=[]
 for bi,s in enumerate(rows):
  for qi,(kind,payload) in enumerate(canonical(s['request'])):
   events.append(dict(event_id=f'OLD-WEB-{bi:03d}-{qi:02d}',billing_run='HISTORICAL_CLOSED',request_kind=kind,batch_index=bi,query_index=qi,request=payload,request_time_utc='UNKNOWN_NOT_SAVED_IN_OLD_RECEIPT',attempt_state='ATTEMPTED_RECEIPT_SAVED',source_id=s['receipt'],receipt_sha256=s['sha256'],new_budget_charge=0))
 origins=[json.loads(l) for l in (dest/'new_official_sources.jsonl').read_text(encoding='utf-8').splitlines()]
 for i,s in enumerate(origins):events.append(dict(event_id=f'OLD-HTTP-{i:03d}',billing_run='HISTORICAL_CLOSED',request_kind='official_http',batch_index=i,query_index=0,request=s['url'],request_time_utc=s['requested_utc'],attempt_state='ATTEMPTED_RECEIPT_SAVED',source_id=s['source_id'],provider_http=s.get('provider_http'),transport_error=s.get('transport_error'),new_budget_charge=0))
 assert len({s['event_id'] for s in events})==len(events)
 assert len(rows)==47 and sum(s['request_kind']!='official_http' for s in events)==53 and len(origins)==5 and len(events)==58
 with (R/'historical_canonical_events.jsonl').open('x',encoding='utf-8') as f:
  for s in events:f.write(json.dumps(s,ensure_ascii=False)+'\n')
 write('historical_reconciliation.json',dict(events_derived=len(events),web_receipts=len(rows),web_events=sum(s['request_kind']!='official_http' for s in events),http_events=len(origins),frozen_independent_controller=58,failed_historical_builder=50,match=True,root_cause='8 single-query dict request wrappers were counted as zero by the old batch-only counter',old_budget_charge=0,tests=10))
 print(json.dumps(dict(run_id=boot['run_id'],authority='BLOB_BYTES_AND_MANIFEST_PASS',prior_zip_members=len(members),events_derived=len(events),event_tests=10,old_budget_reopened=False),ensure_ascii=False))
