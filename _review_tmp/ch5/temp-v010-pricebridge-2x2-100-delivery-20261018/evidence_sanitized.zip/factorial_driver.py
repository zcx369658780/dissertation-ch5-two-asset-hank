"""One driver per frozen ARM; never resumes or retries an ARM."""
import pathlib,sys,json,os,time,datetime,hashlib,traceback,dataclasses,msvcrt
R=pathlib.Path(__file__).resolve().parent
runtime={'__file__':str(R/'task_runtime.py'),'__name__':'task_runtime'}
exec(compile((R/'task_runtime.py').read_bytes(),runtime['__file__'],'exec'),runtime)
def limits(counts,iteration):
 assert 1<=iteration<=100,'E2_ROUND_BUDGET'
 assert counts['HA']<200,'E2_HA_BUDGET'
 assert counts['driver']==1,'E2_DRIVER_BUDGET'
class Budget:
 def __init__(self,bound,arm,folder):
  self.bound=bound;self.arm=arm;self.folder=folder;self.path=folder/'science';self.path.mkdir()
  self.lock=(self.path/'writer.lock').open('xb',buffering=0);self.lock.write(b'1');self.lock.seek(0);msvcrt.locking(self.lock.fileno(),msvcrt.LK_NBLCK,1)
  self.events=(self.path/'events.jsonl').open('xb',buffering=0);self.counts={'driver':1,'HA':0,'HJB':0,'KFE':0,'initializerRoots':0,'localPolicyCells':0,'HJBUpdatesObserved':0,'HA_completed':0,'HA_failed':0}
  self.active=None;self.seq=0;self.chain='0'*64;self.phase={};self.base_profile=sys.getprofile();self.ha=bound['ha'];self.np=bound['np']
  self.event('DRIVER_STARTED',{'arm':arm,'pid':os.getpid(),'maximumHA':200,'maximumRounds':100,'wallDeadline':runtime['read_first']()['deadlineUtc']})
  sys.setprofile(self.profile)
 def guard(self):
  runtime['wall_guard']();m=runtime['rss']()
  assert m['rssBytes']<=2*1024**3,'E2_RSS_ANOMALY'
  if (R/'PARENT_STOP_REQUEST.json').exists():raise RuntimeError('E2_PARENT_SHARED_STOP')
  return m
 def event(self,kind,payload=None):
  m=self.guard();self.seq+=1
  row={'seq':self.seq,'event':kind,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':dict(self.counts),'activeHA':self.active,'arm':self.arm,'payload':payload,'resources':m,'previousEventSHA256':self.chain}
  raw=(json.dumps(row,sort_keys=True,allow_nan=False)+'\n').encode();assert self.events.write(raw)==len(raw),'E2_LEDGER_SHORT_WRITE';os.fsync(self.events.fileno());self.chain=runtime['sha'](raw)
  self.checkpoint()
 def checkpoint(self):
  path=self.path/'current.next'
  with path.open('xb') as f:f.write((json.dumps({'seq':self.seq,'counts':self.counts,'activeHA':self.active,'eventHeadSHA256':self.chain},sort_keys=True)+'\n').encode());f.flush();os.fsync(f.fileno())
  os.replace(path,self.path/'current.json')
 def begin_ha(self,iteration,province,inputs):
  limits(self.counts,iteration);assert self.active is None,'E2_LEDGER_ACTIVE_HA'
  assert inputs['province_index']==province and inputs['round']==iteration
  if iteration==1:
   raw=(json.dumps(inputs,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
   assert raw==(R/f'a0/first/science/HA_{province+1:04d}/input.json').read_bytes(),'E2_FIRST_HA_INPUT_IDENTITY'
  assert inputs['tau_HA']==0. and inputs['HA_SHA256']=='B92F6EFC59D9398F89F8FB6EE67BF6C5F947282D76895051BEC194967EC9C3E3','E2_BLACKBOX_INPUT_IDENTITY'
  # Actual observer payload is bound byte-for-byte to the captured prepared fields.
  assert self.np.asarray([inputs['rah'],inputs['w_eff']],dtype='<f8').tobytes()==self.expected_price_bytes[province],'E2_ACTUAL_PRE_HA_PRICE_IDENTITY'
  self.counts['HA']+=1;self.active=self.counts['HA'];self.phase={'HJB':0,'KFE':0}
  self.event('HA_CHARGED_BEFORE_INITIALIZATION',{'round':iteration,'province':province,'inputSHA256':runtime['sha']((json.dumps(inputs,sort_keys=True,allow_nan=False)+'\n').encode()),'originalInputJSONSHA256':runtime['sha']((json.dumps(inputs,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())})
  path=self.path/f'HA_{self.active:04d}';path.mkdir();runtime['write_json'](path/'input.json',inputs);return path
 def profile(self,frame,event,arg):
  if self.base_profile:self.base_profile(frame,event,arg)
  name=frame.f_code.co_name
  if event=='call':
   if name in ('solve_matlab_faithful_hjb','solve_matlab_faithful_stationary_kfe'):
    assert self.active is not None and pathlib.Path(frame.f_code.co_filename)==pathlib.Path(self.ha.__file__),'E2_SOLVER_BINDING'
    kind='HJB' if name=='solve_matlab_faithful_hjb' else 'KFE';self.phase[kind]+=1;assert self.phase[kind]==1,'E2_DUPLICATE_SOLVER'
    self.counts[kind]+=1;assert self.counts[kind]<=self.counts['HA'],'E2_SOLVER_BUDGET'
    self.event(kind+'_ENTER_BEFORE_BODY')
   elif name=='_source_initial_arrays':assert self.active is not None,'E2_INITIALIZATION_BEFORE_CHARGE'
   elif name=='_source_labor_root':self.counts['initializerRoots']+=1
   elif name=='select_matlab_faithful_local_policy':self.counts['localPolicyCells']+=1
  elif event=='return' and name=='solve_matlab_faithful_hjb':
   n=int(frame.f_locals.get('iteration',0));assert 0<=n<=100,'E2_HJB_ITERATION_BUDGET';self.counts['HJBUpdatesObserved']+=n;self.event('HJB_RETURN_OR_EXCEPTION',{'iterationsObserved':n,'resultReturned':arg is not None})
 def finish(self,success,detail):
  if success:assert self.phase=={'HJB':1,'KFE':1},'E2_HA_PHASE_COUNTS'
  self.counts['HA_completed' if success else 'HA_failed']+=1;self.event('HA_COMPLETED' if success else 'HA_REAL_ERROR',detail);self.active=None;self.checkpoint()
 def close(self):
  sys.setprofile(self.base_profile);self.events.close();self.lock.seek(0);msvcrt.locking(self.lock.fileno(),msvcrt.LK_UNLCK,1);self.lock.close()
def run(bound,old,driver,fb,fixture,budget,folder):
 np=bound['np'];ss=bound['steady'];states=bound['stationary'].mainline_initial_states(fixture);tkn=np.full(2,3.);history=[];status='NOT_CONVERGED_WITHIN_100';failure=None
 provider=driver['faithful_observer'](bound,fixture,budget)
 stream=(folder/'trajectory.jsonl').open('xb',buffering=0)
 try:
  for iteration in range(1,101):
   runtime['assert_sources']();states,binding=fb.prepare_prices_for_arm(states,fixture,budget.arm,iteration,bound['one_turn'])
   runtime['write_json'](folder/f'PRE_HA_ROUND_{iteration:03d}.json',binding)
   budget.expected_price_bytes=[np.asarray([s['rah'],s['w_eff']],dtype='<f8').tobytes() for s in states]
   obs=[provider(s,iteration,i) for i,s in enumerate(states)]
   batch=bound['one_turn'].PreFrozenHouseholdOutputBatch([o['Ct'] for o in obs],[o['Lt_HA'] for o in obs],[o['At'] for o in obs],[o['Bt'] for o in obs],[o['AtTax'] for o in obs],tuple(o['converged'] for o in obs),tuple({'actual_hjb_converged':o['converged']} for o in obs))
   entering=[dict(s) for s in states];turn=fb.price_one_turn(states,batch,fixture,budget.arm,old);states=tuple(dict(s) for s in turn['states'])
   assert np.asarray(turn['shares'],dtype='<f8').tobytes()==np.asarray(binding['S']['values'],dtype='<f8').tobytes(),'E2_SAME_S'
   nk,yt,hcount,rau,ral,wu,wl,converged=ss._diagnostics(states,batch,tkn,1e-9)
   if converged:
    adjusted=[dict(s) for s in states];actions=tuple(ss.AdaptiveAction(str(s['name']),False,float(s['Zt']),float(s['Zt']),'NONE',float(s['GovInv']),float(s['GovInv'])) for s in states);tkn_after=tkn.copy()
   else:
    adjusted,actions=ss._adapt([dict(s) for s in states],float(max(nk)),True);tkn_after=np.array([.6*s['KNratio']+.4*tkn[i] for i,s in enumerate(adjusted)])
   capital=turn['capital'];residual=capital.national_private_capital_conservation_residual
   # Fiscal oracle observes the original raw-wage tax and unaltered government accounts.
   fiscal_res=[]
   for i,s in enumerate(states):
    f=turn['fiscal']['provinces'][i];tax=s['tau']*s['wt0']*s['Lt'];fiscal_res.append(tax-f['wage_tax'])
    assert np.isclose(tax,f['wage_tax'],rtol=1e-13,atol=1e-12),'E2_FISCAL_BINDING'
   row={'arm':budget.arm,'round':iteration,'entering_states':entering,'preHABinding':binding,'household':obs,'states':[dict(s) for s in states],'next_states':adjusted,'tkn_before':tkn,'tkn_after':tkn_after,'nk_gap':nk,'yt_gap':yt,'target_gap':[abs(s['Yt']/s['Yt0']-1) for s in states],'ra_boundary':[s['ra'] in (s['ramin'],s['ramax']) for s in states],'w_boundary':[s['wjt'] in (s['wjtmin'],s['wjtmax']) for s in states],'household_converged_count':hcount,'outer_source_converged':bool(converged),'adapt':[dataclasses.asdict(a) for a in actions],'shares':turn['shares'],'lagged_score':turn['lagged_score'],'fiscal':turn['fiscal'],'migration_Lt_mat':turn['migration'].lt_mat,'private_capital_by_destination':capital.destination_private_productive_capital,'privateCapitalResidual':residual,'rawWageFiscalResidual':fiscal_res,'priceSignal':turn['price_signal'],'boundaryMargins':[{'raRawMinusMax':s['ra0']-s['ramax'],'raUsedLower':s['ra']-s['ramin'],'raUsedUpper':s['ramax']-s['ra'],'wRawMinusMax':s['wt0']-s['wjtmax']} for s in states],'labor_bridge_residual':[states[i]['Lt']-entering[i]['N']*obs[i]['Lt_HA'] for i in range(2)]}
   row=driver['clean'](row,np);raw=(json.dumps(row,sort_keys=True,allow_nan=False)+'\n').encode();assert stream.write(raw)==len(raw),'E2_TRAJECTORY_SHORT_WRITE';os.fsync(stream.fileno());history.append(row)
   budget.event('OUTER_ROUND_COMPLETED',{'round':iteration,'trajectoryRowSHA256':runtime['sha'](raw),'converged':bool(converged)})
   if iteration in (1,10,25,50,75,100) or converged:
    runtime['write_json'](folder/f'trend_{iteration:03d}.json',driver['trend'](history));print(json.dumps({'arm':budget.arm,'round':iteration,'max_nk':max(row['nk_gap']),'max_yt':max(row['yt_gap']),'HH_converged':hcount,'converged':bool(converged)}),flush=True)
   states=tuple(dict(s) for s in adjusted);tkn=tkn_after
   if converged:status=f'SOURCE_CONVERGED_BY_ROUND_{iteration}';break
 except BaseException as exc:
  status='ARM_REAL_ERROR_STOP';failure={'type':type(exc).__name__,'reason':str(exc),'roundInProgress':iteration,'traceback':traceback.format_exc(),'sharedHardGate':'E2_' in str(exc)}
  runtime['write_json'](folder/'first_error.json',failure)
 finally:stream.close()
 runtime['assert_sources']()
 out={'arm':budget.arm,'status':status,'completedOuterRounds':len(history),'maxOuter':100,'failure':failure,'trend':driver['trend'](history),'scienceCounts':dict(budget.counts),'ledgerHeadSHA256':budget.chain,'RSS':runtime['rss'](),'Results':False,'model_activation':False,'REAL_GE':False,'V011':'NOT_STARTED','FULL_RUNNER_IO_CLOSURE':'BLOCKED'}
 runtime['write_json'](folder/'SCIENCE_FINAL.json',out);return out
def main():
 arm=sys.argv[1];folder=R/'arms'/arm
 try:
  runtime['wall_guard']();config=json.loads((R/'SCIENCE_CONFIG.json').read_bytes());assert arm in config['arms'] and config['P0Status']=='P0_PASS'
  for name,h in config['newCodeHashes'].items():assert runtime['sha']((R/name).read_bytes())==h,'E2_FROZEN_TEMP_CODE_HASH'
  assert runtime['sha']((R/config['p0File']).read_bytes())==config['p0SHA256'],'E2_P0_BINDING'
  bound,old,driver=runtime['load_reference'](True);fb=runtime['load_local']('factorial_bridge');fixture=json.loads((R/'reference/fixture_RAW.json').read_bytes())
  # Additional ARM-only write boundary. Original loader continues to guard sources and child/network.
  def arm_guard(event,args):
   if event=='open':
    path,mode,flags=args
    if isinstance(path,int):return
    write=(isinstance(mode,str) and any(k in mode for k in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
    if write:assert pathlib.Path(path).is_relative_to(folder),'E2_CROSS_ARM_WRITE'
   if event in ('os.mkdir','os.remove','os.rmdir','os.rename'):
    for target in (args[:2] if event=='os.rename' else args[:1]):assert pathlib.Path(target).is_relative_to(folder),'E2_CROSS_ARM_MUTATION'
  sys.addaudithook(arm_guard)
  runtime['write_json'](folder/'EXECUTED_MODULES.json',{'modules':bound['modules'],'adapter':bound['adapter'],'numpy':bound['np'].__version__,'scipy':bound['scipy'].__version__})
  budget=Budget(bound,arm,folder)
  try:out=run(bound,old,driver,fb,fixture,budget,folder)
  finally:budget.close()
  print(json.dumps({'terminal':out['status'],'arm':arm,'rounds':out['completedOuterRounds'],'counts':out['scienceCounts']}),flush=True)
  return 0 if out['failure'] is None else 2
 except BaseException as e:
  path=folder/'STARTUP_OR_HARD_FAILURE.json'
  if not path.exists():runtime['write_json'](path,{'type':type(e).__name__,'reason':str(e),'traceback':traceback.format_exc(),'sharedHardGate':True,'noRetry':True})
  raise
if __name__=='__main__':sys.exit(main())
