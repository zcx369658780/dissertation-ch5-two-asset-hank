# TEMP V010 macro constraints — SOURCE_ONLY
M verdict: supported static mechanisms, no solved fixed point and no proven cause of nonconvergence. S06 is the accepted raw-return forensic report; S07 the accepted 100-round review; S08 the accepted ledger E2 review; S10 the prior A+B PENDING review; S11 frozen V010 plan. S12 firm, S13 steady_state, S14 wage, S15 capital_network. source_identity.json binds all 16 exact inputs. The 910-member original trajectory archive was not read.

## 1. Conditional capital scale: separate TWO output conditions
At the accepted last state profit PIt=0, so raw ra0=rk-delta, rk=m*alpha*Y/K. Taking delta=.025 and cap=.09 from S06, fixing m*alpha and a specified output Ybar gives Kreq(Ybar)=m*alpha*Ybar/(.09+.025). This is a conditional algebraic equality/necessary scale for the given branch, not the equilibrium minimum capital. m, profits, wages, labor, Z and household wealth cannot generally be held fixed in a full iteration.

| Province | accepted-review K | historical TARGET-output Kreq | ratio to observed K | holding OBSERVED output instead | ratio |
|---|---:|---:|---:|---:|---:|
| SYN_A | 2278.055 | about7708 | 3.383588 | 8113.520688 | 3.561600 |
| SYN_B | 2668.517 | about9867 | 3.697559 | 10493.977909 | 3.932513 |

The historical 7708/9867 statement explicitly uses frozen GDP TARGETS (S06:50–56), not contemporaneous output. Using the rounded observed rk,K,Y to infer m*alpha and then the reported Kreq implies target outputs about1499.916 and1900.086. These are consistency inversions, NOT authenticated original fixture values. The raw fixture is outside this task. Consequently the historical estimate is compatible with targets near1500/1900, but its unrounded target calculation is not independently re-certified here. There is no contradiction between the two Kreq columns once their conditioning differs.
The new scalar oracle verifies both conditions explicitly and records every rounded input. A fixed-observed-output shortcut cannot be used to claim exact reproduction of the target-output estimate.

A second distinct condition is fixed m,Z,L and zero profit: ra0+delta=m*alpha*Z*L^(1-alpha)*K^(alpha-1). Then Kreq/K=[(ra0+delta)/(.09+delta)]^(1/(1-alpha)), not the fixed-Y ratio. No numerical alpha is authenticated here, so no third historical numeric requirement is fabricated.
Elasticities under that condition are dln(ra0+delta)/dlnK=alpha-1, dln(...)/dlnL=1-alpha and dln(...)/dlnZ=1. Restoring GDP via Z adaptation changes the conditioning again.

## 2. Why extra K does not automatically deliver an equilibrium
S12:61–64: K=Kprivate+GovInv. S15:298–311: W_i=N_i*At_i, flows[j,i]=S[j,i]*W_i, Kprivate_j=sum_i flows[j,i], rah_i=sum_j payoff_j*S[j,i]. Public capital is outside household private-wealth shares.
Using accepted rounded GovInv values, private K is about1086.237/1238.336. If private K alone were artificially frozen, target-output Kreq would imply public capital about6621.763/8628.664. These are conditional balance-sheet readings, NOT a recommendation to set GovInv or a fiscal feasibility finding.
S12:89–101 makes m depend on prior rk, prior/current K,L,Z,pi. Thus a static inverse cannot predict a controlled K increase holding all other terms fixed. Positive profits, where present, also alter the raw-return identity.

## 3. Intermittent control is consistent with persistent high raw return
S13:197–232 and S11:30 require outer not converged, steady_state and the NATIONAL/all-province maxKN gap strictly below .1. Z adjusts for target discrepancy beyond1%; GovInv then decreases*.9 near the lower used-rate bound, otherwise increases*1.1 near the upper bound. tKN updates with .6/.4.
S06:23 reports both raw rates above .09 in ALL100 rounds; minima .373331/.415542. S06:46 reports26 public-capital increases and23 Z changes per province, not complete absence of feedback. Final maxKN=.1075218256230952 is above .1, so this joint gate is closed at that observed final diagnostic.
Used ra at .09 conveys boundary status but loses raw-gap magnitude. The controller can therefore respond intermittently while raw returns remain far above cap. This is a source-supported mechanism, not a stability/nonexistence theorem or a prediction about500 rounds.

## 4. Same-S and price transmission
The frozen plan S11:26 prescribes previous completed raw-return zscore(ddof=0), foreign-only softmax and same S for quantities/payoffs. S15:140–155,289–325 proves the accounting implementation for its explicit inputs. Dimensionless score and payoff rate are separate inputs; replacing payoff with used rates need not authorize changing the score.
S06 reports last S=[[.9,.2],[.1,.8]], giving rounded raw rah=.3888495/.418708 versus .09/.09 if both destination payoffs are capped. Firm raw ra0 and used ra are separate objects, so differing values alone do not prove a bug.
Only four public model modules are authorized here: one_turn/prepare body is NOT inspected in this task. The accepted review describes a rebinding risk. The newly inspected private factorial driver calls prepare_prices_for_arm and binds actual observer inputs to the prepared state's rah/w_eff bytes, but the bridge and runtime-loader bodies are not authorized selected members. Correct intended arm selection or an actual prepare overwrite remains UNKNOWN/NEEDS_OWNER_SOURCE.

## 5. Wages, compensation and fiscal scope
S12:103–134: raw wt0=m*(1-alpha)*Z*(K/L)^alpha; wjt clips it. Corptax contains actual profit tax PLUS (ra0-ra_used)*K+(wt0-wjt)*L, including negative compensation below floors.
S14:52–75 uses destination tau_j plus additive sigma[j,i] once in the nonlinear composite wage. A multi-destination composite index can exceed an individual quote; this is not by itself evidence of a unit bug. True HA-adapter behavior remains only partially available.
The historical raw-wage composite6.948/7.029 and same-state substituted-wjt2.038/2.019 are accepted static comparisons (S06:68–80), not a new HA experiment.
S12:140 directly gives mainline GovInc=Corptax+tau*wt0*L+N*AtTax+GovInv*ra_used-N*T. Compensation is not productive profit; WageTax is not compensation; per-capita household flows require N exactly once. The private driver checks wage-tax arithmetic against the raw wt0*L basis, but the fiscal implementation body is unavailable.
Rounded compensation/GDP recomputes to about69.164%/73.858%, consistent with S06's69.2%/73.9%. These are diagnostic synthetic clip transfers, not realistic tax rates or evidence of government-budget/GE clearing.

## 6. Evidence and limits
Historical100-round values: REVIEW_ACCEPTED_STATIC_FACT; new rounded scalar checks: STATIC_FORMULA_ORACLE. Authenticated selected archive code/events: PRIVATE_SOURCE_CONFIRMED, only within their restricted contents. Price effects, calibration-scale causality, unique WinError5 cause and any future convergence: HYPOTHESIS/NOT_OBSERVED.
No private 100-round arrays/trajectory, initial fixture, actual bridge body, prepare body, migration body, fiscal body, supervisor reader script or complete runtime loader were read. No HA/HJB/KFE/GE/IRF, original production code or old synthetic tests executed.
