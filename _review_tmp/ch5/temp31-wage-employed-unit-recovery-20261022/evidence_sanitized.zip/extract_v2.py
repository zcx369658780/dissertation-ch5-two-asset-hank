import sys,json,base64,pathlib,csv,re,hashlib,io
from lxml import html
R=pathlib.Path(__file__).parent;sys.path.insert(0,str(R/'vendor'));import xlrd
from unit_validator import numeric_tokens
sys.stdout.reconfigure(encoding='utf-8')
def decode(b):
 try:return b.decode('utf-8-sig'),'utf-8'
 except UnicodeDecodeError:return b.decode('gb18030'),'gb18030'
def parse(b):
 if b.startswith(bytes.fromhex('d0cf11e0')):
  w=xlrd.open_workbook(file_contents=b);tables=[{'sheet':s.name,'rows':[[str(s.cell_value(i,j)).removesuffix('.0') for j in range(s.ncols)] for i in range(s.nrows)]} for s in w.sheets()]
  return '\n'.join(' | '.join(r) for t in tables for r in t['rows']),'XLS_XLRD_2.0.2',tables
 t,enc=decode(b);root=html.fromstring(t);[e.drop_tree() for e in root.xpath('//script|//style')]
 return re.sub(r'\s+',' ',root.text_content()),enc,[]
if __name__=='__main__':
 src=[json.loads(l) for l in (R/'reused/official_origin_bytes.jsonl').read_text(encoding='utf-8').splitlines()];ex=[json.loads(l) for l in (R/'reused/official_connector_extracts.jsonl').read_text(encoding='utf-8').splitlines()]
 texts={};tables={};encodings={}
 for s in src:
  t,enc,tb=parse(base64.b64decode(s['content_base64']));texts[s['source_id']]=t;encodings[s['source_id']]=enc
  if tb:tables[s['source_id']]=tb
 for s in ex:texts.setdefault(s['source_id'],s['text'])
 (R/'source_texts_v2.json').write_text(json.dumps(texts,ensure_ascii=False),encoding='utf-8')
 (R/'xls_tables.json').write_text(json.dumps(tables,ensure_ascii=False,indent=2),encoding='utf-8')
 rows=list(csv.DictReader((R/'reused/wage_source_ledger.csv').read_text(encoding='utf-8-sig').splitlines()));cs=[]
 from decimal import Decimal
 for r in rows:
  if not r['source_id']:continue
  t=texts.get(r['source_id'],'');v=Decimal(r['value']);raw=v*10000 if r['source_id'] in ('JL_COV','LN_COV') else v
  matches=[(a,i,j) for a,i,j in numeric_tokens(t) if Decimal(a.replace(',',''))==raw]
  cs.append(dict(province=r['province'],metric=r['measure'],value=r['value'],source=r['source_id'],vintage=r['vintage'],contexts=[t[max(0,i-110):min(len(t),j+100)] for _,i,j in matches[:1]],text_start=t[:130]))
 (R/'contexts_v2.json').write_text(json.dumps(cs,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(dict(encodings=encodings,contexts=cs),ensure_ascii=False))
