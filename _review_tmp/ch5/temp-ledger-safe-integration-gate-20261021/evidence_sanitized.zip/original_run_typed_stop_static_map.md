# Original run: static map and source gap

Original factorial_driver.py is authenticated at SHA256
2f956b9c1495d1026b23b219da059681b9cdd98fadb9233acf02154559ddf456.
No production module, run, main, temp_driver or solver was imported/executed.

run spans original lines63-100. It constructs the observer from the supplied driver,
then calls that observer after preparing prices. It records OUTER_ROUND_COMPLETED
through Budget.event. Its catch at94-96 stores the exception type/reason/traceback
and derives sharedHardGate at95 from the E2_ substring. It writes first_error.json;
the new adapter does not execute or certify this original catch path.

main calls Budget at119, run at120 and budget.close at121. Its separate outer catch
at124 writes a hard-gate failure at126 when appropriate, then rethrows. This is a
distinct static path from run's internal text-based classification. The run's text
test alone is not the whole external escalation protocol.

Budget.guard checks the parent STOP file; run contains no authenticated shared STOP
publisher. temp_driver's observer begins admission before initialization/household
work and finishes or reports failure afterward. That module is static-only. Dynamic
runtime, bridge, external controller and reader implementations are not supplied
by the bounded original source gate and were not searched elsewhere.

The exact eight-basename archive census found only PARENT_STOP_REQUEST.json and
MAIN_STOP_PROCESS_RECEIPT.json. These historical documents are not controller source.
No supervisor.py, parent_supervisor.py, controller.py, parent_controller.py,
reader.py or stop_reader.py was found. REAL_SUPERVISOR_READER_SOURCE_UNAVAILABLE.

The new standalone typed catch adapter consumes the accepted protocol's retained
first error and structured classification, including plain checkpoint WinError5.
An unrelated fixture ValueError containing E2_ remains ordinary E1. Actual production
dispatch cannot be wired or certified without exact real controller sources.
RUN_TYPED_WIRING_SOURCE_GAP; standalone adapter static/fixture evidence is ready.
