"""Independent stdlib synthetic ledger. Never imports a production module or HA."""
from pathlib import Path
import os, json, hashlib, time, sys, ctypes
ROOT=Path(__file__).resolve().parent
ZERO="0"*64
MAX_EVENTS=50

def safe(path):
    p=Path(path).resolve()
    if p!=ROOT and ROOT not in p.parents: raise RuntimeError("OUTSIDE_SYNTHETIC_ROOT")
    return p

def canonical(obj):
    return json.dumps(obj,sort_keys=True,separators=(",",":"),ensure_ascii=True).encode()

def create(path,obj):
    p=safe(path)
    with p.open("xb") as f:
        f.write(canonical(obj)+b"\n");f.flush();os.fsync(f.fileno())

def first_failure(root,exc,phase):
    path=safe(root)/"first_failure.json"
    evidence={"phase":phase,"type":type(exc).__name__,"message":str(exc),"winerror":getattr(exc,"winerror",None),"time_ns":time.monotonic_ns()}
    try:create(path,evidence)
    except FileExistsError:pass
    return evidence

def read_events(root):
    path=safe(root)/"events.jsonl"
    data=path.read_bytes() if path.exists() else b""
    if data and not data.endswith(b"\n"):raise ValueError("TORN_JOURNAL")
    events=[];previous=ZERO
    for i,line in enumerate(data.splitlines(),1):
        event=json.loads(line);claim=event.pop("sha256")
        if event["seq"]!=i or event["previous_sha256"]!=previous:raise ValueError("CHAIN_SEQUENCE_OR_PREVIOUS")
        actual=hashlib.sha256(canonical(event)).hexdigest()
        if claim!=actual:raise ValueError("CHAIN_HASH")
        event["sha256"]=claim;events.append(event);previous=claim
    if len(events)>MAX_EVENTS:raise RuntimeError("SYNTHETIC_EVENT_LIMIT")
    return events

def expected_head(events):
    return {"seq":len(events),"sha256":events[-1]["sha256"] if events else ZERO}

def checkpoint(root):
    path=safe(root)/"current.json"
    return json.loads(path.read_bytes()) if path.exists() else {"seq":0,"sha256":ZERO}

def inspect(root):
    events=read_events(root);head=expected_head(events);cp=checkpoint(root);seq=cp["seq"]
    if not isinstance(seq,int) or seq<0 or seq>len(events):raise ValueError("CHECKPOINT_NOT_PREFIX")
    expected=events[seq-1]["sha256"] if seq else ZERO
    if cp["sha256"]!=expected:raise ValueError("CHECKPOINT_HASH_NOT_PREFIX")
    return {"status":"CONSISTENT" if cp==head else "RECOVERY_REQUIRED","events":events,"head":head,"checkpoint":cp}

class SimulatedCrash(RuntimeError):pass
class RecoveryRequired(RuntimeError):pass

def injected_winerror5(src,dst):
    error=PermissionError(13,"SYNTHETIC_INJECTED_ACCESS_DENIED")
    error.winerror=5
    raise error

class Ledger:
    def __init__(self,root):
        self.root=safe(root);self.root.mkdir(parents=True,exist_ok=True)
        self.lock=self.root/"writer.lock";self.fd=os.open(self.lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
        self.closed=False
    def close(self):
        if not self.closed:
            os.close(self.fd);self.lock.unlink();self.closed=True
    def _checkpoint(self,head,replace=os.replace):
        create(self.root/"current.next",head)
        replace(self.root/"current.next",self.root/"current.json")
    def append(self,kind,payload,*,after_append_crash=False,replace=os.replace):
        state=inspect(self.root)
        if state["status"]!="CONSISTENT":raise RecoveryRequired("EXPLICIT_RECONCILIATION_REQUIRED")
        if len(state["events"])>=MAX_EVENTS:raise RuntimeError("SYNTHETIC_EVENT_LIMIT")
        row={"seq":len(state["events"])+1,"previous_sha256":state["head"]["sha256"],"kind":kind,"payload":payload}
        row["sha256"]=hashlib.sha256(canonical(row)).hexdigest()
        with (self.root/"events.jsonl").open("ab") as f:
            f.write(canonical(row)+b"\n");f.flush();os.fsync(f.fileno())
        try:
            if after_append_crash:raise SimulatedCrash("AFTER_APPEND_BEFORE_CHECKPOINT")
            self._checkpoint(expected_head(state["events"]+[row]),replace)
        except Exception as exc:
            first_failure(self.root,exc,"APPEND_COMMITTED_CHECKPOINT_FAILED");raise
        return row
    def reconcile(self,*,acknowledge_gap=False):
        if not acknowledge_gap:raise RecoveryRequired("GAP_NOT_ACKNOWLEDGED")
        state=inspect(self.root);residual=self.root/"current.next"
        if residual.exists():
            if json.loads(residual.read_bytes())!=state["head"]:raise ValueError("RESIDUAL_NOT_CURRENT_JOURNAL_HEAD")
            quarantine=self.root/("current.next.reconciled.seq"+str(state["head"]["seq"]))
            if quarantine.exists():raise FileExistsError("QUARANTINE_ALREADY_EXISTS")
            residual.rename(quarantine)
        if state["status"]!="CONSISTENT":self._checkpoint(state["head"])
        return inspect(self.root)

def publish_stop(root,reason):
    path=safe(root)/"STOP.json"
    try:create(path,{"reason":reason,"time_ns":time.monotonic_ns(),"class":"SHARED_E2"})
    except FileExistsError:pass
    return json.loads(path.read_bytes())

def await_path(path,timeout=6.):
    path=safe(path);deadline=time.monotonic()+timeout
    while not path.exists():
        if time.monotonic()>deadline:raise TimeoutError("SYNTHETIC_BARRIER_TIMEOUT")
        time.sleep(.01)

def reader(root,profile):
    root=safe(root);target=root/"current.json";handle=None;file=None
    if profile=="python_readonly":
        file=target.open("rb");file.read()
    elif profile=="explicit_share_delete":
        if os.name!="nt":create(root/"ready.json",{"status":"NON_WINDOWS"});return
        from ctypes import wintypes
        kernel=ctypes.WinDLL("kernel32",use_last_error=True)
        kernel.CreateFileW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,wintypes.LPVOID,wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE]
        kernel.CreateFileW.restype=wintypes.HANDLE
        kernel.CloseHandle.argtypes=[wintypes.HANDLE];kernel.CloseHandle.restype=wintypes.BOOL
        handle=kernel.CreateFileW(str(target),0x80000000,7,None,3,0x80,None)
        if handle==ctypes.c_void_p(-1).value:raise ctypes.WinError(ctypes.get_last_error())
    else:raise ValueError("PROFILE_NOT_ALLOWED")
    try:
        create(root/"ready.json",{"status":"READ_HANDLE_HELD","profile":profile})
        await_path(root/"release.json")
    finally:
        if file is not None:file.close()
        if handle is not None:kernel.CloseHandle(handle)

def observer(root,label):
    root=safe(root)
    if label not in ["SYN_A2","SYN_A3"]:raise ValueError("LABEL_NOT_ALLOWED")
    create(root/(label+".ready.json"),{"state":"WAITING_BEFORE_SYNTHETIC_ENTRY"})
    deadline=time.monotonic()+6
    while time.monotonic()<deadline:
        if (root/"STOP.json").exists():
            create(root/(label+".stopped.json"),{"state":"STOP_BEFORE_ENTRY","observed_ns":time.monotonic_ns(),"synthetic_entry_markers":0});return
        if (root/"next_gate.json").exists():
            # Check at the boundary again, never call any scientific function.
            if (root/"STOP.json").exists():continue
            create(root/(label+".forbidden_marker.json"),{"state":"SYNTHETIC_MARKER_ONLY_NOT_HA"});return
        time.sleep(.01)
    raise TimeoutError("STOP_OBSERVER_TIMEOUT")

def main():
    if len(sys.argv)<2:raise ValueError("HELPER_ROLE_REQUIRED")
    role=sys.argv[1]
    if role=="reader":reader(ROOT/sys.argv[2],sys.argv[3])
    elif role=="observer":observer(ROOT/sys.argv[2],sys.argv[3])
    elif role=="short":
        code=int(sys.argv[2])
        if code not in [0,7]:raise ValueError("EXIT_NOT_ALLOWED")
        print("synthetic helper stdout");print("synthetic helper stderr",file=sys.stderr);raise SystemExit(code)
    elif role=="hang":time.sleep(10)
    else:raise ValueError("HELPER_ROLE_NOT_ALLOWED")
if __name__=="__main__":main()
