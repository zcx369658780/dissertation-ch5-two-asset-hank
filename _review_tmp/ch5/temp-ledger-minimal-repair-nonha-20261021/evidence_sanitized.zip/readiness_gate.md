# ISOLATED_REPAIR_REGRESSION_PASS__NOT_DEPLOYED

Final locked implementation passed T1-T6, J1 and J2 with paired identical synthetic
inputs, original versus derived candidate. Previous attempts are retained. Original
defects remain visible; negative/corruption rejection is an expected result.

- T1: three fresh directories, event chains and original duplicate-directory refusal.
- T2: original residual blocks retry; candidate verifies the owned staged head,
  commits it without a duplicate event, and retains the first PermissionError.
- T3: actual native owned-reader errors and both share flags are recorded. Closing
  handles permits verified candidate recovery, not historical root-cause proof.
- T4: original secondary finish masks the primary; candidate returns the identical
  primary object without false failed/completed checkpoint counts. Structured hard
  classification recognizes checkpoint WinError5; unrelated E1 stays non-hard.
- T5: existing STOP prevents even candidate memory charge. Cooperating publisher
  ACK follows the fenced commit and inert callback; a new admission is then denied.
- T6: original and patched owned crash helpers exit23 and are reaped. Both retain
  charged1/entered0/completed0/failed0/unresolved1 and reject constructor resume.
- J1: ten corrupt/ambiguous prefix, counter, current/stage cases are rejected by
  the candidate without modifying journal/checkpoint/staged data files.
- J2: repeated committed calls are no-ops; three recovery calls preserve exactly
  two event records, never marking an uncommitted stage as already committed.

PATCH_PREPARED_NOT_DEPLOYED. GLOBAL_SUPERVISOR_READER_UNVERIFIED.
PRODUCTION_RUNTIME_UNVERIFIED. Actual HA/HJB/KFE/GE/IRF/scientific-driver calls=0.
No A0-A3, model change, original production deployment or follow-up is authorized.

Remaining boundaries: independently obtaining private source bytes; real production
run wiring; cross-process supervisor/reader protocol; historical WinError5 cause;
diagnostic-write failure and power-loss qualification. These are not filled by
fixture PASS. Astra independently reviews integrity, scope and the implementation.
