import os,json,time,pathlib,hashlib,math,stat,threading
ROOT=pathlib.Path(__file__).parent.resolve()
class Halt(RuntimeError):pass
def enc(x):return json.dumps(x,ensure_ascii=False,separators=(",",":"),allow_nan=False).encode()
def put(name,obj):
 p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True)
 b=obj if isinstance(obj,bytes) else enc(obj)
 with open(p,"xb") as f:f.write(b);f.flush();os.fsync(f.fileno())
 if p.read_bytes()!=b:raise Halt("WRITE_READBACK")
 return hashlib.sha256(b).hexdigest()
def append(name,obj):
 p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);b=enc(obj)+b"\n"
 with open(p,"ab") as f:f.write(b);f.flush();os.fsync(f.fileno())
 with open(p,"rb") as f:f.seek(-len(b),2);seen=f.read()
 if seen!=b:raise Halt("APPEND_READBACK")
def snapshot_check():
 for old in json.loads((ROOT/"protected_before.json").read_text("utf-8")):
  s=pathlib.Path(old["path"]).stat()
  now={"size":s.st_size,"mtime_ns":s.st_mtime_ns,"inode":s.st_ino,"attributes":s.st_file_attributes}
  if any(now[k]!=old[k] for k in now):raise Halt("PROTECTED_METADATA_CHANGED")
 if ROOT.stat().st_file_attributes&stat.FILE_ATTRIBUTE_REPARSE_POINT:raise Halt("SCRATCH_REPARSE")
def trend_gate(rows):
 if len(rows)!=10:raise Halt("NEED_TEN_COMPLETE_ROUNDS")
 a=[r["max_KN_gap"] for r in rows[:3]];b=[r["max_KN_gap"] for r in rows[7:10]]
 c=[r["max_Y_gap"] for r in rows[:3]];d=[r["max_Y_gap"] for r in rows[7:10]]
 if not all(math.isfinite(x) for v in [a,b,c,d] for x in v):raise Halt("TREND_NONFINITE")
 ka=sum(a)/3;kb=sum(b)/3;ya=sum(c)/3;yb=sum(d)/3
 boundary=sum(bool(r["both_provinces_any_raw_outside"]) for r in rows[5:10])
 worsen=ka>0 and ya>0 and kb>=1.2*ka and yb>=1.2*ya and boundary>=4
 return {"decision":"EARLY_STOP_OBVIOUS_WORSENING_10" if worsen else "TREND_NOT_OBVIOUS_AT_10","first_KN_mean":ka,"last_KN_mean":kb,"first_Y_mean":ya,"last_Y_mean":yb,"relative_threshold":1.2,"both_raw_outside_rounds_6_10":boundary,"boundary_required":4,"remaining_safety_and_budget_required":True}
class Ledger:
 def __init__(self,folder="science"):
  self.folder=folder;self.c={"HA_attempts":0,"HJB_entries":0,"KFE_entries":0,"scalar_roots":0,"HJB_updates":0,"complete_rounds":0,"HA_by_province":[0,0]}
  self.seq=0;self.local={};self.failed=False;self.lock=threading.RLock();self.start=time.monotonic()
 def emit(self,kind,**x):
  self.seq+=1;append(self.folder+"/events.jsonl",{"seq":self.seq,"kind":kind,"monotonic":time.monotonic(),"counts":self.c.copy(),**x})
 def guard(self):
  if self.failed:raise Halt("TERMINAL_LATCHED")
  if (ROOT/"STOP_REQUEST.json").exists():self.failed=True;raise Halt("LOCAL_STOP_REQUESTED")
  if time.monotonic()-self.start>=14220:self.failed=True;raise Halt("SCIENCE_WALL_LIMIT")
  snapshot_check()
 def begin(self,province,round_no):
  with self.lock:
   self.guard()
   if not 1<=round_no<=20 or self.c["HA_attempts"]>=40 or self.c["HA_by_province"][province]>=20:raise Halt("HA_BUDGET")
   self.c["HA_attempts"]+=1;self.c["HA_by_province"][province]+=1
   self.local={"roots":0,"updates":0,"province":province,"round":round_no}
   self.emit("HA_ATTEMPT_CHARGED",province=province,round=round_no)
   self.guard()
 def root(self):
  self.guard()
  if self.local["roots"]>=400000 or self.c["scalar_roots"]>=16000000:raise Halt("ROOT_BUDGET")
  self.local["roots"]+=1;self.c["scalar_roots"]+=1
 def hjb(self):
  self.guard()
  if self.c["HJB_entries"]>=40:raise Halt("HJB_BUDGET")
  self.c["HJB_entries"]+=1;self.emit("HJB_ENTER",local=self.local.copy())
 def update(self):
  self.guard()
  if self.local["updates"]>=100:raise Halt("HJB_UPDATE_BUDGET")
  self.local["updates"]+=1;self.c["HJB_updates"]+=1
  if self.local["updates"]%10==0:self.emit("HJB_PROGRESS",local=self.local.copy())
 def kfe(self):
  self.guard()
  if self.c["KFE_entries"]>=40:raise Halt("KFE_BUDGET")
  self.c["KFE_entries"]+=1;self.emit("KFE_ENTER",local=self.local.copy())
 def terminal(self,kind,**x):
  self.failed=True;self.emit(kind,**x)
