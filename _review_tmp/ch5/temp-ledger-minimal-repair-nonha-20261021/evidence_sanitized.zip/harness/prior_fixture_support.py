"""Bounded original-method tests. No production module import, HA, or solver.

Ledger fields named HA are synthetic admission counters. They are distinct from
scientific call counters, which remain zero. Only task-owned journals are touched.
"""
import argparse
import ast
import base64
import ctypes
from ctypes import wintypes
import datetime
import hashlib
import json
import msvcrt
import os
from pathlib import Path
import pathlib
import struct
import subprocess
import sys
import threading
import time
import traceback
import types
from original_boundary import gate
from repair_support import RepairProtocol
import builtins
def instantiate_class(code, bindings):
    safe={k:getattr(builtins,k) for k in ["__build_class__","object","RuntimeError","AssertionError","BaseException","dict","len","str","int"]}
    ns={"__builtins__":safe,"__name__":"isolated_budget",**bindings}
    exec(code,ns)
    return ns["Budget"]

START = time.monotonic()
KERNEL = ctypes.WinDLL('kernel32', use_last_error=True)
KERNEL.CreateFileW.argtypes = [wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,
                              ctypes.c_void_p,wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE]
KERNEL.CreateFileW.restype = wintypes.HANDLE
KERNEL.CloseHandle.argtypes = [wintypes.HANDLE]
KERNEL.CloseHandle.restype = wintypes.BOOL
KERNEL.GetCurrentProcess.restype = wintypes.HANDLE
class MemoryCounters(ctypes.Structure):
    _fields_ = [('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD)] + [
        (n,ctypes.c_size_t) for n in ['PeakWorkingSetSize','WorkingSetSize',
        'QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage',
        'QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage']]
PSAPI = ctypes.WinDLL('psapi', use_last_error=True)
PSAPI.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE,ctypes.POINTER(MemoryCounters),wintypes.DWORD]
PSAPI.GetProcessMemoryInfo.restype = wintypes.BOOL

def sha(b): return hashlib.sha256(b).hexdigest()
def write_json(path, value): path.write_text(json.dumps(value, sort_keys=True)+'\n', encoding='utf-8')
def rss():
    m = MemoryCounters(); m.cb = ctypes.sizeof(m)
    if not PSAPI.GetProcessMemoryInfo(KERNEL.GetCurrentProcess(), ctypes.byref(m), m.cb):
        raise ctypes.WinError(ctypes.get_last_error())
    return {'rssBytes':m.WorkingSetSize,'basis':'OWN_CURRENT_PROCESS_NATIVE_WORKING_SET'}
def wall(): assert time.monotonic()-START < 150, 'HARNESS_RESOURCE_STOP'
def error(e): return {'type':type(e).__name__,'message':str(e),'errno':getattr(e,'errno',None),'winerror':getattr(e,'winerror',None)}

class ArrayBytes:
    def __init__(self, items): self.items = items
    def tobytes(self): return struct.pack('<'+('d'*len(self.items)), *self.items)
class InertArrayInterface:
    def asarray(self, items, dtype):
        assert dtype == '<f8' and len(items)==2
        return ArrayBytes(items)

def input_fixture():
    return {'round':2,'province_index':0,'rah':0.09,'w_eff':2.0,'tau_HA':0.0,
            'HA_SHA256':'B92F6EFC59D9398F89F8FB6EE67BF6C5F947282D76895051BEC194967EC9C3E3'}

class Context:
    def __init__(self, root, code, patched=False):
        self.root=root; root.mkdir(parents=True,exist_ok=False)
        self.folder=root/'arm'; self.folder.mkdir()
        self.io=[]; self.inject=False; self.before_replace=None
        rt={'wall_guard':wall,'rss':rss,'sha':sha,'write_json':write_json,
            'read_first':lambda:{'deadlineUtc':'INERT_DISPOSABLE_DEADLINE'}}
        self.protocol=RepairProtocol(root) if patched else None
        if patched:rt['repair']=self.protocol
        proxy=types.SimpleNamespace(getpid=os.getpid,fsync=self.fsync,replace=self.replace)
        self.cls=instantiate_class(code,{'runtime':rt,'R':root,'sys':sys,'os':proxy,
                 'json':json,'datetime':datetime,'msvcrt':msvcrt,'pathlib':pathlib})
        assert sys.getprofile() is None
        bound={'ha':types.SimpleNamespace(__file__=str(root/'INERT_NO_HA_MODULE')),
               'np':InertArrayInterface()}
        self.bound=bound;self.b=self.cls(bound,'INERT_ARM',self.folder)
        self.b.expected_price_bytes={0:struct.pack('<dd',0.09,2.0)}
        self.entered=0;self.completed=0
    def fsync(self,fd):
        self.io.append({'op':'fsync','at':time.monotonic_ns()});return os.fsync(fd)
    def replace(self,src,dst):
        self.io.append({'op':'replace_enter','at':time.monotonic_ns()})
        if self.before_replace: self.before_replace()
        if self.inject:
            self.inject=False
            raise ctypes.WinError(5)
        result=os.replace(src,dst)
        self.io.append({'op':'replace_return','at':time.monotonic_ns()});return result
    def stop(self):
        write_json(self.root/'PARENT_STOP_REQUEST.json',{'inert':True})
        return time.perf_counter_ns()
    def dummy_entry(self):
        self.entered+=1
        write_json(self.root/'INERT_ENTRY.json',{'not_science':True,'at':time.monotonic_ns()})
    def close(self):
        self.b.close();assert sys.getprofile() is None

def audit_journal(ctx):
    raw=(ctx.b.path/'events.jsonl').read_bytes();chain='0'*64;rows=[];heads={0:chain}
    for i,line in enumerate(raw.splitlines(keepends=True),1):
        row=json.loads(line);assert row['seq']==i and row['previousEventSHA256']==chain
        chain=sha(line);heads[i]=chain;rows.append(row)
    cp=json.loads((ctx.b.path/'current.json').read_bytes())
    assert cp['eventHeadSHA256']==heads[cp['seq']]
    return {'events':len(rows),'checkpoint_seq':cp['seq'],'checkpoint_valid_prefix':True,
            'checkpoint_counts':cp['counts'],'memory_counts':dict(ctx.b.counts),
            'active_memory':ctx.b.active,'active_checkpoint':cp['activeHA'],
            'next_exists':(ctx.b.path/'current.next').exists(),
            'charged_events':sum(q['event']=='HA_CHARGED_BEFORE_INITIALIZATION' for q in rows),
            'dummy_entered':ctx.entered,'dummy_completed':ctx.completed,
            'real_science_calls':0,'chain_verified':len(rows)}

def test_T1(run,code,expr):
    cases=[]
    for name in ['one','two','three']:
        c=Context(run/name,code)
        try:
            c.b.event('INERT_EVENT_1');c.b.event('INERT_EVENT_2')
            q=audit_journal(c);assert q['events']==q['checkpoint_seq']==3
            assert [x['op'] for x in c.io[-4:]]==['fsync','fsync','replace_enter','replace_return']
            cases.append({'case':name,'verdict':'REAL_ORIGINAL_METHOD_PASS','journal':q,'fsync_checkpoint_order':True})
            if name=='one':
                try:c.cls(c.bound,'INERT_SECOND_WRITER',c.folder)
                except FileExistsError as e:cases.append({'case':'second_writer_same_directory','verdict':'REAL_ORIGINAL_METHOD_PASS','error':error(e),'mechanism':'constructor_mkdir_existing_directory'})
                else:raise AssertionError('second writer admitted')
        finally:c.close()
    return cases

def test_T2(run,code,expr):
    c=Context(run/'replace_fault',code)
    try:
        c.inject=True
        try:c.b.event('INERT_AFTER_APPEND_FAULT')
        except PermissionError as e:first=error(e)
        else:raise AssertionError('injection absent')
        q=audit_journal(c);assert q['events']==2 and q['checkpoint_seq']==1 and q['next_exists']
        try:c.b.checkpoint()
        except FileExistsError as e:second=error(e)
        else:raise AssertionError('original silently reconciled residual')
        return [{'case':'replace_failure_after_append','verdict':'ORIGINAL_METHOD_DEFECT_REPRODUCED','first_error':first,'fault':'INJECTED_AT_REAL_REPLACE_BOUNDARY','journal':q},
                {'case':'unaltered_checkpoint_retry','verdict':'ORIGINAL_METHOD_DEFECT_REPRODUCED','second_error':second,'journal':audit_journal(c),'original_recovery':'ABSENT','harness_recovery':'NOT_ATTEMPTED'}]
    finally:c.close()

def held_handle(path,share):
    handle=KERNEL.CreateFileW(str(path),0x80000000,share,None,3,0x80,None)
    if handle==ctypes.c_void_p(-1).value:raise ctypes.WinError(ctypes.get_last_error())
    return handle

def test_T3(run,code,expr):
    cases=[]
    c=Context(run/'control',code)
    try:
        c.b.event('INERT_NO_READER');cases.append({'case':'no_reader','verdict':'REAL_ORIGINAL_METHOD_PASS','journal':audit_journal(c)})
    finally:c.close()
    for label,share in [('read_write_no_delete',3),('read_write_delete',7)]:
        c=Context(run/label,code);handle=held_handle(c.b.path/'current.json',share);native=None
        try:
            try:c.b.event('INERT_HELD_READER')
            except OSError as e:native=error(e)
        finally:
            assert KERNEL.CloseHandle(handle)
            released=time.monotonic_ns()
        try:
            q=audit_journal(c)
            cases.append({'case':label,'verdict':'ORIGINAL_METHOD_DEFECT_REPRODUCED' if native else 'REAL_ORIGINAL_METHOD_PASS',
                          'desired_access':'0x80000000_GENERIC_READ','share_mode':share,'creation_disposition':3,'flags_attributes':128,
                          'native_error':native,'WinError5':'REPRODUCED_CONTROLLED_ONLY' if native and native['winerror']==5 else 'NOT_REPRODUCED',
                          'handle_closed':True,'release_at':released,'journal':q})
            if share==3:
                if native:
                    try:c.b.checkpoint()
                    except FileExistsError as e:residual=error(e)
                    else:raise AssertionError('expected residual evidence')
                    # Explicit wrapper-only repair of this new disposable fixture.
                    os.replace(c.b.path/'current.next',c.b.path/'current.json')
                    c.b.event('INERT_AFTER_WRAPPER_RECONCILIATION')
                    cases.append({'case':'release_then_wrapper_reconcile','verdict':'WRAPPER_ONLY','original_retry_error':residual,'after':audit_journal(c)})
                else:cases.append({'case':'release_reconcile_unneeded','verdict':'UNOBSERVED','reason':'No native denial occurred'})
        finally:c.close()
    assert len(cases)<=4
    return cases

def test_T4(run,code,expr):
    c=Context(run/'finish_fault',code)
    try:
        c.inject=True
        try:c.b.begin_ha(2,0,input_fixture())
        except PermissionError as e:first=error(e)
        else:raise AssertionError('first failure not observed')
        try:c.b.finish(False,{'inert_first_error':first['type']})
        except FileExistsError as e:second=error(e)
        else:raise AssertionError('secondary checkpoint failure absent')
        q=audit_journal(c);assert q['events']==3 and q['checkpoint_seq']==1 and q['active_memory']==1 and q['memory_counts']['HA_failed']==1
        classify=lambda exc:eval(expr,{'__builtins__':{'str':str}},{'exc':exc})
        native=ctypes.WinError(5);flag=classify(native);typed=classify(RuntimeError('E2_INERT'))
        assert flag is False and typed is True
        return [{'case':'primary_and_secondary_checkpoint_failure','verdict':'ORIGINAL_METHOD_DEFECT_REPRODUCED','first_error':first,'secondary_error':second,'journal':q,'primary_retained_by':'HARNESS_PRIVATE_CAPTURE','original_finish_did_not_return':True},
                {'case':'original_pure_classifier_expression','verdict':'ORIGINAL_METHOD_DEFECT_REPRODUCED','plain_WinError5_sharedHardGate':flag,'E2_token_sharedHardGate':typed,'run':'SOURCE_STATIC_ONLY_NOT_RUNTIME_VERIFIED'}]
    finally:c.close()

def test_T5(run,code,expr):
    cases=[];c=Context(run/'preexisting_stop',code)
    try:
        c.stop()
        try:c.b.guard()
        except RuntimeError as e:guard_error=error(e)
        else:raise AssertionError('STOP guard missed')
        try:
            c.b.begin_ha(2,0,input_fixture());c.dummy_entry()
        except RuntimeError as e:admission_error=error(e)
        else:raise AssertionError('preexisting STOP admitted')
        q=audit_journal(c)
        assert q['memory_counts']['HA']==1 and q['checkpoint_counts']['HA']==0 and q['charged_events']==0 and q['dummy_entered']==0
        cases.append({'case':'preexisting_stop','verdict':'ORIGINAL_METHOD_DEFECT_REPRODUCED','guard':'REAL_ORIGINAL_METHOD_PASS','guard_error':guard_error,'admission_error':admission_error,'journal':q,'finding':'memory_increment_precedes_event_guard_but_no_durable_charge_or_entry'})
    finally:c.close()
    c=Context(run/'admission_race',code);trigger=threading.Event();done=threading.Event();timing={};thread_error=[]
    def publish_stop():
        try:
            assert trigger.wait(5);timing['STOP_published']=c.stop()
        except BaseException as e:thread_error.append(error(e))
        finally:done.set()
    reader=threading.Thread(target=publish_stop,name='owned_inert_stop_publisher')
    reader.start()
    def boundary():
        trigger.set();assert done.wait(5);assert not thread_error
    c.before_replace=boundary
    try:
        path=c.b.begin_ha(2,0,input_fixture());timing['begin_return']=time.perf_counter_ns()
        c.dummy_entry();timing['dummy_entry_return']=time.perf_counter_ns()
        reader.join(5);assert not reader.is_alive()
        q=audit_journal(c);assert q['charged_events']==1 and q['checkpoint_counts']['HA']==1 and q['dummy_entered']==1
        write_json(run/'race_timing_raw.json',{'clock':'perf_counter_ns','timing':timing,'synchronization':'STOP publisher sets done before replace returns'})
        assert timing['STOP_published']<=timing['begin_return']<=timing['dummy_entry_return']
        cases.append({'case':'STOP_between_guard_append_and_checkpoint_commit','verdict':'STOP_UNSAFE','journal':q,'timing':timing,
                      'finding':'append_precedes_STOP_checkpoint_and_inert_entry_return_after_STOP','global_supervisor_atomicity':'NOT_VERIFIED','owned_thread_joined':True})
        try:c.b.guard()
        except RuntimeError as e:cases.append({'case':'subsequent_guard','verdict':'REAL_ORIGINAL_METHOD_PASS','error':error(e),'additional_dummy_entry':0})
        else:raise AssertionError('subsequent STOP missed')
    finally:
        trigger.set();reader.join(5);assert not reader.is_alive();c.close()
    return cases

def test_T6(run,code,expr):
    worker_root=run/'worker_case'
    args=[sys.executable,'-B',str(Path(__file__).resolve()),'--root',str(TASK_ROOT),'--group','T6','--worker',str(worker_root)]
    proc=subprocess.Popen(args,executable=sys.executable,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=False)
    try:out,err=proc.communicate(timeout=30)
    except subprocess.TimeoutExpired:
        proc.kill();out,err=proc.communicate(timeout=5);raise
    (run/'worker.stdout').write_bytes(out);(run/'worker.stderr').write_bytes(err)
    assert proc.returncode==23 and proc.poll()==23
    pseudo=types.SimpleNamespace(b=types.SimpleNamespace(path=worker_root/'arm/science',counts={},active=None),entered=0,completed=0)
    q=audit_journal(pseudo);assert q['checkpoint_counts']['HA']==1 and q['checkpoint_counts']['HA_completed']==q['checkpoint_counts']['HA_failed']==0 and q['active_checkpoint']==1
    cls=instantiate_class(code,{'runtime':{},'R':worker_root,'sys':sys,'os':os,'json':json,'datetime':datetime,'msvcrt':msvcrt,'pathlib':pathlib})
    try:cls({},'INERT_RESTART',worker_root/'arm')
    except FileExistsError as e:restart=error(e)
    else:raise AssertionError('original constructor resumed journal')
    with (worker_root/'arm/science/writer.lock').open('r+b',buffering=0) as lock:
        msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1);lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
    return [{'case':'controlled_worker_exit','verdict':'REAL_ORIGINAL_METHOD_PASS','exit_code':23,'owned_helpers_started':1,'owned_helpers_reaped':1,'live_owned_helpers':0,'stdout_sha256':sha(out),'stderr_sha256':sha(err)},
            {'case':'read_only_reconstruction','verdict':'WRAPPER_ONLY','journal':q,'charged':1,'entered':0,'completed':0,'failed':0,'interrupted_unresolved':1},
            {'case':'original_constructor_restart','verdict':'ORIGINAL_METHOD_DEFECT_REPRODUCED','error':restart,'resume_supported':False},
            {'case':'native_lock_after_process_exit','verdict':'REAL_ORIGINAL_METHOD_PASS','own_lock_reacquired_and_released':True}]

def install_audit(root):
    def hook(event,args):
        if event=='open' and not isinstance(args[0],int):
            path=Path(os.fsdecode(args[0])).absolute()
            mode=args[1] or '';flags=args[2] if len(args)>2 else 0
            writing=any(x in str(mode) for x in 'wax+') or bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
            if writing and path!=root and root not in path.parents:raise RuntimeError('STOP_UNSAFE_OUTSIDE_SCRATCH_WRITE')
            if not writing and root not in path.parents and path!=root and Path(sys.base_prefix) not in path.parents:
                raise RuntimeError('STOP_UNSAFE_UNAPPROVED_READ')
        if event=='import':
            name=args[0].split('.')[0]
            if name not in sys.stdlib_module_names and name!='original_boundary':raise RuntimeError('STOP_UNSAFE_DYNAMIC_IMPORT')
        if event in {'os.rename','os.remove','os.rmdir','os.mkdir'}:
            for item in (args[:2] if event=='os.rename' else args[:1]):
                path=Path(os.fsdecode(item)).absolute()
                if path!=root and root not in path.parents:raise RuntimeError('STOP_UNSAFE_PATH_MUTATION')
        if event=='subprocess.Popen':
            assert Path(args[0]).resolve()==Path(sys.executable).resolve()
            assert str(Path(__file__).resolve()) in args[1]
    sys.addaudithook(hook)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--group',choices=['T1','T2','T3','T4','T5','T6'],required=True);ap.add_argument('--worker');ap.add_argument('--attempt',type=int,choices=[1,2],default=1)
    a=ap.parse_args();TASK_ROOT=Path(a.root).resolve()
    params=json.loads((TASK_ROOT/'private/TASK_PARAMETERS.json').read_bytes())
    assert TASK_ROOT==Path(params['safe_execution']['new_scratch']) and os.name=='nt'
    pin=params['private_archive']['original_functional_modules'][0]
    code,expr,identity=gate(TASK_ROOT/'private/selected/00_factorial_driver.py',pin)
    install_audit(TASK_ROOT)
    if a.worker:
        worker=Path(a.worker).resolve();assert TASK_ROOT in worker.parents
        c=Context(worker,code);c.b.begin_ha(2,0,input_fixture())
        write_json(worker/'CONTROLLED_CRASH_READY.json',{'charged':1,'entered':0,'completed':0,'real_science_calls':0})
        os._exit(23)
    run=TASK_ROOT/'runs'/(a.group+'_attempt'+str(a.attempt));run.mkdir(exist_ok=False)
    write_json(run/'method_identity.json',identity)
    try:
        cases=globals()['test_'+a.group](run,code,expr)
        result={'group':a.group,'attempt':a.attempt,'harness':'COMPLETED','cases':cases,'case_count':len(cases),
                'original_method_bodies_unchanged':True,'production_module_imports':0,'real_science_calls':0,
                'supervisor_reader':'UNVERIFIED','elapsed_seconds':time.monotonic()-START}
        write_json(run/'results.json',result);print(json.dumps(result))
    except BaseException:
        (run/'unexpected_error.private.txt').write_text(traceback.format_exc(),encoding='utf-8');raise
