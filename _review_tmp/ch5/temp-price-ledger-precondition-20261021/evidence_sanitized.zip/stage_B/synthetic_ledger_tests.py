"""Six bounded synthetic groups; not a production ledger/HA test."""
from pathlib import Path
import json,os,sys,time,subprocess,hashlib,traceback
import synthetic_ledger_oracle as O
ROOT=Path(__file__).resolve().parent
RUN=ROOT/"attempt_01"
RESULTS=[]
CHILDREN=[]
MAX_LIVE=0
PRIVATE=None

def hashed(path):
    b=path.read_bytes()
    return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}

class Owned:
    def __init__(self,role,*args):
        global MAX_LIVE
        if role not in ["reader","observer","short","hang"]:raise ValueError("ROLE_NOT_ALLOWED")
        alive=sum(x.proc.poll() is None for x in CHILDREN)
        if alive>=2:raise RuntimeError("OWNED_CONCURRENCY_LIMIT")
        if len(CHILDREN)>=7:raise RuntimeError("OWNED_START_LIMIT")
        self.ordinal=len(CHILDREN)+1;self.role=role;self.reaped=False
        self.out=PRIVATE/("child_%02d.stdout"%self.ordinal);self.err=PRIVATE/("child_%02d.stderr"%self.ordinal)
        self.fo=self.out.open("xb");self.fe=self.err.open("xb")
        self.proc=subprocess.Popen([sys.executable,"-B",str(ROOT/"synthetic_ledger_oracle.py"),role,*args],cwd=ROOT,stdout=self.fo,stderr=self.fe,stdin=subprocess.DEVNULL,shell=False)
        CHILDREN.append(self);MAX_LIVE=max(MAX_LIVE,alive+1)
    def wait(self,expected=0):
        code=self.proc.wait(timeout=8)
        self.reaped=True;self.fo.close();self.fe.close()
        assert code==expected,(self.role,code,expected)
        return code
    def terminate(self):
        if self.proc.poll() is None:self.proc.terminate()
        self.proc.wait(timeout=3);self.reaped=True;self.fo.close();self.fe.close()
    def evidence(self):
        return {"owned_ordinal":self.ordinal,"role":self.role,"exit_code":self.proc.returncode,"reaped":self.reaped,"stdout":hashed(self.out),"stderr":hashed(self.err)}

def case_dir(n):
    p=RUN/n;p.mkdir();return p

def require_raises(typ,fn):
    try:fn()
    except typ as exc:return exc
    raise AssertionError("EXPECTED_EXCEPTION_NOT_RAISED:"+typ.__name__)

def group1():
    p=case_dir("G1");l=O.Ledger(p)
    try:
        require_raises(FileExistsError,lambda:O.Ledger(p))
        for i in range(4):l.append("SYNTHETIC_EVENT",{"value":i})
        st=O.inspect(p);assert st["status"]=="CONSISTENT" and st["checkpoint"]["seq"]==4
        for i,e in enumerate(st["events"],1):assert e["seq"]==i
        negative=case_dir("G1_corrupt");rows=[dict(e) for e in st["events"]];rows[1]["payload"]={"value":999}
        (negative/"events.jsonl").write_bytes(b"".join(O.canonical(e)+b"\n" for e in rows))
        require_raises(ValueError,lambda:O.read_events(negative))
        return {"inputs":{"events":4,"writers":1},"assertions":["exclusive second writer rejected","seq and previous SHA chain valid","checkpoint=head","payload tamper rejected"],"head":st["head"],"negative_case":"EXPECTED_REJECTION"}
    finally:l.close()

def group2():
    p=case_dir("G2");l=O.Ledger(p)
    try:
        l.append("FIRST",{"value":1});cp=(p/"current.json").read_bytes()
        require_raises(O.SimulatedCrash,lambda:l.append("SECOND",{"value":2},after_append_crash=True))
        assert (p/"current.json").read_bytes()==cp
        st=O.inspect(p);assert st["status"]=="RECOVERY_REQUIRED" and st["head"]["seq"]==2 and st["checkpoint"]["seq"]==1
        require_raises(O.RecoveryRequired,lambda:l.append("THIRD",{}))
        require_raises(O.RecoveryRequired,lambda:l.reconcile())
        first=hashed(p/"first_failure.json");l.close();l=O.Ledger(p)
        fixed=l.reconcile(acknowledge_gap=True);assert fixed["status"]=="CONSISTENT" and fixed["head"]["seq"]==2
        assert hashed(p/"first_failure.json")==first
        assert len(O.read_events(p))==2
        return {"inputs":{"fault":"AFTER_APPEND_BEFORE_CHECKPOINT"},"assertions":["checkpoint stayed seq1","append head seq2 retained","gap blocks writes","explicit reconciliation after reopen","no duplicate event or false completed event","first failure immutable"],"before":{"head":2,"checkpoint":1},"after":{"head":2,"checkpoint":2},"semantics":"RECOVERED_ACKNOWLEDGED_GAP_NOT_SILENT_SUCCESS"}
    finally:l.close()

def group3():
    observations=[]
    for profile in ["python_readonly","explicit_share_delete"]:
        p=case_dir("G3_"+profile);O.create(p/"current.json",{"seq":0})
        child=Owned("reader",str(p.relative_to(ROOT)),profile)
        try:
            O.await_path(p/"ready.json");O.create(p/"current.next",{"seq":1})
            try:os.replace(p/"current.next",p/"current.json");observed={"replace":"SUCCEEDED","winerror":None}
            except PermissionError as exc:
                O.first_failure(p,exc,"ACTUAL_NATIVE_REPLACE_WITH_READER_HELD")
                observed={"replace":"DENIED","winerror":getattr(exc,"winerror",None),"exception_type":type(exc).__name__}
                assert json.loads((p/"current.json").read_bytes())["seq"]==0 and (p/"current.next").exists()
            O.create(p/"release.json",{});child.wait()
            if (p/"current.next").exists():os.replace(p/"current.next",p/"current.json")
            assert json.loads((p/"current.json").read_bytes())["seq"]==1
            observations.append({"profile":profile,**observed,"reader_reaped":True,"after_reader_release_checkpoint":1})
        finally:
            if not child.reaped:child.terminate()
    real5=any(x["winerror"]==5 for x in observations)
    return {"inputs":{"reader_modes":["CPython read-only open","read-only native CreateFileW share=READ|WRITE|DELETE"],"changes_to_global_windows_settings":0},"assertions":["held readers synchronized before replace","native error/success captured","release then checkpoint advancement","own readers reaped"],"observations":observations,"real_WinError5":"REPRODUCED_IN_THIS_SYNTHETIC_FIXTURE" if real5 else "NOT_REPRODUCED","historical_root_cause":"UNPROVEN","platform":os.name}

def group4():
    p=case_dir("G4");l=O.Ledger(p)
    try:
        l.append("FIRST",{});before=(p/"current.json").read_bytes()
        require_raises(PermissionError,lambda:l.append("SECOND",{},replace=O.injected_winerror5))
        assert (p/"current.json").read_bytes()==before and (p/"current.next").exists()
        first=hashed(p/"first_failure.json");info=json.loads((p/"first_failure.json").read_bytes());assert info["winerror"]==5
        # A naive subsequent exclusive checkpoint write encounters the residual;
        # its failure cannot replace the immutable first diagnostic.
        exc=require_raises(FileExistsError,lambda:l._checkpoint(O.inspect(p)["head"]))
        O.first_failure(p,exc,"SECONDARY_RESIDUAL_ERROR")
        assert hashed(p/"first_failure.json")==first
        before_state=O.inspect(p);assert before_state["checkpoint"]["seq"]==1 and before_state["head"]["seq"]==2
        final=l.reconcile(acknowledge_gap=True)
        assert final["status"]=="CONSISTENT" and (p/"current.next.reconciled.seq2").exists()
        assert hashed(p/"first_failure.json")==first
        return {"inputs":{"replace_fault":"INJECTED_PermissionError_winerror_5"},"assertions":["real current seq1 not falsely advanced","append seq2 durable","current.next retained","secondary FileExistsError does not overwrite first failure","validated residual quarantined before explicit reconcile"],"injected_winerror":5,"before":{"head":2,"checkpoint":1},"after":{"head":2,"checkpoint":2},"real_native_reproduction_claim":False}
    finally:l.close()

def group5():
    shared=case_dir("G5_shared");fault=case_dir("G5_SYN_A1");children=[Owned("observer",str(shared.relative_to(ROOT)),label) for label in ["SYN_A2","SYN_A3"]]
    l=O.Ledger(fault)
    try:
        for label in ["SYN_A2","SYN_A3"]:O.await_path(shared/(label+".ready.json"))
        try:l.append("SYNTHETIC_NEXT_ENTRY_RESERVATION",{},replace=O.injected_winerror5)
        except PermissionError:stop=O.publish_stop(shared,"SYN_A1_CHECKPOINT_E2")
        else:raise AssertionError("MISSING_INJECTED_E2")
        O.create(shared/"next_gate.json",{"marker_only":True})
        observations=[]
        for label,child in zip(["SYN_A2","SYN_A3"],children):
            child.wait();o=json.loads((shared/(label+".stopped.json")).read_bytes())
            latency=(o["observed_ns"]-stop["time_ns"])/1e9
            assert 0<=latency<2 and o["synthetic_entry_markers"]==0
            assert not (shared/(label+".forbidden_marker.json")).exists()
            observations.append({"synthetic_arm":label,"stop_latency_seconds":latency,"synthetic_entry_markers":0,"reaped":True})
        assert O.inspect(fault)["checkpoint"]["seq"]==0 and O.inspect(fault)["head"]["seq"]==1
        return {"inputs":{"inert_controller_count":3,"real_HA_calls":0},"assertions":["SYN_A1 checkpoint E2 publishes shared STOP immediately","two own observers check STOP at next inert entry boundary","zero later synthetic entry markers","failed append not charged as successful checkpoint","all observers reaped"],"observations":observations,"production_transferability":"PRODUCTION_UNVERIFIED"}
    finally:
        l.close()
        for child in children:
            if not child.reaped:child.terminate()

def group6():
    a=Owned("short","0");a.wait()
    b=Owned("short","7");b.wait(expected=7)
    h=Owned("hang")
    try:
        try:h.proc.wait(timeout=.15)
        except subprocess.TimeoutExpired:h.terminate()
        else:raise AssertionError("HANG_FIXTURE_EARLY_EXIT")
    finally:
        if not h.reaped:h.terminate()
    assert len(CHILDREN)==7 and all(x.reaped and x.proc.poll() is not None for x in CHILDREN)
    assert a.out.read_bytes()==b"synthetic helper stdout\r\n" or a.out.read_bytes()==b"synthetic helper stdout\n"
    assert a.err.read_bytes()
    return {"inputs":{"normal_exit":0,"expected_negative_exit":7,"owned_hang_terminated":True},"assertions":["every actual helper start reserved and recorded","expected nonzero exit remains failure, not success","timeout terminates only owned Popen","all seven helper processes reaped","raw stdout/stderr retained privately; public gets byte/hash/summary"],"helper_starts":len(CHILDREN),"max_concurrent_helpers":MAX_LIVE,"max_total_python_in_test":MAX_LIVE+1,"kernel_descendants":"UNKNOWN","resources":[x.evidence() for x in CHILDREN]}

def main():
    global PRIVATE
    RUN.mkdir();PRIVATE=RUN/"private";PRIVATE.mkdir()
    fixtures={"schema":"synthetic_ledger_fixture_v1","science_calls":0,"max_events_per_ledger":50,"max_helpers":7,"max_concurrent_helpers":2,"groups":["chain","append_gap","held_readers","injected_replace","shared_stop","owned_reap"],"historical_input_files":[]}
    (ROOT/"synthetic_fixtures.json").write_text(json.dumps(fixtures,indent=2),encoding="utf-8")
    started=time.monotonic();unexpected=[]
    for n,fn in enumerate([group1,group2,group3,group4,group5,group6],1):
        begin=time.monotonic()
        try:
            detail=fn();row={"group":n,"status":"PASS","elapsed_seconds":time.monotonic()-begin,"detail":detail}
        except Exception as exc:
            raw=traceback.format_exc().encode();(PRIVATE/("group%d.traceback"%n)).write_bytes(raw)
            row={"group":n,"status":"FAIL","elapsed_seconds":time.monotonic()-begin,"error_type":type(exc).__name__,"error":str(exc).replace(str(ROOT),"<SYNTHETIC_ROOT>")};unexpected.append(row)
        RESULTS.append(row)
    for child in CHILDREN:
        if not child.reaped:child.terminate()
    output={"status":"SIMULATED_LEDGER_GATE_PASS__PRODUCTION_UNVERIFIED" if not unexpected else "SYNTHETIC_TEST_FAILURE","groups":RESULTS,"owned_child_starts":len(CHILDREN),"all_owned_children_reaped":all(x.reaped for x in CHILDREN),"max_concurrent_helpers":MAX_LIVE,"kernel_descendants":"UNKNOWN","real_science_calls":0,"elapsed_seconds":time.monotonic()-started,"unexpected_errors":unexpected,"production_ledger":"PRODUCTION_UNVERIFIED","source_hashes":{n:hashed(ROOT/n) for n in ["synthetic_ledger_oracle.py","synthetic_ledger_tests.py"]}}
    (ROOT/"synthetic_test_results.json").write_text(json.dumps(output,indent=2),encoding="utf-8")
    print(json.dumps({"status":output["status"],"groups":[{"group":x["group"],"status":x["status"],"detail":x.get("detail")} for x in RESULTS],"owned_child_starts":len(CHILDREN),"all_reaped":output["all_owned_children_reaped"]}))
    raise SystemExit(0 if not unexpected else 1)
if __name__=="__main__":main()
