"""Task-owned cooperating protocol, not a production supervisor/reader.

Only the Budget writer creates RepairProtocol once. Other actors attach with
their own Windows handle to its verified, stable byte-range lock file.
"""
import contextlib,hashlib,json,msvcrt,os,stat,threading,time
from pathlib import Path
from repair_support import LedgerFault,classify,strict

def sha(b):return hashlib.sha256(b).hexdigest()
def stable(path):
    st=path.lstat()
    if stat.S_ISLNK(st.st_mode) or getattr(st,'st_file_attributes',0)&1024:
        raise LedgerFault('REDIRECTION','attachment')
    if not stat.S_ISREG(st.st_mode):raise LedgerFault('NOT_REGULAR','attachment')
    return st

def exclusive_json(path,value):
    raw=(json.dumps(value,sort_keys=True)+'\n').encode()
    if path.exists():raise FileExistsError('OWNED_MARKER_ALREADY_EXISTS')
    stage=path.with_name(path.name+'.next')
    with stage.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    os.replace(stage,path)
    return raw

class Trace:
    def __init__(self,path,role):
        self.file=path.open('xb',buffering=0);self.role=role;self.seq=0
    def emit(self,kind,**data):
        self.seq+=1
        row={'role':self.role,'pid':os.getpid(),'seq':self.seq,'kind':kind,
             'qpc_ns':time.perf_counter_ns(),**data}
        raw=(json.dumps(row,sort_keys=True)+'\n').encode();assert self.file.write(raw)==len(raw);os.fsync(self.file.fileno());return row
    def close(self):self.file.close()

def make_descriptor(root,nonce):
    # Called only after the one writer's accepted constructor created the fence.
    f=root/'admission.fence';st=stable(f);raw=f.read_bytes()
    if raw!=b'1':raise LedgerFault('FENCE_BYTES','attachment')
    d={'nonce':nonce,'owner_pid':os.getpid(),'name':'admission.fence','ino':st.st_ino,
       'dev':st.st_dev,'bytes':len(raw),'sha256':sha(raw)}
    data=exclusive_json(root/'FENCE_READY.json',d)
    return d,sha(data)

class SharedFence:
    def __init__(self,root,descriptor_sha,nonce,owner_pid,trace):
        self.root=Path(root);self.trace=trace;self.mutex=threading.RLock();self.local=threading.local();self.on_blocked=None
        descriptor=self.root/'FENCE_READY.json';stable(descriptor);raw=descriptor.read_bytes()
        if sha(raw)!=descriptor_sha:raise LedgerFault('DESCRIPTOR_IDENTITY','attachment')
        self.descriptor=strict(raw)
        if self.descriptor.get('nonce')!=nonce or self.descriptor.get('owner_pid')!=owner_pid or self.descriptor.get('name')!='admission.fence':
            raise LedgerFault('OWNER_NONCE_IDENTITY','attachment')
        self.fingerprint=sha(json.dumps(self.descriptor,sort_keys=True).encode());self.validate()
        trace.emit('FENCE_ATTACHED',fence_identity_sha256=self.fingerprint,owner_pid=owner_pid)
    def validate(self,fd=None):
        path=self.root/'admission.fence';st=stable(path);d=self.descriptor
        if (st.st_ino,st.st_dev,st.st_size)!=(d['ino'],d['dev'],d['bytes']):raise LedgerFault('FENCE_FILE_IDENTITY','attachment')
        if fd is not None:
            fs=os.fstat(fd)
            if (fs.st_ino,fs.st_dev)!=(st.st_ino,st.st_dev):raise LedgerFault('FENCE_HANDLE_IDENTITY','attachment')
    @contextlib.contextmanager
    def fence(self):
        with self.mutex:
            depth=getattr(self.local,'depth',0)
            if depth:
                self.local.depth+=1
                try:yield
                finally:self.local.depth-=1
                return
            self.validate();f=(self.root/'admission.fence').open('r+b',buffering=0);deadline=time.monotonic()+12
            try:
                self.validate(f.fileno())
                contended=False
                while True:
                    try:f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1);break
                    except OSError:
                        if not contended:
                            contended=True;self.trace.emit('LOCK_CONTENDED')
                            if self.on_blocked:self.on_blocked()
                        if time.monotonic()>deadline:raise LedgerFault('FENCE_BUSY','attachment')
                        time.sleep(.005)
                self.validate(f.fileno());f.seek(0)
                if sha(f.read())!=self.descriptor['sha256']:raise LedgerFault('FENCE_CONTENT_IDENTITY','attachment')
                f.seek(0);self.local.depth=1;self.trace.emit('LOCK_ACQUIRED')
                try:yield
                finally:
                    self.local.depth=0;f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1);self.trace.emit('LOCK_RELEASED')
            finally:f.close()
    def read_stop(self):
        path=self.root/'PARENT_STOP_REQUEST.json';stable(path);raw=path.read_bytes();doc=strict(raw)
        if not isinstance(doc,dict) or set(doc)!={'status','nonce','owner_pid','fence_identity_sha256','request_id'}:
            raise LedgerFault('CORRUPT_STOP','STOP')
        if doc['status']!='STOP' or doc['nonce']!=self.descriptor['nonce'] or doc['owner_pid']!=self.descriptor['owner_pid'] or doc['fence_identity_sha256']!=self.fingerprint or doc['request_id']!=self.descriptor['nonce']:
            raise LedgerFault('STOP_IDENTITY','STOP')
        return doc,raw
    def read_ack(self,stop_raw):
        path=self.root/'STOP_ACK.json';stable(path);raw=path.read_bytes();doc=strict(raw)
        if doc!={'status':'ACK','stop_sha256':sha(stop_raw),'fence_identity_sha256':self.fingerprint}:
            raise LedgerFault('ACK_IDENTITY','STOP')
        return doc,raw
    def publish(self,attempt_recorded=False):
        if not attempt_recorded:self.trace.emit('STOP_ATTEMPT')
        with self.fence():
            target=self.root/'PARENT_STOP_REQUEST.json';stage=self.root/'PARENT_STOP_REQUEST.next';ack=self.root/'STOP_ACK.json'
            if stage.exists():raise LedgerFault('UNKNOWN_STOP_STAGE','STOP')
            if target.exists():
                doc,raw=self.read_stop();_,ack_raw=self.read_ack(raw)
                self.trace.emit('DUPLICATE_STOP_ACK',stop_sha256=sha(raw),ack_sha256=sha(ack_raw));return
            if ack.exists():raise LedgerFault('ORPHAN_ACK','STOP')
            doc={'status':'STOP','nonce':self.descriptor['nonce'],'owner_pid':self.descriptor['owner_pid'],
                 'fence_identity_sha256':self.fingerprint,'request_id':self.descriptor['nonce']}
            raw=exclusive_json(stage,doc);st=stable(stage)
            if stage.read_bytes()!=raw:raise LedgerFault('STOP_STAGE_IDENTITY','STOP')
            os.replace(stage,target)
            if target.read_bytes()!=raw:raise LedgerFault('STOP_READBACK','STOP')
            self.trace.emit('STOP_DURABLE',stop_sha256=sha(raw),durability='FILE_FSYNC_AND_ATOMIC_REPLACE_NOT_POWERLOSS_QUALIFIED')
            ack_raw=exclusive_json(ack,{'status':'ACK','stop_sha256':sha(raw),'fence_identity_sha256':self.fingerprint})
            self.trace.emit('STOP_ACK',stop_sha256=sha(raw),ack_sha256=sha(ack_raw))
    def observe(self):
        with self.fence():
            _,raw=self.read_stop();_,ack=self.read_ack(raw)
            self.trace.emit('READER_OBSERVED_STOP',stop_sha256=sha(raw),ack_sha256=sha(ack));return raw

def typed_catch_adapter(protocol,budget,exc,stage):
    """New safe handoff only. It never calls the real run or real supervisor."""
    primary=protocol.primary.get(id(budget))
    if primary:
        record=primary['record'];kind=record['classification'];cause=primary['exception']
    else:kind=classify(exc,stage);record={'type':type(exc).__name__,'stage':stage};cause=exc
    return {'primary_type':type(cause).__name__,'primary_stage':record['stage'],
            'sharedHardGate':kind['hard'],'code':kind['code'],'same_primary_object':cause is exc,
            'production_run_executed':False,'controller_dispatch':'NOT_CONNECTED_SOURCE_UNAVAILABLE'}
