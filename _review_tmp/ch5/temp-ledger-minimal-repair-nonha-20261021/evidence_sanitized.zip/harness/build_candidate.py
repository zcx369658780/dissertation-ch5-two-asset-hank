"""Build private minimal source replacement; never execute original module."""
import ast
import copy
import difflib
import hashlib
import json
from pathlib import Path

def canon(n):return ast.dump(n,include_attributes=False)
def build(root):
    source=root/'private/source/factorial_driver.py';raw=source.read_bytes();text=raw.decode();tree=ast.parse(raw)
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Budget');changes={};identities={}
    for old in cls.body:
        n=copy.deepcopy(old)
        if n.name=='guard':
            n.body.insert(0,ast.parse("runtime['repair'].owner(self)").body[0])
            for q in ast.walk(n):
                if isinstance(q,ast.Raise) and q.exc is not None:
                    q.exc=ast.parse("runtime['repair'].fault('STOP_ACK','guard')",mode='eval').body
        elif n.name=='event':
            body=ast.parse("runtime['repair'].pre_event(self)").body+n.body
            n.body=[ast.Try(body=body,handlers=[ast.ExceptHandler(type=ast.Name(id='BaseException',ctx=ast.Load()),name='exc',body=ast.parse("runtime['repair'].capture(self,exc,'event');raise").body)],orelse=[],finalbody=[])]
        elif n.name=='checkpoint':
            n.body=ast.parse("""try:
 plan=runtime['repair'].checkpoint_plan(self)
 if plan=='COMMITTED':
  return
 path=self.path/'current.next'
 if plan=='NEW':
  with path.open('xb') as f:
   f.write((json.dumps({'seq':self.seq,'counts':self.counts,'activeHA':self.active,'eventHeadSHA256':self.chain},sort_keys=True)+'\\n').encode())
   f.flush()
   os.fsync(f.fileno())
  runtime['repair'].remember_stage(self,path)
 os.replace(path,self.path/'current.json')
 runtime['repair'].committed(self)
except BaseException as exc:
 runtime['repair'].capture(self,exc,'checkpoint')
 raise
""").body
        elif n.name=='begin_ha':
            n.body=[ast.With(items=[ast.withitem(context_expr=ast.parse("runtime['repair'].admission(self)",mode='eval').body,optional_vars=None)],body=n.body)]
        elif n.name=='finish':
            # Persist the finished active state in its event, not as a different
            # checkpoint at the same event sequence.
            n.body=ast.parse("runtime['repair'].raise_primary(self)").body+[n.body[0],n.body[1],n.body[3],n.body[2],n.body[4]]
        ast.fix_missing_locations(n)
        identities[n.name]={'original':hashlib.sha256(canon(old).encode()).hexdigest(),'candidate':hashlib.sha256(canon(n).encode()).hexdigest(),'changed':canon(old)!=canon(n),'source_lines':[old.lineno,old.end_lineno]}
        if canon(old)!=canon(n):changes[n.name]=(old,n)
    assert set(changes)=={'guard','event','checkpoint','begin_ha','finish'}
    lines=text.splitlines(keepends=True)
    for name,(old,new) in sorted(changes.items(),key=lambda item:item[1][0].lineno,reverse=True):
        lines[old.lineno-1:old.end_lineno]=[' '*old.col_offset+line+'\n' for line in ast.unparse(new).splitlines()]
    candidate=''.join(lines);dest=root/'private_repaired_candidate/factorial_driver.py';dest.write_text(candidate,encoding='utf-8',newline='')
    patched=ast.parse(candidate);pc=next(n for n in patched.body if isinstance(n,ast.ClassDef) and n.name=='Budget')
    assert [canon(n) for n in tree.body if n is not cls]==[canon(n) for n in patched.body if n is not pc]
    for n in pc.body:assert hashlib.sha256(canon(n).encode()).hexdigest()==identities[n.name]['candidate']
    diff=''.join(difflib.unified_diff(text.splitlines(True),candidate.splitlines(True),fromfile='authenticated_private_original',tofile='private_derived_candidate'))
    (root/'private_repaired_candidate/ledger_minimal_repair.diff').write_text(diff,encoding='utf-8')
    report={'original_bytes':len(raw),'original_sha256':hashlib.sha256(raw).hexdigest(),'candidate_bytes':len(dest.read_bytes()),'candidate_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'methods':identities,'unchanged_outside_budget':True,'full_diff_sha256':hashlib.sha256(diff.encode()).hexdigest(),'deployment':'NOT_DEPLOYED'}
    (root/'public/safe_ast_patch_manifest.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    # Public diff gives only new hook changes; old private bodies remain private.
    public=[]
    for name,(old,new) in changes.items():
        public.extend(['@@ Budget.'+name+' @@\n','- [private original body retained only locally; original AST '+identities[name]['original']+']\n','+ [derived AST '+identities[name]['candidate']+']\n'])
    public.append('+ checkpoint: validate prefix/stage; skip committed; reuse only owned verified stage; retain replace error\n+ event: validate prior committed head; preserve first exception\n+ guard: validate owner and raise typed STOP\n+ begin_ha: same original body inside local admission fence\n+ finish: rethrow retained primary before secondary reporting\n')
    (root/'public/minimal_patch.diff.txt').write_text(''.join(public),encoding='utf-8')
    return report
