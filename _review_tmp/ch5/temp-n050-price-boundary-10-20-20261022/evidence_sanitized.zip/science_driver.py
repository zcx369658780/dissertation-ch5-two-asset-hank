import os,sys,json,pathlib,time,hashlib,types,traceback,math
sys.dont_write_bytecode=True
import numpy as np
from core import ROOT,put,append,Ledger,Halt,trend_gate,snapshot_check
module=types.ModuleType("mp");module.__path__=[str(ROOT/"model")];sys.modules["mp"]=module
from mp.stationary_runtime import mainline_initial_states
from mp.one_turn import prepare_mainline_household_states,PreFrozenHouseholdOutputBatch
from mp.temp_bridge import run_mainline_one_turn
from mp.steady_state import mainline_outer_diagnostics,_adapt
import exports.matlab_faithful_two_asset_ha as bb
import initializer
import postloop
def audit(event,args):
 if event in {"subprocess.Popen","os.system","os.posix_spawn"}:raise Halt("CHILD_PROCESS_FORBIDDEN")
 if event=="open" and not isinstance(args[0],int):
  mode=args[1];flags=args[2]
  writing=(isinstance(mode,str) and any(x in mode for x in "wax+")) or (isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
  if writing and not pathlib.Path(args[0]).resolve().is_relative_to(ROOT):raise Halt("OUT_OF_SCOPE_WRITE")
sys.addaudithook(audit)
qualification=json.loads((ROOT/"runner_qualification.json").read_text("utf-8"))
assert qualification["verdict"]=="PASS_TASK_OWNED_COOPERATING_RUNNER_ONLY"
arm=json.loads((ROOT/"science_driver_armed.json").read_text("utf-8"))
assert arm["driver_charged"]==1
put("science_driver_started.json",{"run_id":arm["run_id"],"pid":os.getpid(),"driver_starts":1,"unix":time.time()})
fixture=json.loads((ROOT/"fixture_trial.json").read_text("utf-8"))
assert fixture["population_N"]==[50,80]
ledger=Ledger();history=[];prices=[];quantities=[];decision={"decision":"NOT_REACHED_10_COMPLETE_ROUNDS"};terminal="UNSET";phase="INIT";first_error=None
p=fixture["parameters"];g=fixture["grid"]
grid=bb.MatlabFaithfulHJBGrid(np.linspace(g["b_min"],g["b_max"],20),np.linspace(g["a_min"],g["a_max"],20),np.array(g["z"]),np.array(g["z_transition_generator"]))
params=bb.EconomicParams(p["rho"],p["gamma_c"],p["phi_l"],p["chi_0"],p["chi_1"],p["a_bar"],0.,0.)
num=bb.MatlabFaithfulHJBNumerics(p["HJB_Delta"],1e-7,100,1e-12)
original_root=initializer._source_labor_root
def root_count(**kw):
 ledger.root();ledger.emit("SCALAR_ROOT_BEGIN",local=ledger.local.copy());return original_root(**kw)
initializer._source_labor_root=root_count
original_solve=bb.linalg.spsolve
def linear_solve(*a,**kw):
 if phase=="HJB":
  ledger.update();ledger.emit("HJB_UPDATE_BEGIN",local=ledger.local.copy())
 return original_solve(*a,**kw)
bb.linalg.spsolve=linear_solve
old_policy=bb.select_matlab_faithful_local_policy;cells=0
def policy(**kw):
 global cells
 cells+=1
 if cells%800==1:ledger.guard()
 return old_policy(**kw)
bb.select_matlab_faithful_local_policy=policy
original_hjb=bb.solve_matlab_faithful_hjb;original_kfe=bb.solve_matlab_faithful_stationary_kfe
def hjb(*a,**kw):
 global phase
 phase="HJB";ledger.hjb();return original_hjb(*a,**kw)
def kfe(*a,**kw):
 global phase
 phase="KFE";ledger.kfe();return original_kfe(*a,**kw)
def boundary(raw,lo,hi):
 return "ABOVE" if raw>hi else "BELOW" if raw<lo else "AT_BOUNDARY_EXACT" if raw==lo or raw==hi else "INSIDE"
def arrfile(name,a):return put(name,np.asarray(a,dtype="<f8").tobytes(order="F"))
states=mainline_initial_states(fixture);tkn=np.full(2,3.)
put("science/initial_states.json",{"states":states,"fixture_sha256":hashlib.sha256((ROOT/"fixture_trial.json").read_bytes()).hexdigest(),"N_only_exogenous_change":True,"numerics":{"delta":1000,"D_tolerance":1e-7,"iterations":100,"drift_tolerance":1e-12},"initializer_semantics":"unchanged accepted _source_initial_arrays including effective_return_squared; net wage via tau=0"})
try:
 for round_no in range(1,21):
  ledger.guard()
  states=prepare_mainline_household_states(states,fixture)
  entering=[dict(s) for s in states];out=[];ha=[]
  put("science/round_"+str(round_no)+"_entering.json",entering)
  for i,s in enumerate(entering):
   ledger.begin(i,round_no)
   if hashlib.sha256((ROOT/"exports/matlab_faithful_two_asset_ha.py").read_bytes()).hexdigest()!="b92f6efc59d9398f89f8fb6ee67bf6c5f947282d76895051bec194967ec9c3e3":raise Halt("BLACKBOX_IDENTITY_CHANGED")
   phase="INITIALIZATION"
   init_s=dict(s,w=s["w_eff"],tau=0.)
   initial,labor=initializer._source_initial_arrays(init_s,grid,params)
   h=bb.HouseholdInputs(s["rah"],s["rb"],0.,np.array([s["w_eff"]]),np.array([0.]),np.array([p["alphal"]]))
   receipt_prefix="science/ha_"+str(ledger.c["HA_attempts"])
   put(receipt_prefix+"_input.json",{"province":s["name"],"round":round_no,"rah":s["rah"],"rb":s["rb"],"w_eff":s["w_eff"],"tau_HA":0,"Tt":s["Tt"],"rb_gap":s["rb_gap"],"source_initializer_root_calls":ledger.local["roots"],"V0_sha256":hashlib.sha256(initial.tobytes(order="F")).hexdigest()})
   result=postloop.solve_matlab_source_postloop_household(grid,params,h,initial,labor,s["Tt"],s["rb_gap"],num,hjb_solver=hjb,kfe_solver=kfe)
   agg=result.aggregates;hj=result.hjb;kf=result.kfe
   arrays=[hj.value,hj.consumption,hj.labor,kf.density]
   if not all(np.isfinite(x).all() for x in arrays):raise Halt("HA_NONFINITE_ARRAY")
   mass=kf.density*kf.cell_weight;n=mass.size;gam=(n+64)*np.finfo(float).eps/(1-(n+64)*np.finfo(float).eps)
   bound=gam*max(1.,float(abs(mass).max()))
   if abs(float(mass.sum())-1)>gam or float(mass.min()) < -bound or float(-mass[mass<0].sum())>n*bound:raise Halt("KFE_UNUSABLE_MASS")
   if not np.isfinite([agg.c_ss,agg.l_ss,agg.a_ss,agg.b_ss,hj.convergence_statistic]).all() or agg.c_ss<=0 or agg.l_ss<0 or agg.a_ss<0:raise Halt("UNUSABLE_ASSETS_OR_LABOR")
   effective=bb.matlab_faithful_illiquid_return(grid.a,grid.a[-1],s["rah"])
   at_tax=agg.a_ss*s["rah"]-float(np.sum(grid.a[None,:,None]*effective[None,:,None]*kf.density)*kf.cell_weight)
   out.append((agg.c_ss,agg.l_ss,agg.a_ss,agg.b_ss,at_tax,bool(hj.converged)))
   bellman=float(abs(params.rho*hj.value.ravel(order="F")-hj.utility.ravel(order="F")-hj.post_convergence_operator.full@hj.value.ravel(order="F")).max())
   info={"province":s["name"],"round":round_no,"converged":bool(hj.converged),"HJB_terminal":"SOURCE_D_CONVERGED" if hj.converged else "SOURCE_MAX100_FINITE_NONCONVERGED","HJB_updates":int(hj.iterations),"D":float(hj.convergence_statistic),"Bellman_diagnostic_only":bellman,"KFE":"ORIGINAL_POSTLOOP_FINITE_MASS_QUALIFIED","mass_sum":float(mass.sum()),"minimum_mass":float(mass.min()),"mass_roundoff_bound":bound,"Ct":agg.c_ss,"Lt_HA_per_person":agg.l_ss,"At_per_person":agg.a_ss,"Bt_per_person":agg.b_ss,"AtTax":at_tax,"root_calls":ledger.local["roots"],"value_sha256":arrfile(receipt_prefix+"_V.f64",hj.value),"density_sha256":arrfile(receipt_prefix+"_density.f64",kf.density)}
   ha.append(info);put(receipt_prefix+"_terminal.json",info);ledger.emit("HA_COMPLETED",info=info)
   print(json.dumps({"round":round_no,"province":s["name"],"HA_completed":True,"HJB_converged":bool(hj.converged),"HJB_updates":hj.iterations,"D":hj.convergence_statistic}),flush=True)
  ledger.guard()
  batch=PreFrozenHouseholdOutputBatch(np.array([x[0] for x in out]),np.array([x[1] for x in out]),np.array([x[2] for x in out]),np.array([x[3] for x in out]),np.array([x[4] for x in out]),tuple(x[5] for x in out),tuple({"raw_HA_status":h["HJB_terminal"]} for h in ha))
  phase="MACRO";turn=run_mainline_one_turn(entering,batch,fixture);new=[dict(s) for s in turn["states"]]
  diagnostic=mainline_outer_diagnostics(new,tkn)
  if not np.isfinite(diagnostic["nk_gap"]+diagnostic["yt_gap"]).all():raise Halt("OUTER_NONFINITE_GAP")
  boundary_both=True;round_prices=[];round_quant=[]
  for i,(s,f,ns,hh) in enumerate(zip(entering,turn["firms"],new,ha)):
   re=boundary(f.ra0,s["ramin"],s["ramax"]);we=boundary(f.wt0,s["wjtmin"],s["wjtmax"])
   boundary_both=boundary_both and (re in ("ABOVE","BELOW") or we in ("ABOVE","BELOW"))
   row={"round":round_no,"province":s["name"],"N":s["N"],"raw_ra0":f.ra0,"used_ra":f.ra,"lower_ra":s["ramin"],"upper_ra":s["ramax"],"ra_event":re,"raw_wt0":f.wt0,"used_wjt":f.wjt,"lower_wjt":s["wjtmin"],"upper_wjt":s["wjtmax"],"wjt_event":we,"raw_ra_distance_lower":f.ra0-s["ramin"],"raw_ra_distance_upper":s["ramax"]-f.ra0,"raw_wt_distance_lower":f.wt0-s["wjtmin"],"raw_wt_distance_upper":s["wjtmax"]-f.wt0,"rk":f.rk,"divrate":f.PIt*(1-s["corptau"])/f.Kt,"rah_HA_entering":s["rah"],"rah_next":ns["rah"],"rah_reference_band":boundary(s["rah"],s["ramin"],s["ramax"]),"household_wage_field":"w_eff","household_wage_actual":s["w_eff"],"household_wage_next":ns["w_eff"],"household_wage_reference":boundary(s["w_eff"],s["wjtmin"],s["wjtmax"]),"household_actual_clip":"NOT_ACTUAL_CLIP","Zt_entering":s["Zt"],"GovInv_entering":s["GovInv"],"Kt":f.Kt,"Lt":f.Lt,"KN_gap":diagnostic["nk_gap"][i],"Y_gap":diagnostic["yt_gap"][i],"HA_status":hh["HJB_terminal"],"HJB_D":hh["D"],"KFE":hh["KFE"]}
   qr={"round":round_no,"province":s["name"],"Zt":s["Zt"],"alpha":s["alpha"],"mt":f.mt,"Kt":f.Kt,"Kprivate":float(turn["capital"].destination_private_productive_capital[i]),"GovInv":s["GovInv"],"Lt_firm":f.Lt,"Kt_div_Lt":f.Kt/f.Lt,"Yt":f.Yt,"N":s["N"],"At_per_person":float(batch.at[i]),"At_times_N":s["N"]*float(batch.at[i]),"household_labor_per_person":float(batch.household_lt[i]),"household_labor_total":s["N"]*float(batch.household_lt[i]),"household_labor_field":"Lt_HA=aggregates.l_ss","Lst":"UNMAPPED_HOUSEHOLD_LABOR_SUPPLY_LABEL","rah_used":s["rah"],"household_wage_used":s["w_eff"],"Lt_mat_destination_origin":turn["migration"].lt_mat.tolist(),"Lt_mat_destination_sum":float(turn["migration"].lt_mat[i].sum()),"Lt_mat_origin_sum":float(turn["migration"].lt_mat[:,i].sum()),"firm_Lt_minus_destination_sum":f.Lt-float(turn["migration"].lt_mat[i].sum()),"Kt_minus_Kprivate_GovInv":f.Kt-float(turn["capital"].destination_private_productive_capital[i])-s["GovInv"],"same_S_capital_conservation_residual":turn["capital"].national_private_capital_conservation_residual,"same_S":turn["shares"].tolist(),"lagged_raw_score":turn["lagged_score"].tolist(),"firm_minus_origin_HA_labor_total":f.Lt-s["N"]*float(batch.household_lt[i]),"timing":"HA entering rah/w_eff; HA terminal aggregates; same-round firm and Lt_mat"}
   round_prices.append(row);round_quant.append(qr)
  before_adapt=[dict(s) for s in new]
  if diagnostic["OUTER_ITERATION_CONVERGED"]:actions=()
  else:new,actions=_adapt(new,max(diagnostic["nk_gap"]),True);tkn=np.array([.6*s["KNratio"]+.4*tkn[i] for i,s in enumerate(new)])
  for i in range(2):
   round_prices[i].update(Zt_next=new[i]["Zt"],GovInv_next=new[i]["GovInv"])
   round_quant[i].update(Zt_next=new[i]["Zt"],GovInv_next=new[i]["GovInv"])
  record={"round":round_no,"max_KN_gap":max(diagnostic["nk_gap"]),"max_Y_gap":max(diagnostic["yt_gap"]),"both_provinces_any_raw_outside":boundary_both,"diagnostic":diagnostic,"prices":round_prices,"quantities":round_quant,"before_adapt":before_adapt,"next_states":new,"adapt":[vars(x) for x in actions]}
  ledger.guard();put("science/checkpoint_round_"+str(round_no)+".json",record);append("science/trajectory.jsonl",record)
  prices+=round_prices;quantities+=round_quant;history.append(record);ledger.c["complete_rounds"]=round_no;ledger.emit("ROUND_COMPLETED",round=round_no)
  states=tuple(new)
  print(json.dumps({"complete_round":round_no,"max_KN_gap":record["max_KN_gap"],"max_Y_gap":record["max_Y_gap"]}),flush=True)
  if diagnostic["OUTER_ITERATION_CONVERGED"]:terminal="TEMP_SOURCE_RULE_CONVERGED";break
  if round_no==10:
   decision=trend_gate(history);put("science/decision_at_10.json",decision);print(json.dumps(decision),flush=True)
   if decision["decision"]=="EARLY_STOP_OBVIOUS_WORSENING_10":terminal=decision["decision"];break
   ledger.guard()
  if round_no==20:terminal="TEMP_MAX20_COMPLETED_NONCONVERGED"
except BaseException as e:
 first_error={"type":type(e).__name__,"message":str(e),"phase":phase,"round_in_progress":len(history)+1,"counts":ledger.c,"traceback":traceback.format_exc()}
 terminal="STOP_"+str(e) if isinstance(e,Halt) else "STOP_SCIENTIFIC_EXCEPTION"
 put("science/FIRST_SCIENCE_ERROR.json",first_error)
finally:
 ledger.terminal("SCIENCE_TERMINAL",actual_terminal=terminal)
 put("science/driver_terminal.json",{"run_id":arm["run_id"],"science_terminal":terminal,"complete_outer_rounds":len(history),"decision_at_10":decision,"counts":ledger.c,"first_error":first_error,"HA_HJB_qualification":"per-attempt source flags; finite nonconverged permitted only for TEMP feedback","production_GLOBAL_STOP":"UNVERIFIED","Results":False,"V011":"NOT_STARTED"})
 print(json.dumps({"science_terminal":terminal,"complete_rounds":len(history),"counts":ledger.c}),flush=True)
sys.exit(0 if first_error is None else 2)
