# Original checkpoint and exception behavior

T2 injects one PermissionError/WinError5 at the ORIGINAL os.replace boundary.
The event was appended and fsynced, but current.json remained seq1 while the
event head/current.next advanced to seq2. An unchanged checkpoint retry failed
with FileExistsError because exclusive current.next creation sees the residual.
There is no original local reconciliation or retry-cleanup branch. This is a
controlled injected denial, distinct from the native observations in T3.

T3 no-reader replacement succeeded. Owned CreateFileW GENERIC_READ handles with
share=3 (READ|WRITE) and share=7 (READ|WRITE|DELETE), OPEN_EXISTING and attributes128
both yielded actual PermissionError/WinError5 at original os.replace. Handles were
closed. These results do NOT show that adding FILE_SHARE_DELETE cures replacement,
or identify the historical PowerShell handle cause. No Windows global setting was
changed. Closing the reader alone did not reconcile current.next. One explicit
harness-only os.replace of the disposable residual, followed by an original event,
demonstrated a WRAPPER_ONLY recovery control; it is not original recovery PASS.

T4 injected a primary begin_ha checkpoint failure. finish(False) then appended an
error event and incremented HA_failed but failed again at the residual next file;
current remained seq1, events reached seq3 and active stayed1. The harness keeps
both exceptions. The original finish did not return, so its active-clear statement
was not reached. This supports a primary-error masking risk; it does not execute
or certify the full production catch path.

The exact AST-extracted pure run classifier maps plain WinError5 to false and an
E2_ token error to true. Full run/main are SOURCE_STATIC_ONLY_NOT_RUNTIME_VERIFIED.
Typed escalation and prefix/residual recovery are future design requirements,
not implemented fixes or permission to change production.
