"""Six bounded groups; all processes are task-owned inert fixtures."""
import argparse,ast,copy,ctypes,hashlib,json,msvcrt,os,pathlib,subprocess,sys,symtable,time,traceback,types
from pathlib import Path
import prior_fixture_support as fixture
from original_boundary import gate,canonical,EXPECTED_GLOBALS
from repair_support import LedgerFault,classify
from safe_cross_process_adapter import SharedFence,Trace,make_descriptor,exclusive_json,typed_catch_adapter

def sha(b):return hashlib.sha256(b).hexdigest()
def save(path,obj):path.write_text(json.dumps(obj,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def wait_file(path,seconds=15):
    end=time.monotonic()+seconds
    while not path.exists():
        if time.monotonic()>end:raise TimeoutError('OWNED_FIXTURE_HANDSHAKE_TIMEOUT')
        time.sleep(.005)
def catch(fn):
    try:fn()
    except BaseException as e:return e
    return None

def budget_code(root):
    p=json.loads((root/'private/TASK_PARAMETERS.json').read_bytes());pin=p['original_archive']['fixed_python_members'][0]
    gate(root/'private/source/factorial_driver.py',pin) # static original gate, module not executed
    data=(root/'private_candidate/factorial_driver.py').read_bytes();assert len(data)==p['prior_patch']['bytes'] and sha(data)==p['prior_patch']['sha256']
    tree=ast.parse(data);budget=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='Budget');limits=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='limits');identity=json.loads((root/'private/prior/safe_ast_patch_manifest.json').read_bytes())
    for n in budget.body:
        assert sha(canonical(n).encode())==identity['methods'][n.name]['candidate']
        table=symtable.symtable(ast.unparse(n),'<symbols>','exec').get_children()[0]
        assert {v.get_name() for v in table.get_symbols() if v.is_global() and v.is_referenced()}<=EXPECTED_GLOBALS|{'BaseException'}
    assert not any(isinstance(n,(ast.Import,ast.ImportFrom,ast.Global,ast.Nonlocal)) for n in ast.walk(budget))
    return compile(ast.fix_missing_locations(ast.Module(body=[copy.deepcopy(limits),copy.deepcopy(budget)],type_ignores=[])),'<isolated-accepted-budget>','exec')

def actor(root,case,role,nonce,owner,descriptor_hash):
    writer_root=case/'writer';trace=Trace(case/(role+'.jsonl'),role)
    try:
        if role in ['writer','crash']:
            ctx=fixture.Context(writer_root,budget_code(root),patched=True)
            try:
                desc,h=make_descriptor(writer_root,nonce);shared=SharedFence(writer_root,h,nonce,os.getpid(),trace)
                # Explicit fixture-only fence binding; accepted source bytes/AST unchanged.
                ctx.protocol.fence=shared.fence
                exclusive_json(case/'WRITER_READY.json',{'owner_pid':os.getpid(),'descriptor_sha256':h})
                if role=='crash':
                    with shared.fence():
                        ctx.b.begin_ha(2,0,fixture.input_fixture())
                        trace.emit('CHARGE_COMMITTED',count=ctx.b.counts['HA']);os._exit(23)
                wait_file(case/'ALLOW_ADMISSION.json')
                def checkpoint_boundary():
                    exclusive_json(case/'AT_CHECKPOINT.json',{'inert':True})
                    wait_file(case/'PUBLISHER_BLOCKED.json')
                ctx.before_replace=checkpoint_boundary
                def inert_entry():
                    cp=json.loads((ctx.b.path/'current.json').read_bytes());assert cp['counts']['HA']==ctx.b.counts['HA']==1
                    trace.emit('CHARGE_COMMITTED',charged=1,checkpoint_seq=cp['seq'])
                    ctx.dummy_entry();trace.emit('INERT_ENTRY_RETURN',entered=ctx.entered)
                ctx.protocol.admit_and_enter(ctx.b,fixture.input_fixture(),inert_entry)
                wait_file(writer_root/'STOP_ACK.json')
                with shared.fence():shared.read_ack(shared.read_stop()[1])
                late=catch(lambda:ctx.protocol.admit_and_enter(ctx.b,fixture.input_fixture(),inert_entry));assert late is not None
                trace.emit('POST_ACK_ADMISSION_DENIED',error_type=type(late).__name__,memory_HA=ctx.b.counts['HA'])
                journal=fixture.audit_journal(ctx);assert journal['charged_events']==journal['checkpoint_counts']['HA']==ctx.entered==1
                save(case/'writer_result.json',{'journal':journal,'new_charge_after_ACK':0,'new_entry_after_ACK':0,'error_type':type(late).__name__,'real_science_calls':0})
            finally:ctx.close()
        else:
            shared=SharedFence(writer_root,descriptor_hash,nonce,owner,trace)
            if role=='publisher':
                wait_file(case/'AT_CHECKPOINT.json');trace.emit('STOP_ATTEMPT')
                shared.on_blocked=lambda:exclusive_json(case/'PUBLISHER_BLOCKED.json',{'pid':os.getpid()})
                shared.publish(attempt_recorded=True);save(case/'publisher_result.json',{'STOP_ACK':True,'constructor_called':False})
            elif role=='reader':
                wait_file(writer_root/'PARENT_STOP_REQUEST.json');shared.observe();save(case/'reader_result.json',{'observed_valid_STOP_and_ACK':True,'constructor_called':False})
    finally:trace.close()

def spawn(args):
    ledger=root/'private/operations/helper_start_ledger.jsonl'
    role=args[args.index('--actor')+1]
    with ledger.open('ab',buffering=0) as f:f.write((json.dumps({'phase':'PRECHARGE','role':role,'parent_pid':os.getpid()})+'\n').encode());os.fsync(f.fileno())
    proc=subprocess.Popen([sys.executable,'-B',str(Path(__file__).resolve()),*args],executable=sys.executable,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=False)
    with ledger.open('ab',buffering=0) as f:f.write((json.dumps({'phase':'STARTED','role':role,'parent_pid':os.getpid(),'pid':proc.pid})+'\n').encode());os.fsync(f.fileno())
    return proc
def reap(proc,base,expected=0):
    timed_out=False
    try:out,err=proc.communicate(timeout=30)
    except subprocess.TimeoutExpired:
        timed_out=True;proc.kill();out,err=proc.communicate(timeout=5)
    base.with_suffix('.stdout').write_bytes(out);base.with_suffix('.stderr').write_bytes(err)
    if timed_out:raise TimeoutError('OWNED_HELPER_TIMEOUT_RAW_RETAINED')
    if proc.returncode!=expected:raise AssertionError('OWNED_HELPER_EXIT_'+str(proc.returncode)+':'+err.decode('utf-8',errors='replace'))
    assert proc.poll()==expected
    return {'pid':proc.pid,'exit':proc.returncode,'reaped':True,'stdout_sha256':sha(out),'stderr_sha256':sha(err)}

def race(root,run,label,with_reader):
    case=run/label;case.mkdir();nonce=sha((label+str(os.getpid())).encode());procs=[];summary=[]
    writer=spawn(['--root',str(root),'--group','X3' if with_reader else 'X2','--actor','writer','--case',str(case),'--nonce',nonce]);procs.append(writer)
    try:
        wait_file(case/'WRITER_READY.json');ready=json.loads((case/'WRITER_READY.json').read_bytes());assert ready['owner_pid']==writer.pid
        common=['--root',str(root),'--group','X3' if with_reader else 'X2','--case',str(case),'--nonce',nonce,'--owner',str(writer.pid),'--descriptor-hash',ready['descriptor_sha256']]
        publisher=spawn([*common,'--actor','publisher']);procs.append(publisher)
        if with_reader:reader=spawn([*common,'--actor','reader']);procs.append(reader)
        exclusive_json(case/'ALLOW_ADMISSION.json',{'go':True})
        for role,proc in zip(['writer','publisher','reader'],procs):summary.append(reap(proc,case/(role+'_controller')))
        events=[]
        for role in ['writer','publisher']+(['reader'] if with_reader else []):events.extend(json.loads(line) for line in (case/(role+'.jsonl')).read_bytes().splitlines())
        kinds={k:[x for x in events if x['kind']==k] for k in ['STOP_ATTEMPT','STOP_DURABLE','STOP_ACK','CHARGE_COMMITTED','INERT_ENTRY_RETURN','READER_OBSERVED_STOP']}
        assert all(len(kinds[k])==1 for k in ['STOP_ATTEMPT','STOP_DURABLE','STOP_ACK','CHARGE_COMMITTED','INERT_ENTRY_RETURN'])
        ack=kinds['STOP_ACK'][0]['qpc_ns'];entry=kinds['INERT_ENTRY_RETURN'][0]['qpc_ns'];charge=kinds['CHARGE_COMMITTED'][0]['qpc_ns']
        assert charge<=entry<=kinds['STOP_DURABLE'][0]['qpc_ns']<=ack
        assert kinds['STOP_ATTEMPT'][0]['qpc_ns']<=charge
        assert any(x['role']=='publisher' and x['kind']=='LOCK_CONTENDED' for x in events)
        assert not any(x['qpc_ns']>ack for k in ['CHARGE_COMMITTED','INERT_ENTRY_RETURN'] for x in kinds[k])
        fingerprints={x['fence_identity_sha256'] for x in events if x['kind']=='FENCE_ATTACHED'};assert len(fingerprints)==1
        assert len({x['pid'] for x in summary})==len(procs)
        if with_reader:assert len(kinds['READER_OBSERVED_STOP'])==1 and kinds['READER_OBSERVED_STOP'][0]['qpc_ns']>=ack
        return {'case':label,'independent_processes':summary,'events':events,'same_verified_fence':True,'same_protocol_only':True,'new_successful_charge_after_ACK':0,'new_inert_entry_after_ACK':0,'reader':with_reader,'qualified':True}
    finally:
        for i,proc in enumerate(procs):
            if proc.poll() is None:
                proc.kill();out,err=proc.communicate(timeout=5)
                (case/('abort_'+str(i)+'.stdout')).write_bytes(out);(case/('abort_'+str(i)+'.stderr')).write_bytes(err)

def local_fixture(run,name,root):
    c=fixture.Context(run/name,budget_code(root),patched=True);trace=Trace(run/(name+'.jsonl'),name);d,h=make_descriptor(c.root,'LOCAL-'+name);shared=SharedFence(c.root,h,'LOCAL-'+name,os.getpid(),trace);c.protocol.fence=shared.fence
    return c,shared,trace

def X1(root,run):
    t=ast.parse((root/'private/source/factorial_driver.py').read_bytes());fn=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='run');calls=[]
    for n in ast.walk(fn):
        if isinstance(n,ast.Call):
            name=ast.unparse(n.func)
            if name.startswith(('budget.','driver[','runtime[')):calls.append({'line':n.lineno,'call':name})
    classify_nodes=[n for n in ast.walk(fn) if isinstance(n,ast.Compare) and ast.unparse(n)=="'E2_' in str(exc)"]
    assert len(classify_nodes)==1
    result={'qualified':True,'run_lines':[fn.lineno,fn.end_lineno],'run_AST_sha256':sha(canonical(fn).encode()),'classifier_line':classify_nodes[0].lineno,'bounded_calls':calls,'run_execution':False,'real_controller_source':'UNAVAILABLE','wiring':'RUN_TYPED_WIRING_SOURCE_GAP','standalone_adapter':'STATIC_READY_ONLY'}
    save(root/'public/run_static_map.json',result);return result
def X2(root,run):return {'qualified':True,'cases':[race(root,run,'INERT_ARM_A',False),race(root,run,'INERT_ARM_B',False)]}
def X3(root,run):return {'qualified':True,'cases':[race(root,run,'INERT_READER_CASE',True)]}
def X4(root,run):
    c,shared,tr=local_fixture(run,'typed',root)
    try:
        c.inject=True;first=catch(lambda:c.b.event('INERT_CHECKPOINT_DENIAL'));assert isinstance(first,PermissionError)
        second=catch(lambda:c.b.finish(False,{'inert':True}));assert second is first
        hard=typed_catch_adapter(c.protocol,c.b,first,'checkpoint');assert hard['sharedHardGate'] and hard['same_primary_object']
        other=types.SimpleNamespace();soft=typed_catch_adapter(c.protocol,other,ValueError('E2_display_only'),'fixture');assert not soft['sharedHardGate']
        c.b.checkpoint();q=fixture.audit_journal(c);assert q['events']==q['checkpoint_seq']==2
        return {'qualified':True,'first_error':fixture.error(first),'finish_same_primary':True,'typed_handoff':hard,'ordinary_E1':soft,'after_verified_recovery':q,'original_run_executed':False}
    finally:c.close();tr.close()
def X5(root,run):
    out=[]
    for name,contents,target in [('corrupt_STOP',b'{partial','PARENT_STOP_REQUEST.json'),('partial_STOP_stage',b'{','PARENT_STOP_REQUEST.next')]:
        c,shared,tr=local_fixture(run,name,root)
        try:
            path=c.root/target;path.write_bytes(contents);e=catch(shared.publish);assert isinstance(e,LedgerFault) and path.read_bytes()==contents and not(c.root/'STOP_ACK.json').exists()
            out.append({'case':name,'rejected':True,'error':fixture.error(e),'input_retained':True,'ACK':False})
        finally:c.close();tr.close()
    c,shared,tr=local_fixture(run,'duplicate',root)
    try:
        shared.publish();before=(c.root/'STOP_ACK.json').read_bytes();shared.publish();assert (c.root/'STOP_ACK.json').read_bytes()==before
        out.append({'case':'duplicate_STOP','idempotent_ACK_bytes':True})
        wrong=catch(lambda:SharedFence(c.root,'0'*64,'LOCAL-duplicate',os.getpid(),tr));assert isinstance(wrong,LedgerFault);out.append({'case':'wrong_attachment_identity','rejected':True})
    finally:c.close();tr.close()
    for share in [3,7]:
        c,shared,tr=local_fixture(run,'native_'+str(share),root);h=fixture.held_handle(c.b.path/'current.json',share)
        try:e=catch(lambda:c.b.event('INERT_NATIVE_READER'))
        finally:assert fixture.KERNEL.CloseHandle(h)
        try:
            if e:assert isinstance(e,PermissionError);c.b.checkpoint()
            q=fixture.audit_journal(c);assert q['events']==q['checkpoint_seq']==2
            out.append({'case':'native_current_reader','desired_access':2147483648,'share':share,'creation':3,'attributes':128,'native_error':fixture.error(e) if e else None,'WinError5':'REPRODUCED_CONTROLLED_ONLY' if e and getattr(e,'winerror',None)==5 else 'NOT_REPRODUCED','handle_closed':True,'verified_stage_recovered':True})
        finally:c.close();tr.close()
    case=run/'controlled_crash';case.mkdir();proc=spawn(['--root',str(root),'--group','X5','--actor','crash','--case',str(case),'--nonce','CRASH_OWNED']);record=reap(proc,case/'crash_controller',23)
    cp=json.loads((case/'writer/arm/science/current.json').read_bytes());assert cp['counts']['HA']==1 and cp['counts']['HA_completed']==cp['counts']['HA_failed']==0 and cp['activeHA']==1
    ready=json.loads((case/'WRITER_READY.json').read_bytes());trace=Trace(case/'post_crash_probe.jsonl','post_crash_probe');fence=SharedFence(case/'writer',ready['descriptor_sha256'],'CRASH_OWNED',proc.pid,trace)
    with fence.fence():pass
    trace.close();out.append({'case':'controlled_exit','process':record,'charged':1,'entered':0,'completed':0,'failed':0,'unresolved':1,'lock_reacquired_after_exit':True,'no_resume':True})
    return {'qualified':True,'cases':out}
def X6(root,run):
    p=json.loads((root/'private/TASK_PARAMETERS.json').read_bytes());state=json.loads((root/'private/state.json').read_bytes());budget_code(root)
    for pin in p['accepted_public_bundle']['static_pinned_members']:assert sha((root/'private/prior'/pin['name']).read_bytes())==pin['sha256']
    assert (root/'harness/repair_support.py').read_bytes()==(root/'private/prior/harness/repair_support.py').read_bytes()
    return {'qualified':True,'candidate_sha256':state['prior_patch']['sha256'],'accepted_method_AST':'UNCHANGED','accepted_support_source':'UNCHANGED','fixture_attachment':'NEW_INSTANCE_BINDING_ONLY','old_T1_T6_J1_J2':'ACCEPTED_PINNED_BASELINE_REUSED_NOT_RERUN','real_controller':'REAL_SUPERVISOR_READER_SOURCE_UNAVAILABLE','global_supervisor_reader':'UNVERIFIED','production_runtime':'UNVERIFIED','science_budget':'ZERO'}

def install_audit(root):
    def hook(event,args):
        if event=='open' and not isinstance(args[0],int):
            path=Path(os.fsdecode(args[0])).absolute();mode=str(args[1] or '');flags=args[2]
            writing=any(c in mode for c in 'wax+') or bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
            if writing and root not in path.parents:raise RuntimeError('STOP_UNSAFE_WRITE')
            if not writing and root not in path.parents and Path(sys.base_prefix) not in path.parents:raise RuntimeError('STOP_UNSAFE_READ')
        if event=='import' and args[0].split('.')[0] not in sys.stdlib_module_names:raise RuntimeError('STOP_UNSAFE_IMPORT')
        if event=='subprocess.Popen':assert Path(args[0]).resolve()==Path(sys.executable).resolve() and str(Path(__file__).resolve()) in args[1]
    sys.addaudithook(hook)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--group',choices=['X1','X2','X3','X4','X5','X6'],required=True);ap.add_argument('--attempt',type=int,choices=[1,2,3],default=1);ap.add_argument('--actor',choices=['writer','publisher','reader','crash']);ap.add_argument('--case');ap.add_argument('--nonce');ap.add_argument('--owner',type=int);ap.add_argument('--descriptor-hash');a=ap.parse_args();root=Path(a.root).resolve();p=json.loads((root/'private/TASK_PARAMETERS.json').read_bytes());assert root==Path(p['scratch']['unique'])
    budget_code(root);install_audit(root)
    if a.actor:
        case=Path(a.case).resolve();assert root in case.parents;actor(root,case,a.actor,a.nonce,a.owner,a.descriptor_hash)
    else:
        run=root/'runs'/(a.group+'_attempt'+str(a.attempt));run.mkdir()
        try:
            result=globals()[a.group](root,run);result.update({'group':a.group,'attempt':a.attempt,'real_science_calls':0});save(run/'results.json',result);print(json.dumps(result))
        except BaseException:
            (run/'first_error.private.txt').write_text(traceback.format_exc(),encoding='utf-8');raise
