"""TEMP-only price fields around byte-exact A0 macro arithmetic."""
import math,hashlib
import numpy as np
from TEMP_V010_MODEL.multi_province.wage import mainline_phi,mainline_effective_wages
from TEMP_V010_MODEL.multi_province.capital_network import BilateralCapitalNetworkInputs,build_bilateral_capital_network
ARMS=('A0_RAW_RA0_RAW_WT0','A1_USED_RA_RAW_WT0','A2_RAW_RA_USED_WJT','A3_USED_RA_USED_WJT')
def factors(arm):
 if arm not in ARMS:raise ValueError('UNKNOWN_ARM')
 return arm in (ARMS[1],ARMS[3]),arm in (ARMS[2],ARMS[3])
def floats(x):
 a=np.asarray(x,dtype='<f8');return {'values':a.tolist(),'shape':list(a.shape),'float64LEHex':a.tobytes().hex(),'SHA256':hashlib.sha256(a.tobytes()).hexdigest().upper()}
def network(states,fixture):
 p=fixture['parameters'];raw=np.array([s['ra0_raw_previous'] for s in states]);sd=float(np.std(raw,ddof=0))
 score=np.zeros(len(raw)) if sd==0 else (raw-np.mean(raw))/sd
 net=build_bilateral_capital_network(BilateralCapitalNetworkInputs(tuple(fixture['province_order']),np.array([s['At'] for s in states]),np.array([s['N'] for s in states]),np.array(fixture['foreign_share_theta']),np.array(fixture['distance_score_destination_origin']),score,raw,p['portfolio_beta_distance'],p['portfolio_beta_return'],'LAGGED_COMPLETED_ITERATION_RAW_RETURN__SYNTHETIC_INITIAL_ANCHOR'))
 return net,raw,score
def independent_oracle(states,fixture,arm):
 used_ra,used_w=factors(arm);n=len(states);p=fixture['parameters']
 raw=[s['ra0_raw_previous'] for s in states];mean=math.fsum(raw)/n;sd=math.sqrt(math.fsum((v-mean)**2 for v in raw)/n)
 score=[0.]*n if sd==0 else [(v-mean)/sd for v in raw];S=[[0.]*n for _ in range(n)]
 for i in range(n):
  eligible=[j for j in range(n) if j!=i];v=[-p['portfolio_beta_distance']*fixture['distance_score_destination_origin'][j][i]+p['portfolio_beta_return']*score[j] for j in eligible]
  weights=[math.exp(x-max(v)) for x in v];den=math.fsum(weights)
  for j,w in zip(eligible,weights):S[j][i]=fixture['foreign_share_theta'][i]*w/den
  S[i][i]=1-fixture['foreign_share_theta'][i]
 pay=[s['ra'] if used_ra else s['ra0_raw_previous'] for s in states]
 rah=[math.fsum(pay[j]*S[j][i] for j in range(n)) for i in range(n)]
 gross=[s['wjt'] if used_w else s['wt0'] for s in states];out=[];ex=p['phi_l']/(1+p['phi_l'])
 for i in range(n):
  total=0.
  for j in range(n):
   phi=1+.3*(fixture['pgdp_reference'][i]-fixture['pgdp_reference'][j])/(fixture['pgdp_reference'][i]+fixture['pgdp_reference'][j])
   base=gross[j]*(1-states[j]['tau']-fixture['migration_wedge_destination_origin'][j][i])/phi
   if base<0:raise ValueError('NEGATIVE_NET_WAGE_BASE')
   total+=phi*base**(1+1/p['phi_l'])
  out.append(p['alphal']**(-ex)*total**ex)
 return np.array(S),np.array(score),np.array(rah),np.array(out)
def validate_prices(states,fixture,arm,S,score,rah,w_eff,tau_HA=0.):
 so,sc,ro,wo=independent_oracle(states,fixture,arm)
 assert tau_HA==0.,'DOUBLE_TAX'
 assert np.allclose(np.sum(S,axis=0),1,rtol=0,atol=1e-12),'S_NOT_CONSERVED'
 for actual,expected,label in ((S,so,'S'),(score,sc,'RAW_SCORE'),(rah,ro,'RAH'),(w_eff,wo,'W_EFF')):
  assert np.isfinite(actual).all() and np.allclose(actual,expected,rtol=2e-14,atol=2e-14),'PRICE_ORACLE_'+label
def prepare_prices_for_arm(states,fixture,arm,iteration,one):
 used_ra,used_w=factors(arm);net,raw,score=network(states,fixture);S=net.portfolio_shares_destination_origin
 if iteration==1:
  # Exact frozen fixture input remains authoritative; no lagged mixing yet.
  ready=tuple(dict(s) for s in states)
 else:
  ready=one.prepare_mainline_household_states(states,fixture)
  pay=np.array([s['ra'] for s in states]) if used_ra else raw
  rah=pay@S
  ready=tuple(dict(s,rah=float(rah[i])) for i,s in enumerate(ready))
  validate_prices(states,fixture,arm,S,score,[s['rah'] for s in ready],[s['w_eff'] for s in ready])
 binding={'arm':arm,'round':iteration,'previousRa0Raw':floats(raw),'previousRaUsed':floats([s['ra'] for s in states]),'scoreRaw':floats(score),'S':floats(S),'effectiveRahUsedByHA':floats([s['rah'] for s in ready]),'effectiveWEffUsedByHA':floats([s['w_eff'] for s in ready]),'tau_HA':0.,'firstRoundFixtureException':iteration==1,'postTurnRahPrediction':[s['rah'] for s in states]}
 return ready,binding
def price_one_turn(states,batch,fixture,arm,reference_bridge):
 used_ra,used_w=factors(arm);turn=reference_bridge.experiment_one_turn(states,batch,fixture)
 firms=turn['firms'];S=turn['shares'];p=fixture['parameters']
 payoff=np.array([f.ra if used_ra else f.ra0 for f in firms]);rah=payoff@S
 wages=mainline_effective_wages([f.wjt if used_w else f.wt0 for f in firms],[s['tau'] for s in states],turn['phi'],np.array(fixture['migration_wedge_destination_origin']),phi_l=p['phi_l'],alphal=p['alphal'])
 turn['states']=tuple(dict(s,rah=float(rah[i]),w_eff=float(wages[i])) for i,s in enumerate(turn['states']))
 turn['price_signal']={'arm':arm,'returnSource':'firm.ra' if used_ra else 'firm.ra0','wageSource':'firm.wjt' if used_w else 'firm.wt0','postTurnSForecast':floats(S),'postTurnRahForecast':floats(rah),'nextWEff':floats(wages),'macroWjtGrossSource':'firm.wt0','wageTaxSource':'tau*firm.wt0*firm.Lt','firstAffectedHARound':2}
 return turn
