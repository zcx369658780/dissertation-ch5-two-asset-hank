# Decision: REAL_LEDGER_INTERFACE_DEFECT_CONFIRMED

All six authorized groups completed, using unchanged original Budget method ASTs.
T1 established three disposable writer/event/checkpoint paths and duplicate-writer
directory exclusion. This does not by itself prove global multi-process locking.
T2 reproduced append/checkpoint divergence and failed original residual retry.
T3 obtained native owned-reader WinError5 in both tested share modes, with a passing
no-reader control. T4 reproduced secondary finish failure and the text classifier
limitation. T5 demonstrated pre-STOP memory/durable count separation and a bounded
STOP admission window. T6 exited one owned worker with code23 after durable charge,
reaped it, reconstructed its checkpoint read-only and reacquired its released lock.

T6's original constructor refuses the existing science directory. The test labels
this ORIGINAL_METHOD_DEFECT_REPRODUCED as an absent restart capability; refusal is
consistent with the module's stated one-shot/no-resume design, not evidence of
journal corruption. Reconstruction is WRAPPER_ONLY, never a successful HA return.
The interrupted ledger records charged1/entered0/completed0/failed0/unresolved1.

No original production method, old source, old journal or formal V010 was modified.
No production driver or temp module was imported. HA/HJB/KFE/GE/IRF=0. No A0-A3 or
old science/test suite was run. STOP_UNSAFE is a measured disposable interface
finding, not an accidental real scientific execution.

PRODUCTION_RUNTIME_UNVERIFIED remains mandatory. Before any scientific pilot:
obtain separate Owner approval for exact production supervisor/reader/bridge
sources, typed hard-error escalation, first-error retention, explicit residual and
event-prefix reconciliation, and an atomic admission fence. Any actual production
repair and its interface qualification require a new task. A1-A3 science budgets
remain zero. This report does not issue that task or change the mathematical model.
