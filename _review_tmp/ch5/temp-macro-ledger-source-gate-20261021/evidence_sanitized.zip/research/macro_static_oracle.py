"""SOURCE_ONLY scalar algebra; no production import, solver, calibration or trajectory."""
from pathlib import Path
import json, math
D=0.025; CAP=0.09
# Rounded accepted-review numbers, not newly read 100-round raw trajectories.
rows=[
 {"province":"SYN_A","K":2278.055,"Y":1578.827,"ra0":.384584,"rk":.409584,"G":1191.818,"L":154.718,"wt0":4.020457,"wjt":1.3,"Kreq_report_target":7708.},
 {"province":"SYN_B","K":2668.517,"Y":2020.823,"ra0":.427239,"rk":.452239,"G":1430.181,"L":163.026,"wt0":4.935043,"wjt":1.3,"Kreq_report_target":9867.},
]
for x in rows:
    assert math.isclose(x["ra0"],x["rk"]-D,abs_tol=1e-12)
    malpha=x["rk"]*x["K"]/x["Y"]
    x["m_alpha_inferred_from_rounded_observed_state"]=malpha
    x["Kreq_holding_observed_output_malpha_zero_profit"]=x["K"]*(x["ra0"]+D)/(CAP+D)
    x["ratio_observed_output_condition"]=x["Kreq_holding_observed_output_malpha_zero_profit"]/x["K"]
    x["ratio_historical_target_condition"]=x["Kreq_report_target"]/x["K"]
    x["Ytarget_implied_by_report_Kreq_not_authenticated_fixture"]=x["Kreq_report_target"]*(CAP+D)/malpha
    x["Kprivate_inferred"]=x["K"]-x["G"]
    x["GovInv_required_if_private_K_fixed_NOT_POLICY_RECOMMENDATION"]=x["Kreq_report_target"]-x["Kprivate_inferred"]
    x["capital_clip_compensation"]=(x["ra0"]-CAP)*x["K"]
    x["wage_clip_compensation"]=(x["wt0"]-x["wjt"])*x["L"]
    x["clip_compensation_to_observed_Y"]=(x["capital_clip_compensation"]+x["wage_clip_compensation"])/x["Y"]
    assert x["ratio_observed_output_condition"]>x["ratio_historical_target_condition"]>3.
    assert math.isclose(malpha*x["Y"]/x["Kreq_holding_observed_output_malpha_zero_profit"]-D,CAP,abs_tol=1e-12)
S=[[.9,.2],[.1,.8]]
raw=[x["ra0"] for x in rows]
rah=[sum(S[j][i]*raw[j] for j in range(2)) for i in range(2)]
used=[sum(S[j][i]*CAP for j in range(2)) for i in range(2)]
for v in used:assert math.isclose(v,CAP,abs_tol=1e-12)
result={"tier":"STATIC_FORMULA_ORACLE_USING_REVIEW_ACCEPTED_ROUNDED_NUMBERS","source":"S06 lines23-84","rows":rows,"same_S":{"S":S,"raw_rah":rah,"used_rah":used},"GovInv_26_updates_factor":1.1**26,"final_gate":{"max_KN_gap":.1075218256230952,"adaptation_max_KN_strict_bound":.1,"joint_gate_open_at_final":False},"not_proved":["actual raw fixture Ytarget exact values","new fixed point","causal price bridge effect","number of future rounds","old HA algorithm error"],"science_calls":0}
Path(__file__).with_name("macro_static_oracle_results.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
print(json.dumps(result))
