from fractions import Fraction as F
import pathlib,json
R=pathlib.Path(__file__).parent
E=[F(50),F(50)];M=[[F(4,5),F(1,10)],[F(1,5),F(9,10)]];eff=[F(1),F(2)];w=[F(2),F(3)];tau=[F(1,10),F(1,5)]
flow=[[M[j][i]*E[i] for i in range(2)] for j in range(2)]
D=[sum(row) for row in flow];L=[D[j]*eff[j] for j in range(2)]
net=[sum(flow[j][i]*eff[j]*w[j]*(1-tau[j]) for j in range(2)) for i in range(2)]
gross=sum(L[j]*w[j] for j in range(2));tax=sum(L[j]*w[j]*tau[j] for j in range(2))
tests=[('heads',D,[45,55]),('effective_labor',L,[45,110]),('origin_net',net,[120,225]),('gross',gross,420),('tax',tax,75),('net_total',sum(net),345)]
assert all(a==e for _,a,e in tests)
with (R/'small_oracle_independent_check.json').open('x',encoding='utf-8') as f:json.dump({'passed':6,'failed':0,'tests':[{'name':n,'actual':str(a),'expected':str(e),'pass_test':a==e} for n,a,e in tests],'not_production_or_HA':True},f,ensure_ascii=False,indent=2)
print('INDEPENDENT_SMALL_ORACLE_PASS 6')
