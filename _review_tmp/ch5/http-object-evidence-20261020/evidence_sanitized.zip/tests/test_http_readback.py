"""New deterministic HTTP-interface fixtures; no live network or old suite."""
import base64
import copy
import hashlib
import http.client
import io
import json
from pathlib import Path
import sys
import unittest
from unittest import mock
import urllib.error
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from ch5_evidence_publisher import Publisher, Rejected, digest


def git_id(kind, data):
    return hashlib.sha1(kind.encode() + b' ' + str(len(data)).encode() + b'\0' + data).hexdigest()


class Response:
    status = 200
    def __init__(self, body, fault=None, declared=None):
        self.body = io.BytesIO(body)
        self.headers = {'Content-Length': str(len(body) if declared is None else declared)}
        self.fault = fault
    def __enter__(self): return self
    def __exit__(self, *args): return False
    def read(self, count):
        if self.fault:
            fault, self.fault = self.fault, None
            raise fault
        return self.body.read(count)


class Fixture:
    """Constructs cryptographically consistent small Git tree/blob objects."""
    def __init__(self, publisher, tag, payload=None, extra=None):
        self.p = publisher
        self.payload = publisher._synthetic_payload() if payload is None else payload
        self.payload['result.md'] += ('\nSynthetic case ' + tag).encode()
        self.objects, self.calls, self.faults = {}, [], {}
        self.blobs = {}
        entries = {}
        for name, data in self.payload.items():
            oid = git_id('blob', data)
            self.blobs[name] = oid
            self.objects['/git/blobs/' + oid] = {'sha': oid, 'size': len(data), 'encoding': 'base64', 'content': base64.b64encode(data).decode()}
            entries[name] = {'path': name, 'mode': '100644', 'type': 'blob', 'sha': oid, 'size': len(data)}
        if extra:
            entries.update(extra)
        self.target = self.tree(entries)
        tree = self.target
        for name in reversed(Path(publisher.params['publication']['temp_path']).parts):
            tree = self.tree({name: {'path': name, 'mode': '040000', 'type': 'tree', 'sha': tree}})
        self.root_tree = tree
        candidate = hashlib.sha1(('SYNTHETIC COMMIT ' + tag).encode()).hexdigest()
        parent = publisher.params['publication']['fixed_parent']
        self.expected = {'candidate': candidate, 'tree': tree, 'parent': parent}
        self.ref = '/git/ref/heads/' + publisher.params['publication']['review_branch']
        self.objects[self.ref] = {'ref': 'refs/heads/' + publisher.params['publication']['review_branch'], 'object': {'type': 'commit', 'sha': candidate}}
        self.objects['/git/commits/' + parent] = {'sha': parent, 'parents': [], 'tree': {'sha': '0' * 40}}
        self.objects['/git/commits/' + candidate] = {'sha': candidate, 'parents': [{'sha': parent}], 'tree': {'sha': tree}}
        publisher._http_fixture_id = tag
        publisher._http_test_transport = self.open
    def tree(self, rows):
        rows = sorted(rows.values(), key=lambda row: (row['path'] + ('/' if row['type'] == 'tree' else '')).encode())
        wire = b''.join(row['mode'].lstrip('0').encode() + b' ' + row['path'].encode() + b'\0' + bytes.fromhex(row['sha']) for row in rows)
        oid = git_id('tree', wire)
        self.objects['/git/trees/' + oid] = {'sha': oid, 'tree': rows, 'truncated': False}
        return oid
    def open(self, request, timeout):
        suffix = request.full_url.split(self.p.params['publication']['repository'], 1)[1]
        self.calls.append(suffix)
        fault = self.faults.get(suffix, [])
        if fault:
            value = fault.pop(0)
            if isinstance(value, urllib.error.HTTPError): raise value
            return Response(json.dumps(self.objects[suffix]).encode(), fault=value)
        return Response(json.dumps(self.objects[suffix]).encode())
    def verify(self):
        return self.p.readback(self.expected, self.payload)


class HTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p = Publisher(ROOT, 'engineering', 'qualification')

    def test_H01_exact_deep_nonrecursive_objects(self):
        f = Fixture(self.p, 'H01')
        proof = f.verify()
        self.assertEqual(proof['verified_files'], 3)
        self.assertTrue(proof['member_hashes_verified'])
        self.assertEqual(len(f.calls), 10)
        self.assertTrue(all('?' not in path for path in f.calls))
        self.assertEqual(sum('/git/trees/' in path for path in f.calls), 4)

    def test_H02_extra_collision_missing_and_type_rejected(self):
        for tag, extra in [('extra', {'extra.txt': {'path': 'extra.txt', 'mode': '100644', 'type': 'blob', 'sha': '1' * 40, 'size': 1}}), ('case', {'RESULT.md': {'path': 'RESULT.md', 'mode': '100644', 'type': 'blob', 'sha': '1' * 40, 'size': 1}})]:
            f = Fixture(self.p, 'H02-' + tag, extra=extra)
            with self.assertRaises(Rejected): f.verify()
        f = Fixture(self.p, 'H02-missing')
        f.objects['/git/trees/' + f.root_tree]['tree'] = []
        with self.assertRaises(Rejected): f.verify()
        f = Fixture(self.p, 'H02-type')
        f.objects['/git/trees/' + f.target]['tree'][0]['mode'] = '120000'
        with self.assertRaises(Rejected): f.verify()

    def test_H03_truncated_or_unknown_tree_rejected(self):
        for value in (True, None):
            f = Fixture(self.p, 'H03-' + str(value))
            f.objects['/git/trees/' + f.root_tree]['truncated'] = value
            with self.assertRaises(Rejected): f.verify()

    def test_H04_interruption_partial_retained_and_bounded(self):
        partial = b'{"synthetic_private_partial":'
        f = Fixture(self.p, 'H04-recovered')
        route = '/git/trees/' + f.root_tree
        f.faults[route] = [http.client.IncompleteRead(partial, 20)]
        before = len(self.p._http_records)
        f.verify()
        records = self.p._http_records[before:]
        failed = [row for row in records if row['error_type'] == 'IncompleteRead']
        self.assertEqual(len(failed), 1)
        self.assertEqual(failed[0]['received_bytes'], len(partial))
        index = self.p._http_records.index(failed[0]) + 1
        retained = (self.p.private / ('http-%04d.body' % index)).read_bytes()
        self.assertEqual(retained, partial)
        self.assertEqual(failed[0]['sha256'], digest(partial))
        self.assertNotIn('synthetic_private_partial', json.dumps(records))
        f = Fixture(self.p, 'H04-exhausted')
        route = '/git/trees/' + f.root_tree
        f.faults[route] = [http.client.IncompleteRead(partial, 20), http.client.IncompleteRead(partial, 20)]
        with self.assertRaises(http.client.IncompleteRead): f.verify()
        self.assertEqual(f.calls.count(route), 2)

    def test_H05_absent_conflicting_and_auth_ref_no_retry(self):
        for status in (404, 403):
            f = Fixture(self.p, 'H05-' + str(status))
            f.faults[f.ref] = [urllib.error.HTTPError('https://api.github.com/synthetic', status, 'synthetic', {}, io.BytesIO(b'synthetic body'))]
            with self.assertRaises(urllib.error.HTTPError): f.verify()
            self.assertEqual(f.calls, [f.ref])
        f = Fixture(self.p, 'H05-conflict')
        f.objects[f.ref]['object']['sha'] = '0' * 40
        with self.assertRaises(Rejected): f.verify()
        self.assertEqual(f.calls, [f.ref])

    def test_H06_blob_bytes_and_manifest_hash_fail(self):
        f = Fixture(self.p, 'H06-bytes')
        f.objects['/git/blobs/' + f.blobs['result.md']]['content'] = base64.b64encode(b'WRONG').decode()
        with self.assertRaises(Rejected): f.verify()
        payload = self.p._synthetic_payload()
        manifest = json.loads(payload['manifest.json'])
        manifest['members'][0]['sha256'] = '0' * 64
        payload['manifest.json'] = json.dumps(manifest).encode()
        f = Fixture(self.p, 'H06-manifest', payload=payload)
        with self.assertRaises(Rejected): f.verify()

    def test_H07_complete_immutable_cache_and_corruption(self):
        f = Fixture(self.p, 'H07')
        f.verify(); calls = len(f.calls); f.verify()
        self.assertEqual(f.calls[calls:], [f.ref])
        route = '/git/blobs/' + f.blobs['result.md']
        key = digest((self.p.params['publication']['repository'] + route).encode())
        cached = self.p.private / 'http-cache' / 'H07' / (key + '.body')
        original = cached.read_bytes()
        (self.p.private / 'H07-original-cache-body.bin').write_bytes(original)
        cached.write_bytes(b'CORRUPTED SYNTHETIC CACHE')
        with self.assertRaises(Rejected): f.verify()

    def test_H08_commit_parent_tree_binding(self):
        for label in ('parent', 'tree'):
            f = Fixture(self.p, 'H08-' + label)
            obj = f.objects['/git/commits/' + f.expected['candidate']]
            if label == 'parent': obj['parents'].append({'sha': '0' * 40})
            else: obj['tree']['sha'] = '0' * 40
            with self.assertRaises(Rejected): f.verify()
        f = Fixture(self.p, 'H08-expected')
        f.expected['parent'] = '0' * 40
        with self.assertRaises(Rejected): f.verify()
        self.assertEqual(f.calls, [])

    def test_H09_unsafe_zip_path_rejected(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w') as z: z.writestr('../unsafe.txt', b'SYNTHETIC')
        with zipfile.ZipFile(io.BytesIO(buf.getvalue())) as z: crc = z.infolist()[0].CRC
        payload = {'result.md': b'synthetic', 'manifest.json': json.dumps({'members': [{'path': '../unsafe.txt', 'bytes': 9, 'sha256': digest(b'SYNTHETIC'), 'crc32': crc}]}).encode(), 'evidence_sanitized.zip': buf.getvalue()}
        f = Fixture(self.p, 'H09', payload=payload)
        with self.assertRaises(Rejected): f.verify()

    def test_H10_existing_ref_prevents_any_push(self):
        f = Fixture(self.p, 'H10')
        payload = f.payload
        mapped = {ROOT / 'attempts/qualification/test_results.json': json.dumps([{'status': 'PASS', 'kind': 'SYNTHETIC_ADMISSION_FIXTURE'}] * 7).encode(), ROOT / 'package/PAYLOAD_LOCK.json': json.dumps({n: {'bytes': len(b), 'sha256': digest(b)} for n, b in payload.items()}).encode()}
        mapped.update({ROOT / 'package' / n: b for n, b in payload.items()})
        original = Path.read_bytes
        def fixture_read(path): return mapped[path] if path in mapped else original(path)
        self.p.stage = 'delivery'
        try:
            with mock.patch.object(Path, 'read_bytes', fixture_read), mock.patch.object(self.p, '_http', return_value={'existing_ref': True}), mock.patch.object(self.p, '_repo', side_effect=AssertionError('must not reach Git mutation')):
                with self.assertRaisesRegex(Rejected, 'review ref already exists'): self.p.publish()
        finally:
            self.p.stage = 'engineering'


def run_suite():
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(HTTPTests)
    class Results(unittest.TextTestResult):
        rows = []
        def addSuccess(self, test):
            self.rows.append({'cluster': test.id(), 'status': 'PASS'}); super().addSuccess(test)
        def addFailure(self, test, err):
            self.rows.append({'cluster': test.id(), 'status': 'FAIL', 'error': self._exc_info_to_string(err, test)}); super().addFailure(test, err)
        def addError(self, test, err):
            self.rows.append({'cluster': test.id(), 'status': 'ERROR', 'error': self._exc_info_to_string(err, test)}); super().addError(test, err)
    result = unittest.TextTestRunner(verbosity=2, resultclass=Results).run(suite)
    (ROOT / 'attempts/qualification/test_results.json').write_text(json.dumps(Results.rows, indent=2), encoding='utf-8')
    p = HTTPTests.p
    if hasattr(p, '_http_test_transport'): del p._http_test_transport
    (p.public / 'http-interface-records.json').write_text(json.dumps(p._http_records, indent=2), encoding='utf-8')
    if not result.wasSuccessful(): return 1
    proof = p.selftest()
    print(json.dumps({'clusters': len(Results.rows), 'status': 'PASS', 'fake_bare': proof}))
    return 0


if __name__ == '__main__': raise SystemExit(run_suite())
