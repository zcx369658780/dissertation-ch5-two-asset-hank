# CH5_REVIEW_PATH_CLASSIFIER_V19_SYNTHETIC_ONLY_20261018

结论：PASS_SYNTHETIC_CLASSIFIER_LOCAL；Astra 独立验收 PENDING。
run_id：06ed068da2d948649f463889051ea157
治理 HEAD：326935e286d00be70306dfeee66b598e73f93725
固定发行 Commit：fa923c6048d958eba772b8145f79cf1fa857ee42
合同 Blob、UTF-8 长度和 SHA256 见最终回执及 FIRST.json；身份等级 CONNECTOR_TEXT_VERIFIED。当前治理的 TASK_BLOB=VERIFY_BY_READBACK，已通过固定提交 tasks tree 的只读元数据回读取得 Blob，再核对原样连接器文本。未声称原始 Git 对象字节认证。

BOOTSTRAP 0/1/2 在首次写入前通过。仅核验有限保护根、父链及目标；20 项路径/文件身份首尾一致，3 份 Git 定位/index/common-dir 证明文件 SHA 一致。旧运行目录仅读取根身份，旧 ZIP、manifest、回执和模型源码内容读取均为 0，也未写入。未对旧内容重新计算哈希，不能把“不写入”夸大为全树内容独立复算。

实现只接受内存字节。JSON 由 System.Text.Json 验证和解码；URI 由 System.Uri 及 scheme/authority 结构判定；Windows/UNC 按完整 token 与路径组件判定。分类器没有裸正则最终裁决，没有文件系统路径探测，没有执行待检查文本。JSON 原始转义 token 与解析后语义 span 分开输出。所有 span 保留规则、上下文、半开字符/字节区间、是否复核及判定；完整 UTF-16/UTF-8 映射规则见 docs/CLASSIFIER_BOUNDARY.md。

最终合成测试：91/91 样本，1754/1754 断言，失败样本 0，失败断言 0。所有原始输入字节、Base64、SHA256 和重复分析映射均通过。语料包含 URI、盘符、UNC、JSON 转义/解析字符串、混合文本、凭据候选、格式错误、无效 UTF-8、Unicode/emoji、重复路径、穿越候选及嵌套归档元数据；未打开或生成任何归档。

下表为逐样本的“该类是否出现”多标签统计，包含原始 span 与 JSON 解码语义 span；不是逐 span 的精确率或生产数据性能：

| 类别 | TP | FP | FN | TN |
|---|---:|---:|---:|---:|
| URI | 26 | 0 | 0 | 65 |
| WINDOWS_DRIVE_PATH | 23 | 0 | 0 | 68 |
| UNC_PATH | 5 | 0 | 0 | 86 |
| JSON_ESCAPED_FRAGMENT | 10 | 0 | 0 | 81 |
| CREDENTIAL_CANDIDATE | 7 | 0 | 0 | 84 |
| ORDINARY_TEXT | 27 | 0 | 0 | 64 |
| UNKNOWN | 15 | 0 | 0 | 76 |

负例 56 个，定义为 gold 不含 Windows/UNC/凭据候选的样本，包含 URI、普通文本、序列化片段和预设 UNKNOWN。UNKNOWN 15 个均与预期一致，包括无效 URI/UNC、格式错误 JSON/UTF-8、不支持容器、穿越和不完整语法；全部 BLOCK_UNKNOWN。UNKNOWN 不是测试失败，也不是泄露证明。URI 与盘符 span 重叠负例检查通过；大小写重复路径检测通过。

分类与安全结论分别记录：路径/凭据候选要求上下文复核；JSON_ESCAPED_FRAGMENT 不自动当成实际路径或秘密；UNKNOWN 阻断。NO_FLAG_IN_SYNTHETIC_TEXT 也不构成发布授权。

首次工程错误：内存 bootstrap 代码准备引用了不可用的历史工具存储项，抛出 TypeError；未执行控制器操作或写文件。随后出现一次 bootstrap PowerShell 括号语法错误，仍在脚本执行前。首次测试编译失败：旧测试候选第 50 行含非预期字符，与内存模板不同，具体产生机制未独立证明。三项原始错误/候选均保留。改用短分段 Base64 传输，以独立 JavaScript 与 .NET SHA256 验证源码字节后重新编译；最终两份 reliable 源码和测试通过。没有改写失败原件；没有分类断言失败用例。

资源：4/4 批；控制器 Job 累计/活动 1/1，后代 0，另有启动只读 PowerShell 1 次仅属工具观察，共 2 个工具进程。Python/focused pytest 启动 0/24，并发 Python 0/4，Python 活动工作线程 0/32。测试、编译和解析均在控制进程内执行；没有外部 runner。控制器 Job ActiveProcessLimit=1 在控制器存活时阻断额外活动子进程，未把它当成通用生命周期累计创建限制。账本序号、前序 SHA 和 Job 计数已复核。时间与最终字节数见 FINAL_RECEIPT.json。

网络范围：启动授权所必需的治理连接器只读 GET 共 12 次；执行期网络、SSH、Git fetch/push、发布均为 0。旧归档扫描 0，归档生成 0，科学/模型/ResourceGate/adapter/旧 runner 调用 0。全部新增工件仅在本轮 scratch，源码/测试 SHA 索引为 SOURCE_TEST_SHA_INDEX.json。

剩余限制：仅验证这 91 个合成样本，未证明分类器穷尽所有 URI/Windows/JSON 变体；没有真实归档或旧证据回归。旧 Delivery V2 继续 FAIL_CLOSED；原 491 成员 ZIP 的完整安全性继续 UNKNOWN。本任务不授权恢复发布。旧源证据保持未访问、不写入，不能假称重新认证其内容。初始只读工具进程内核身份未补造。最终回执写入时控制器尚存活，其随后退出由工具完成回执单独证明。

model_activation=False；REAL_GE=False；Results=FALSE；V011=NOT_STARTED；FULL_RUNNER_IO_CLOSURE=BLOCKED。
最终 STOP：WAIT_ASTRA_PATH_CLASSIFIER_V19_REVIEW
