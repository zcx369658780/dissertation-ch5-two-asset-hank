# Real production ledger call graph — static, not execution
L verdict: STATIC_REAL_SOURCE_PATH_CONFIRMED with incomplete external controller/bridge/runtime sources. Private archive outer bytes/SHA match the frozen identity;12 selected texts (66401 decoded bytes) are retained privately. No source file is imported or executed. ledger_source_boundary_matrix.json binds individual member SHA/CRC/lengths.

## Confirmed implemented edges
- factorial_driver.py main:101–127 -> Budget:11–17 -> run:63–100; run creates observer from temp_driver.faithful_observer:94–142 via a runtime dictionary. Exact runtime dictionary/module resolution is not fully inspected.
- Budget.__init__: exclusive writer.lock open plus msvcrt nonblocking byte lock; per-arm events.jsonl exclusive binary creation; seq0/64-zero genesis. This is per-arm single-writer intent, not one global journal.
- Budget.event:23–27 -> guard:18–22 -> increment seq -> construct counters/activeHA/previousEventSHA256 row -> append exact JSON bytes -> fsync -> update chain SHA -> checkpoint.
- Budget.checkpoint:28–31 -> exclusive current.next creation, file fsync, then os.replace(current.next,current.json). No catch/reconcile/quarantine/delete-sharing handling exists inside this method.
- run:69–72 -> bridge prepare -> capture state rah/w_eff byte pairs -> observer(state). Budget.begin_ha:32–43 checks captured-byte equality and initial-point/blackbox identities, increments charged HA and active, then event(HA_CHARGED_BEFORE_INITIALIZATION). Only after that successful event/checkpoint path returns does observer initialize and invoke its HA adapter (temp_driver:104–116). This describes original code, not a call made now.
- Budget.profile:44–57 records HJB/KFE entry events before profiled function bodies. Historical event10 is KFE_ENTER_BEFORE_BODY, which must not be treated as proof of a completed KFE.
- observer exception:139–141 writes failure metadata and calls finish(False). Budget.finish:58–60 increments failure/completion count, attempts another event/checkpoint, and clears active only after event returns. A checkpoint error can therefore cause secondary checkpoint failure before clearing active and can mask an earlier exception unless separately retained.
- run catch:94–96 labels sharedHardGate using whether exception TEXT contains E2_. A plain PermissionError/WinError5 message need not satisfy it. Main catch:124–127 marks errors that escape the run differently; do not conflate these two catch levels.
- Budget.guard reads shared PARENT_STOP_REQUEST.json existence. The inspected driver does not publish this global request on local checkpoint failure. Its arm audit hook:109–116 also confines writes to the arm folder. The supervisor/global stop publisher and actual PowerShell reader implementation are outside selected code.

## Direct original-byte journal findings
Recomputed every original JSONL line's SHA including its newline, linked to the next previousEventSHA256;61/61 seq/hash links pass. Every current.json points to a valid prefix hash.
A1: event head11, checkpoint9, failed count1 and completed1 at charged2; tail events are HJB return, KFE entry, HA_REAL_ERROR. A2/A3: event head=checkpoint25, charged5/completed4 each, activeHA5 and final HJB entry. A matching checkpoint does not make active work complete.
This task's new counts for all scientific calls remain0; those are historical counters from authenticated text.

## STOP timing anchors and gate order
The stop-request record follows A1's last recorded failure event by152.615832 seconds. Earlier accepted review described about147 seconds from driver exit; different anchors explain the difference. Actual supervisor process-polling or timeout code is not supplied here.
A2/A3 last HJB-entry events predate STOP publication. Their existence proves continued historical entry after A1's recorded failure, not entries after an already-published STOP. Guard is checked within event, after begin_ha incremented the in-memory reservation. An assertion failure there need not be a durably appended successful charge. No atomic global STOP/entry fence is proved by this code.

## Runtime/reader boundary
The read-only audit confirms static interfaces and original historical event consistency, not current executable readiness or original IO root cause. Native reader flags/handle identities are NOT_OBSERVED. The stop request's possibleTrigger text is a hypothesis, not a reader trace. The original current.next residual bytes and first_error.json were not selected/read; residual cascade has accepted-report support plus a matching source path, not a new residual-file audit.
