$script:Terminal=$false
Add-Type -TypeDefinition @'
using System;using System.IO;using System.Text;using System.Runtime.InteropServices;using Microsoft.Win32.SafeHandles;
public static class C19 {
 [StructLayout(LayoutKind.Sequential)]struct Info{public uint attr,c1,c2,a1,a2,w1,w2,vol,s1,s2,links,i1,i2;}
 [StructLayout(LayoutKind.Sequential)]struct Basic{public long p,j;public uint flags;public UIntPtr min,max;public uint active;public UIntPtr affinity;public uint priority,scheduling;}
 [StructLayout(LayoutKind.Sequential)]struct IO{public ulong a,b,c,d,e,f;}
 [StructLayout(LayoutKind.Sequential)]struct Limits{public Basic basic;public IO io;public UIntPtr pm,jm,ppm,pjm;}
 [StructLayout(LayoutKind.Sequential)]struct Accounting{public long a,b,c,d;public uint faults,total,active,terminated;}
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern SafeFileHandle CreateFile(string p,uint a,uint share,IntPtr s,uint disp,uint flags,IntPtr t);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetFileInformationByHandle(SafeFileHandle h,out Info i);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern uint GetFinalPathNameByHandle(SafeFileHandle h,StringBuilder b,uint n,uint flags);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern bool CreateDirectory(string p,IntPtr s);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern IntPtr CreateJobObject(IntPtr s,string name);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool AssignProcessToJobObject(IntPtr j,IntPtr p);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool SetInformationJobObject(IntPtr j,int c,ref Limits l,uint n);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool QueryInformationJobObject(IntPtr j,int c,out Accounting a,uint n,IntPtr r);
 public static IntPtr Job;static SafeFileHandle hold;
 public static string Id(string p){using(var h=CreateFile(p,0x80,7,IntPtr.Zero,3,0x02200000,IntPtr.Zero)){if(h.IsInvalid)throw new System.ComponentModel.Win32Exception();Info i;if(!GetFileInformationByHandle(h,out i))throw new System.ComponentModel.Win32Exception();var b=new StringBuilder(32768);if(GetFinalPathNameByHandle(h,b,32768,0)==0)throw new System.ComponentModel.Win32Exception();string expected="\\\\?\\"+Path.GetFullPath(p);if((i.attr&0x400)!=0||i.links!=1||!String.Equals(b.ToString().TrimEnd('\\'),expected.TrimEnd('\\'),StringComparison.OrdinalIgnoreCase))throw new Exception("PATH_IDENTITY input="+p+" expected="+expected+" final="+b+" attr="+i.attr+" links="+i.links);return b+"|"+i.vol.ToString("X8")+"|"+i.i1.ToString("X8")+i.i2.ToString("X8")+"|"+i.attr+"|"+i.links;}}
 public static void Hold(string p){hold=CreateFile(p,0x80,3,IntPtr.Zero,3,0x02000000,IntPtr.Zero);if(hold.IsInvalid)throw new System.ComponentModel.Win32Exception();}
 public static void NewDir(string p){if(!CreateDirectory(p,IntPtr.Zero))throw new System.ComponentModel.Win32Exception();}
 public static void StartJob(){Job=CreateJobObject(IntPtr.Zero,null);if(Job==IntPtr.Zero||!AssignProcessToJobObject(Job,System.Diagnostics.Process.GetCurrentProcess().Handle))throw new System.ComponentModel.Win32Exception();var l=new Limits();l.basic.flags=0x2008;l.basic.active=1;if(!SetInformationJobObject(Job,9,ref l,(uint)Marshal.SizeOf<Limits>()))throw new System.ComponentModel.Win32Exception();}
 public static string Status(){Accounting a;if(!QueryInformationJobObject(Job,1,out a,(uint)Marshal.SizeOf<Accounting>(),IntPtr.Zero))throw new System.ComponentModel.Win32Exception();return System.Text.Json.JsonSerializer.Serialize(new{total=a.total,active=a.active,terminated=a.terminated});}
}
'@

$script:Protected=@('<PRIVATE_PATH_19>','<PRIVATE_PATH_14>','<PRIVATE_PATH_05>','<PRIVATE_PATH_04>','<PRIVATE_PATH_02>','<PRIVATE_PATH_07>','<PRIVATE_PATH_12>','<PRIVATE_PATH_11>','<PRIVATE_PATH_13>','<PRIVATE_PATH_20>','<PRIVATE_PATH_10>')
$script:Ids=@{};foreach($p in $script:Protected){$q=$p;while($q){if(-not $script:Ids.ContainsKey($q)){$script:Ids[$q]=[C19]::Id($q)};$d=[IO.Directory]::GetParent($q);$q=if($d){$d.FullName}else{$null}}}
$script:Ids['<PRIVATE_PATH_24>']=[C19]::Id('<PRIVATE_PATH_24>')
function Within([string]$ancestor,[string]$target){$r=[IO.Path]::GetRelativePath($ancestor,$target);return (-not [IO.Path]::IsPathRooted($r) -and $r.Split([IO.Path]::DirectorySeparatorChar)[0] -cne '..')}
if(-not $script:IdentityPassed -or [IO.Path]::GetDirectoryName($script:Root) -ine '<PRIVATE_PATH_24>' -or [IO.Directory]::Exists($script:Root) -or [IO.File]::Exists($script:Root)){throw 'TARGET_IDENTITY'}
foreach($p in $script:Protected){if((Within $p $script:Root)-or(Within $script:Root $p)){throw 'PROTECTED_INTERSECTION'}}
$script:ProofHashes=@{}
foreach($p in @('<PRIVATE_PATH_16>','<PRIVATE_PATH_03>','<PRIVATE_PATH_01>')){$script:Ids[$p]=[C19]::Id($p);$script:ProofHashes[$p]=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([IO.File]::ReadAllBytes($p))).ToLowerInvariant()}
$parent=[C19]::Id('<PRIVATE_PATH_24>');[C19]::Hold('<PRIVATE_PATH_24>');Write-Output 'BOOTSTRAP0_PASS_FINITE_ROOTS_NO_OLD_EVIDENCE_READS'
[C19]::NewDir($script:Root);$script:RootId=[C19]::Id($script:Root)
if([C19]::Id('<PRIVATE_PATH_24>') -cne $parent){throw 'PARENT_CHANGED'}
foreach($p in $script:Ids.Keys){if([C19]::Id($p) -cne $script:Ids[$p]){throw 'PROTECTED_ID_CHANGED'}}
function Used-Bytes {$fs=@([IO.Directory]::EnumerateFiles($script:Root,'*',[IO.SearchOption]::AllDirectories));return (($fs|ForEach-Object{[IO.FileInfo]::new($_).Length}|Measure-Object -Sum).Sum)}
function New-File([string]$rel,[byte[]]$bytes){$p=[IO.Path]::GetFullPath((Join-Path $script:Root $rel));if(-not (Within $script:Root $p)-or $p -ieq $script:Root){throw 'WRITE_SCOPE'};if([C19]::Id($script:Root) -cne $script:RootId){throw 'ROOT_CHANGED'};if((Used-Bytes)+$bytes.Length -gt 134217728){throw 'STORAGE_PREWRITE_LIMIT'};$d=[IO.Path]::GetDirectoryName($p);[IO.Directory]::CreateDirectory($d)|Out-Null;while($d -and (Within $script:Root $d)){$null=[C19]::Id($d);if($d -ieq $script:Root){break};$d=[IO.Path]::GetDirectoryName($d)};$f=[IO.FileStream]::new($p,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$f.Write($bytes);$f.Flush($true)}finally{$f.Dispose()}}
function Save([string]$rel,$v){New-File $rel ([Text.Encoding]::UTF8.GetBytes(($v|ConvertTo-Json -Depth 50)+"`n"))}
function Sha([byte[]]$b){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($b)).ToLowerInvariant()}
[C19]::StartJob();$script:WriteAuthorized=$true
Save 'FIRST.json' @{task=$script:Task;run_id=$script:Run;started=$script:Started;governanceHEAD='326935e286d00be70306dfeee66b598e73f93725';issueCommit='fa923c6048d958eba772b8145f79cf1fa857ee42';contractBlob=$script:TaskBlob;contractSHA256=$script:TaskSHA;contractBytes=$script:ContractBytes.Length;identity='CONNECTOR_TEXT_VERIFIED';expectedSource='GitHub fixed-commit/tasks tree metadata';bootstrap=@{roots=$script:Protected;ids=$script:Ids;proofHashes=$script:ProofHashes;parent=$parent;scratch=$script:RootId;beforeFirstFile=$true};oldEvidenceContentReads=0;intakeToolObserved=1;controllerPID=$PID;budgets=@{processes=96;PythonStarts=24;activePython=4;pythonWorkers=32;seconds=5400;batches=4;bytes=134217728};enforcement='All classification/tests in-process; controller Job active limit=1; no process/worker launch API in classifier';science=0}
New-File 'authority/CONTRACT.md' $script:ContractBytes
New-File 'bootstrap.ps1' ([Text.Encoding]::UTF8.GetBytes($request.code))
Save 'errors/FIRST_PREBOOTSTRAP_ERROR.json' $request.firstError
Save 'errors/BOOTSTRAP_SYNTAX_ERROR.json' $request.syntaxError
$script:LedgerSeq=0;$script:LedgerHead='GENESIS'
function Batch([string]$purpose){if($script:Terminal -or $script:Batches -ge 4 -or ([DateTimeOffset]::UtcNow-$script:Started).TotalSeconds -ge 5400){throw 'PRE_BATCH_BUDGET_OR_STOP'};$k=[C19]::Status()|ConvertFrom-Json;if($k.total -ne 1 -or $k.active -ne 1){throw 'E2_UNEXPECTED_PROCESS'};$script:Batches++;$v=@{seq=$script:LedgerSeq;previous=$script:LedgerHead;utc=[DateTimeOffset]::UtcNow;purpose=$purpose;batches=$script:Batches;kernel=$k;toolObservedIntake=1;Python=0;workerThreads=0;bytes=Used-Bytes};$b=[Text.Encoding]::UTF8.GetBytes(($v|ConvertTo-Json -Depth 10)+"`n");$script:LedgerHead=Sha $b;New-File ('resource/'+$script:LedgerSeq.ToString('D3')+'.json') $b;$script:LedgerSeq++}
Write-Output ('BOOTSTRAP1_2_PASS run='+$script:Run+' Job='+[C19]::Status())
