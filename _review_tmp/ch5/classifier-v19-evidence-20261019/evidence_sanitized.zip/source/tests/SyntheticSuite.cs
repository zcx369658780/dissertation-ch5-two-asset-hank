namespace PathReviewV19Tests {
using System;using System.Text;using System.Text.Json;using System.Collections.Generic;using System.Linq;using System.Security.Cryptography;using PathReviewV19;
public sealed class Fixture {
 public string Id{get;set;}public byte[] Bytes{get;set;}public string Format{get;set;}public string[] Expected{get;set;}public string ExpectedDecision{get;set;}public int ExpectedDuplicates{get;set;}=-1;
}
public static class Suite {
 static readonly UTF8Encoding Utf=new UTF8Encoding(false,true);
 static readonly string[] Kinds={"URI","WINDOWS_DRIVE_PATH","UNC_PATH","JSON_ESCAPED_FRAGMENT","CREDENTIAL_CANDIDATE","ORDINARY_TEXT","UNKNOWN"};
 static Fixture F(string id,string text,string labels,string format="text",string decision=null,int duplicates=-1)=>new Fixture{Id=id,Bytes=Utf.GetBytes(text),Expected=labels.Split('|').OrderBy(x=>x,StringComparer.Ordinal).ToArray(),Format=format,ExpectedDecision=decision??(labels.Contains("UNKNOWN")?"BLOCK_UNKNOWN":labels.Contains("WINDOWS_DRIVE_PATH")||labels.Contains("UNC_PATH")||labels.Contains("CREDENTIAL_CANDIDATE")?"REVIEW_REQUIRED":"NO_FLAG_IN_SYNTHETIC_TEXT"),ExpectedDuplicates=duplicates};
 public static List<Fixture> Cases(){
  var x=new List<Fixture>{
   F("uri_https","https://example.test/a/b","URI"),
   F("uri_ssh","ssh://host/path","URI"),
   F("uri_ftp","ftp://example.test/file","URI"),
   F("uri_query","https://example.test/a?key=value","URI"),
   F("uri_ipv6","https://[2001:db8::1]/demo","URI"),
   F("uri_windows_substring","https://example.test/C:/demo/file","URI"),
   F("uri_unicode","https://example.test/中文/??","URI"),
   F("uri_parentheses","(https://example.test/a)","URI"),
   F("uri_file","file:///C:/demo/file.txt","URI",decision:"REVIEW_REQUIRED"),
   F("uri_userinfo","https://demo:SYNTHETIC_ONLY@example.test/a","URI|CREDENTIAL_CANDIDATE",decision:"REVIEW_REQUIRED"),
   F("uri_traversal","https://example.test/a/../demo","URI",decision:"REVIEW_REQUIRED"),
   F("uri_missing_host","https://","UNKNOWN"),
   F("uri_missing_ssh_host","ssh://","UNKNOWN"),
   F("windows_backslash",@"C:\Users\demo\file.txt","WINDOWS_DRIVE_PATH"),
   F("windows_forward","D:/data/file.txt","WINDOWS_DRIVE_PATH"),
   F("windows_lower",@"c:\demo\file.txt","WINDOWS_DRIVE_PATH"),
   F("windows_quoted_space","\"C:\\demo folder\\file.txt\"","WINDOWS_DRIVE_PATH"),
   F("windows_unicode",@"D:\合成\??\文件.txt","WINDOWS_DRIVE_PATH"),
   F("windows_traversal",@"C:\demo\..\file.txt","WINDOWS_DRIVE_PATH"),
   F("windows_ads",@"C:\demo\file.txt:stream","WINDOWS_DRIVE_PATH"),
   F("windows_invalid",@"C:\demo\bad?name","UNKNOWN"),
   F("ordinary_bare_s","s:/","ORDINARY_TEXT"),
   F("ordinary_substring","The substring s:/ is ordinary text","ORDINARY_TEXT"),
   F("ordinary_attached","prefixs:/demo","ORDINARY_TEXT"),
   F("ordinary_relative_slash","folder/demo/file.txt","ORDINARY_TEXT"),
   F("ordinary_relative_backslash",@"folder\demo\file.txt","ORDINARY_TEXT"),
   F("ordinary_path_inside_word","prefixC:/demo","ORDINARY_TEXT"),
   F("ordinary_placeholder",@"<ROOT>\.git\worktrees\demo","ORDINARY_TEXT"),
   F("ordinary_credential_words","password token api_key","ORDINARY_TEXT"),
   F("ordinary_unicode","合成 中文 ?? ordinary","ORDINARY_TEXT"),
   F("ordinary_empty","","ORDINARY_TEXT"),
   F("unc_required",@"\\server\share\file","UNC_PATH"),
   F("unc_share",@"\\server\share","UNC_PATH"),
   F("unc_unicode",@"\\服务器\共享\文件","UNC_PATH"),
   F("unc_incomplete",@"\\server","UNKNOWN"),
   F("unc_missing_share",@"\\server\","UNKNOWN"),
   F("unc_device",@"\\?\C:\demo","UNKNOWN"),
   F("json_windows_root",JsonSerializer.Serialize(@"C:\Users\demo\file.txt"),"JSON_ESCAPED_FRAGMENT|WINDOWS_DRIVE_PATH","json"),
  n   F("json_windows_field",JsonSerializer.Serialize(new{p=@"D:\data\file.txt"}),"ORDINARY_TEXT|JSON_ESCAPED_FRAGMENT|WINDOWS_DRIVE_PATH","json"),
   F("json_fragment",JsonSerializer.Serialize(@"\worktrees\"),"ORDINARY_TEXT|JSON_ESCAPED_FRAGMENT","json"),
   F("json_placeholder",JsonSerializer.Serialize(@"<ROOT>\.git\worktrees\demo"),"ORDINARY_TEXT|JSON_ESCAPED_FRAGMENT","json"),
   F("json_unc",JsonSerializer.Serialize(@"\\server\share\file"),"JSON_ESCAPED_FRAGMENT|UNC_PATH","json"),
   F("json_uri",JsonSerializer.Serialize("https://example.test/a"),"URI","json"),
   F("json_escaped_slash","\"https:\\/\\/example.test\\/a\"","URI|JSON_ESCAPED_FRAGMENT","json"),
   F("json_unicode_drive","\"\\u0043:\\\\demo\\\\file.txt\"","JSON_ESCAPED_FRAGMENT|WINDOWS_DRIVE_PATH","json"),
   F("json_unicode_literal","\"中文??\"","ORDINARY_TEXT","json"),
   F("json_unicode_escape",JsonSerializer.Serialize("中文??"),"ORDINARY_TEXT|JSON_ESCAPED_FRAGMENT","json"),
   F("json_control_escape","\"\\n\\t\"","JSON_ESCAPED_FRAGMENT","json"),
   F("json_empty_string","\"\"","ORDINARY_TEXT","json"),
   F("json_numeric","123","ORDINARY_TEXT","json"),
   F("json_password",JsonSerializer.Serialize(new{password="SYNTHETIC_NOT_A_SECRET"}),"ORDINARY_TEXT|CREDENTIAL_CANDIDATE","json"),
   F("json_empty_password",JsonSerializer.Serialize(new{password=""}),"ORDINARY_TEXT","json"),
   F("json_password_array","{\"token\":[\"SYNTHETIC_A\",\"SYNTHETIC_B\"]}","ORDINARY_TEXT|CREDENTIAL_CANDIDATE","json"),
   F("json_bad_escape","{\"p\":\"C:\\q\"}","UNKNOWN","json"),
   F("json_truncated","{\"p\":","UNKNOWN","json"),
   F("json_auto_malformed","[1,","UNKNOWN","auto"),
   F("mixed_uri_path_json","https://example.test/a D:/demo/file {\"p\":\"\\\\worktrees\\\\\"}","URI|WINDOWS_DRIVE_PATH|JSON_ESCAPED_FRAGMENT|ORDINARY_TEXT"),
   F("mixed_words_and_quoted","see https://example.test/a and \"C:\\demo folder\\file.txt\" now","URI|WINDOWS_DRIVE_PATH|ORDINARY_TEXT"),
   F("credential_assignment","api_key=SYNTHETIC_NOT_A_SECRET","ORDINARY_TEXT|CREDENTIAL_CANDIDATE"),
   F("credential_quoted_assignment","api_key=\"SYNTHETIC_NOT_A_SECRET\"","ORDINARY_TEXT|CREDENTIAL_CANDIDATE"),
   F("credential_bearer","Bearer SYNTHETIC_ONLY_BEARER","ORDINARY_TEXT|CREDENTIAL_CANDIDATE"),
   F("credential_marker","-----BEGIN SYNTHETIC PRIVATE KEY-----","CREDENTIAL_CANDIDATE"),
   F("unknown_traversal","../demo/file.txt","UNKNOWN"),
   F("unknown_format","p: synthetic","UNKNOWN","yaml"),
   F("unknown_unclosed_quote","\"C:\\demo","UNKNOWN"),
   F("metadata_nested_archive","{\"archive\":\"inner.zip\",\"member\":\"../demo.txt\"}","ORDINARY_TEXT|UNKNOWN","json"),
   F("metadata_benign","{\"archive\":\"inner.zip\",\"member\":\"folder/demo.txt\"}","ORDINARY_TEXT","json"),
   F("duplicate_windows",@"C:\Demo\File.txt c:/demo/file.txt","WINDOWS_DRIVE_PATH",duplicates:1),
   F("duplicate_unc",@"\\Server\Share\File \\server\share\file","UNC_PATH",duplicates:1),
   F("mixed_uri_unknown","https://example.test/a ../demo","URI|UNKNOWN"),
  };
  x.Add(new Fixture{Id="invalid_utf8",Bytes=new byte[]{0xff,0xfe,0x80},Format="text",Expected=new[]{"UNKNOWN"},ExpectedDecision="BLOCK_UNKNOWN"});
  for(int i=0;i<10;i++){x.Add(F("uri_generated_"+i,"https://example.test/synthetic/"+i+"?v="+i,"URI"));x.Add(F("drive_generated_"+i,"D:/synthetic/folder"+i+"/file.txt","WINDOWS_DRIVE_PATH"));}
  return x;
 }
 public static string FixturesJSON()=>JsonSerializer.Serialize(new{provenance="ALL_INPUTS_LITERAL_OR_GENERATED_SYNTHETIC_ONLY",fixtures=Cases()});
 static string Projection(Result r)=>JsonSerializer.Serialize(new{r.Decision,spans=Classifier.All(r).Select(f=>new{f.Id,f.Kind,f.Contextxt,f.RuleId,f.RawStart,f.RawEnd,f.ByteStart,f.ByteEnd,f.DecodedStart,f.DecodedEnd,f.ParsedValue,f.Flags,f.DuplicateOf}),tokens=r.Tokens.Select(t=>new{t.Id,t.RawStart,t.RawEnd,t.RawToken,t.ParsedString,t.Mapping})});
 public static string Run(){
  var cases=Cases();int assertions=0,passed=0;var rows=new List<object>();var failures=new List<object>();var matrix=Kinds.ToDictionary(k=>k,k=>new int[4]);
  foreach(var f in cases){var errors=new List<string>();void Check(bool b,string id){assertions++;if(b)passed++;else errors.Add(id);}
   byte[] before=(byte[])f.Bytes.Clone();string expectedSHA=Convert.ToHexString(SHA256.HashData(before)).ToLowerInvariant();
   Result r=Classifier.Analyze(f.Id,f.Bytes,f.Format);Result second=Classifier.Analyze(f.Id,f.Bytes,f.Format);string[] actual=Classifier.Labels(r);
   Check(actual.SequenceEqual(f.Expected),"gold_label_set");
   Check(r.Decision==f.ExpectedDecision,"security_decision_separate_from_labels");
   Check(before.SequenceEqual(f.Bytes),"original_bytes_unchanged");
   Check(r.RawBytesBase64==Convert.ToBase64String(before),"raw_byte_preservation");
   Check(r.InputSHA256==expectedSHA,"original_SHA256");
   Check(Projection(r)==Projection(second),"stable_offsets_and_mapping");
   if(r.OriginalText!=null){
    foreach(var s in Classifier.All(r)){Check(s.RawStart>=0&&s.RawEnd>=s.RawStart&&s.RawEnd<=r.OriginalText.Length,"raw_span_bounds");
     Check(s.ByteStart==Utf.GetByteCount(r.OriginalText.AsSpan(0,s.RawStart))&&s.ByteEnd==Utf.GetByteCount(r.OriginalText.AsSpan(0,s.RawEnd)),"byte_char_offset_agreement");
     Check(!String.IsNullOrEmpty(s.RuleId)&&!String.IsNullOrEmpty(s.Context)&&!String.IsNullOrEmpty(s.Decision),"classification_metadata");}
    foreach(var t in r.Tokens){
     Check(t.RawToken==r.OriginalText.Substring(t.RawStart,t.RawEnd-t.RawStart),"original_JSON_token");
     Check(JsonSerializer.Deserialize<string>(t.RawToken)==t.ParsedString,"JSON_parser_oracle");
     Check(t.Mapping.Count==t.ParsedString.Length,"mapping_utf16_denominator");
     for(int i=0;i<t.Mapping.Count;i++){var m=t.Mapping[i];Check(m.DecodedIndex==i&&m.RawStart>=t.RawStart+1&&m.RawEnd<=t.RawEnd-1&&m.RawEnd>m.RawStart,"mapping_unit_bounds");
      Check(m.ByteStart==Utf.GetByteCount(r.OriginalText.AsSpan(0,m.RawStart))&&m.ByteEnd==Utf.GetByteCount(r.OriginalText.AsSpan(0,m.RawEnd)),"mapping_unit_byte_agreement");}
    }
    var uris=Classifier.All(r).Where(s=>s.Kind=="URI");var drives=Classifier.All(r).Where(s=>s.Kind=="WINDOWS_DRIVE_PATH");
    Check(!uris.Any(u=>drives.Any(d=>u.RawStart<d.RawEnd&&d.RawStart<u.RawEnd)),"no_URI_drive_overlap");
   }
   if(f.ExpectedDuplicates>=0)Check(Classifier.All(r).Count(s=>s.DuplicateOf!=null)==f.ExpectedDuplicates,"case_insensitive_duplicate_count");
   foreach(string kind in Kinds){bool gold=f.Expected.Contains(kind),pred=actual.Contains(kind);matrix[kind][gold?(pred?0:2):(pred?1:3)]++;}
   if(errors.Count>0)failures.Add(new{id=f.Id,expected=f.Expected,actual,expectedDecision=f.ExpectedDecision,actualDecision=r.Decision,errors});
   rows.Add(new{id=f.Id,format=f.Format,expected=f.Expected,actual,result=errors.Count==0?"PASS":"FAIL",errors,classification=r});
  }
  return JsonSerializer.Serialize(new{scope="SYNTHETIC_CLASSIFIER_ONLY_NO_FILESYSTEM_OR_ARCHIVE_INPUT",samples=cases.Count,passSamples=cases.Count-failures.Count,failSamples=failures.Count,assertions,passAssertions=passed,failAssertions=assertions-passed,metricsBasis="Per-sample per-class presence; multi-label TP/FP/FN/TN, not span-level accuracy",confusion=matrix.Select(k=>new{kind=k.Key,TP=k.Value[0],FP=k.Value[1],FN=k.Value[2],TN=k.Value[3]}),expectedUnknownSamples=cases.Count(f=>f.Expected.Contains("UNKNOWN")),unknownSamples=rows.Count(o=>{using(var j=JsonDocument.Parse(JsonSerializer.Serialize(o)))return j.RootElement.GetProperty("actual").EnumerateArray().Any(x=>x.GetString()=="UNKNOWN");}),negativeSamples=cases.Count(f=>!f.Expected.Contains("WINDOWS_DRIVE_PATH")&&!f.Expected.Contains("UNC_PATH")&&!f.Expected.Contains("CREDENTIAL_CANDIDATE")),failures,rows});
 }
}
}
