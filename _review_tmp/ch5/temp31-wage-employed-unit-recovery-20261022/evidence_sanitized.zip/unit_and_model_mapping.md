SOURCE_ONLY：MU=10万元，NU=100人。工资元/人/年转MU/NU/年除1000；人数万人转NU乘100。吉林2793233人/10000=279.3233万人，年末非私营单位人数不能作为工资年度平均分母或全社会就业。辽宁5-4原表单位万人，501.6267不重复缩放，其时点仍UNKNOWN。天津公报新定位896.56和714.21万人均年末，工作地/居住地仍UNKNOWN。
WORKPLACE_UNIT_REPORTING为单位报告口径，不证明家庭居民地/实际劳动工作地映射。HU参考64.8906755511未采纳；N、HU、a/b、工资与收益率界和asset_bridge未改。HA/HJB/KFE/roots/driver/outer/GE/IRF全0。
