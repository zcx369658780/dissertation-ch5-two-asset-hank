"""Paired disposable original/derived regressions; never import production code."""
import argparse,ast,base64,copy,ctypes,hashlib,json,msvcrt,os,pathlib,subprocess,sys,threading,time,traceback,symtable
from pathlib import Path
from original_boundary import gate,canonical,EXPECTED_GLOBALS
import prior_fixture_support as fixture
from repair_support import classify,LedgerFault

def digest(b):return hashlib.sha256(b).hexdigest()
def save(path,obj):path.write_text(json.dumps(obj,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def load_code(root,mode):
 p=json.loads((root/'private/TASK_PARAMETERS.json').read_bytes());pin=p['evidence_inputs']['frozen_original_private_archive']['exact_member']
 original,expr,identity=gate(root/'private/source/factorial_driver.py',{'bytes':pin['bytes'],'sha256':pin['sha256']})
 if mode=='ORIGINAL_UNCHANGED':return original,expr,identity
 manifest=json.loads((root/'public/safe_ast_patch_manifest.json').read_bytes());raw=(root/'private_repaired_candidate/factorial_driver.py').read_bytes();assert digest(raw)==manifest['candidate_sha256']
 tree=ast.parse(raw);budget=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Budget');limits=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='limits')
 for n in budget.body:
  assert digest(canonical(n).encode())==manifest['methods'][n.name]['candidate']
  table=symtable.symtable(ast.unparse(n),'<candidate_symbols>','exec').get_children()[0]
  assert {x.get_name() for x in table.get_symbols() if x.is_global() and x.is_referenced()} <= EXPECTED_GLOBALS|{'BaseException'}
 assert not any(isinstance(n,(ast.Import,ast.ImportFrom,ast.Global,ast.Nonlocal)) for n in ast.walk(budget))
 assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in {'exec','eval','compile','__import__','getattr'} for n in ast.walk(budget))
 t=ast.fix_missing_locations(ast.Module(body=[copy.deepcopy(limits),copy.deepcopy(budget)],type_ignores=[]))
 return compile(t,'<isolated-derived-budget>','exec'),expr,identity

def new(run,label,code,patched):return fixture.Context(run/label,code,patched=patched)
def observe(c):
 q=fixture.audit_journal(c)
 q['charged_appended']=q['charged_events'];q['charged_checkpoint']=q['checkpoint_counts']['HA']
 q['entered']=c.entered;q['completed']=q['checkpoint_counts']['HA_completed'];q['failed']=q['checkpoint_counts']['HA_failed']
 q['unresolved']=max(0,q['charged_appended']-q['completed']-q['failed'])
 return q
def call_error(fn):
 try:fn()
 except BaseException as e:return e
 return None
def err(e):return fixture.error(e) if e else None

def T1(run,code,expr,patched):
 out=[]
 for name in ['one','two','three']:
  c=new(run,name,code,patched)
  try:
   c.b.event('INERT_1');c.b.event('INERT_2');q=observe(c);assert q['events']==q['checkpoint_seq']==3
   denied=call_error(lambda:c.cls(c.bound,'DUPLICATE',c.folder));assert isinstance(denied,FileExistsError)
   out.append({'case':name,'journal':q,'duplicate_constructor_denied':True})
  finally:c.close()
 return {'qualified':True,'cases':out}

def T2(run,code,expr,patched):
 c=new(run,'replace_fault',code,patched)
 try:
  c.inject=True;first=call_error(lambda:c.b.event('INERT_FAULT'));assert isinstance(first,PermissionError)
  before=observe(c);assert before['events']==2 and before['checkpoint_seq']==1 and before['next_exists']
  second=call_error(c.b.checkpoint);after=observe(c)
  if patched:assert second is None and after['events']==2 and after['checkpoint_seq']==2 and not after['next_exists']
  else:assert isinstance(second,FileExistsError)
  return {'qualified':patched,'first_error':err(first),'retry_error':err(second),'before':before,'after':after,'no_duplicate_append':before['events']==after['events'],'primary_retained':not patched or c.protocol.primary[id(c.b)]['exception'] is first}
 finally:c.close()

def T3(run,code,expr,patched):
 out=[]
 for label,share in [('control',None),('read_write',3),('read_write_delete',7)]:
  c=new(run,label,code,patched);handle=fixture.held_handle(c.b.path/'current.json',share) if share is not None else None
  try:
   failure=call_error(lambda:c.b.event('INERT_READER'))
  finally:
   if handle is not None:assert fixture.KERNEL.CloseHandle(handle)
  try:
   retry=call_error(c.b.checkpoint) if failure else None;q=observe(c)
   if share is None:assert failure is None
   if patched:assert retry is None and q['events']==q['checkpoint_seq']==2
   elif failure:assert isinstance(retry,FileExistsError)
   out.append({'case':label,'access':2147483648 if share else None,'share':share,'open_existing':3 if share else None,'flags':128 if share else None,'native_error':err(failure),'handle_closed':handle is not None,'retry_error':err(retry),'journal':q})
  finally:c.close()
 return {'qualified':patched,'cases':out,'historical_native_cause':'UNOBSERVED'}

def T4(run,code,expr,patched):
 c=new(run,'secondary_fault',code,patched)
 try:
  c.inject=True;first=call_error(lambda:c.b.begin_ha(2,0,fixture.input_fixture()));assert isinstance(first,PermissionError)
  secondary=call_error(lambda:c.b.finish(False,{'inert':True}));q=observe(c)
  if patched:
   assert secondary is first and c.protocol.primary[id(c.b)]['exception'] is first
   hard=classify(first,'checkpoint')['hard'];soft=classify(ValueError('E2_fake'),'fixture')['hard'];assert hard and not soft
   assert q['events']==2 and q['failed']==0 and q['unresolved']==1
  else:
   assert isinstance(secondary,FileExistsError);hard=eval(expr,{'__builtins__':{'str':str}},{'exc':first});soft=eval(expr,{'__builtins__':{'str':str}},{'exc':ValueError('E2_fake')});assert not hard
  return {'qualified':patched,'first_error':err(first),'finish_error':err(secondary),'same_primary_object':secondary is first,'plain_native_hard':hard,'ordinary_fixture_E1_hard':soft,'journal':q,'full_production_run':'STATIC_ONLY_NOT_EXECUTED'}
 finally:c.close()

def T5(run,code,expr,patched):
 c=new(run,'preSTOP',code,patched)
 try:
  (c.protocol.publish_stop() if patched else c.stop())
  e=call_error(lambda:c.b.begin_ha(2,0,fixture.input_fixture()));assert e is not None;q=observe(c)
  assert q['charged_checkpoint']==0 and q['entered']==0
  if patched:assert q['memory_counts']['HA']==0
  first={'error':err(e),'journal':q}
 finally:c.close()
 c=new(run,'race',code,patched);trigger=threading.Event();attempt=threading.Event();done=threading.Event();times={};errors=[]
 def publisher():
  try:
   assert trigger.wait(5);times['publish_attempt']=time.perf_counter_ns();attempt.set()
   if patched:times['STOP_ACK']=c.protocol.publish_stop()
   else:c.stop();times['STOP_ACK']=time.perf_counter_ns()
  except BaseException as e:errors.append(err(e))
  finally:done.set()
 thread=threading.Thread(target=publisher,name='OWNED_STOP_PUBLISHER');thread.start()
 def boundary():
  trigger.set();assert attempt.wait(5)
  if not patched:assert done.wait(5)
 c.before_replace=boundary
 try:
  if patched:c.protocol.admit_and_enter(c.b,fixture.input_fixture(),c.dummy_entry)
  else:c.b.begin_ha(2,0,fixture.input_fixture());c.dummy_entry()
  times['entry_return']=time.perf_counter_ns();thread.join(5);assert not thread.is_alive() and not errors
  q=observe(c);assert q['charged_checkpoint']==q['entered']==1
  if patched:
   trace=c.protocol.trace;entry=next(x['qpc_ns'] for x in trace if x['kind']=='INERT_ENTRY_RETURN');ack=next(x['qpc_ns'] for x in trace if x['kind']=='STOP_ACK');assert entry<=ack
  else:trace=[];assert times['STOP_ACK']<=times['entry_return']
  late=call_error(lambda:c.b.begin_ha(2,0,fixture.input_fixture()));assert late is not None
  return {'qualified':patched,'preexisting':first,'race':q,'times':times,'protocol_trace':trace,'subsequent_admission_denied':err(late),'new_entry_after_ACK':0 if patched else 1,'scope':'LOCAL_FENCE_ONLY_GLOBAL_UNVERIFIED','owned_thread_joined':True}
 finally:trigger.set();thread.join(5);assert not thread.is_alive();c.close()

def T6(run,code,expr,patched):
 mode='PATCHED_DERIVED_CANDIDATE' if patched else 'ORIGINAL_UNCHANGED';target=run/'worker';cmd=[sys.executable,'-B',str(Path(__file__).resolve()),'--root',str(ROOT),'--group','T6','--worker',str(target),'--mode',mode]
 proc=subprocess.Popen(cmd,executable=sys.executable,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=False)
 try:out,stderr=proc.communicate(timeout=30)
 except subprocess.TimeoutExpired:proc.kill();out,stderr=proc.communicate(timeout=5);raise
 (run/'worker.stdout').write_bytes(out);(run/'worker.stderr').write_bytes(stderr);assert proc.returncode==23 and proc.poll()==23
 cp=json.loads((target/'arm/science/current.json').read_bytes());assert cp['counts']['HA']==1 and cp['counts']['HA_completed']==cp['counts']['HA_failed']==0 and cp['activeHA']==1
 denied=call_error(lambda:fixture.instantiate_class(code,{'runtime':{},'R':target,'sys':sys,'os':os,'json':json,'datetime':fixture.datetime,'msvcrt':msvcrt,'pathlib':pathlib})({},'RESTART',target/'arm'));assert isinstance(denied,FileExistsError)
 with (target/'arm/science/writer.lock').open('r+b',buffering=0) as lock:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1);lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
 return {'qualified':True,'owned_helpers':1,'reaped':1,'exit':23,'charged':1,'entered':0,'completed':0,'failed':0,'unresolved':1,'active':1,'restart_refused':err(denied),'lock_reacquired':True,'reconstruction':'READ_ONLY_WRAPPER_ONLY'}

def J1(run,code,expr,patched):
 out=[]
 for kind in ['event_seq','boolean_seq','boolean_counter','event_prev','current_corrupt','partial_next','unknown_valid_next','partial_event','duplicate_JSON_next','mismatched_known_stage']:
  c=new(run,kind,code,patched)
  try:
   ev=c.b.path/'events.jsonl';cp=c.b.path/'current.json';nxt=c.b.path/'current.next'
   if kind in ['event_seq','event_prev','boolean_seq','boolean_counter']:
    row=json.loads(ev.read_bytes())
    if kind=='event_seq':row['seq']=9
    elif kind=='event_prev':row['previousEventSHA256']='1'*64
    elif kind=='boolean_seq':row['seq']=True
    else:row['counts']['HA']=False
    ev.write_bytes((json.dumps(row,sort_keys=True)+'\n').encode())
   elif kind=='current_corrupt':cp.write_bytes(b'{partial')
   elif kind=='partial_next':nxt.write_bytes(b'{')
   elif kind=='unknown_valid_next':nxt.write_bytes(cp.read_bytes())
   elif kind=='partial_event':ev.write_bytes(ev.read_bytes()[:-1])
   elif kind=='duplicate_JSON_next':nxt.write_bytes(b'{"seq":1,"seq":2}')
   else:
    c.inject=True;assert call_error(lambda:c.b.event('INERT_STAGED')) is not None;nxt.write_bytes(b'{"seq":999}')
   before={x.name:digest(x.read_bytes()) for x in [ev,cp,nxt] if x.exists()};e=call_error(c.b.checkpoint);after={x.name:digest(x.read_bytes()) for x in [ev,cp,nxt] if x.exists()}
   if patched:assert e is not None and before==after and classify(e,'checkpoint')['hard']
   out.append({'case':kind,'rejected':e is not None,'error':err(e),'data_files_unchanged':before==after,'before':before,'after':after})
  finally:c.close()
 return {'qualified':patched,'cases':out}

def J2(run,code,expr,patched):
 c=new(run,'repeat',code,patched)
 try:
  c.b.event('INERT_REPEAT');before=observe(c);inode=(c.b.path/'current.json').stat().st_ino
  for _ in range(3):c.b.checkpoint()
  after=observe(c);assert before==after and before['events']==2
  if patched:assert inode==(c.b.path/'current.json').stat().st_ino
  stable={'before':before,'after':after,'checkpoint_inode_stable':inode==(c.b.path/'current.json').stat().st_ino}
 finally:c.close()
 c=new(run,'recover_repeat',code,patched)
 try:
  c.inject=True;assert call_error(lambda:c.b.event('INERT_REPEAT_FAULT')) is not None
  failed_view=observe(c);assert failed_view['checkpoint_seq']==1
  errors=[err(call_error(c.b.checkpoint)) for _ in range(3)];q=observe(c)
  if patched:assert errors==[None]*3 and q['checkpoint_seq']==q['events']==2 and not q['next_exists']
  else:assert all(x is not None for x in errors)
  return {'qualified':patched,'normal_repeat':stable,'pre_recovery_checkpoint':failed_view['checkpoint_seq'],'recovery_attempts':errors,'after':q,'exactly_once_events':q['events']==2}
 finally:c.close()

def audit(root):
 def hook(event,args):
  if event=='open' and not isinstance(args[0],int):
   path=Path(os.fsdecode(args[0])).absolute();mode=str(args[1] or '');flags=args[2]
   writing=any(x in mode for x in 'wax+') or bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
   if writing and root not in path.parents:raise RuntimeError('STOP_UNSAFE_WRITE')
   if not writing and root not in path.parents and Path(sys.base_prefix) not in path.parents:raise RuntimeError('STOP_UNSAFE_READ')
  if event=='import' and args[0].split('.')[0] not in sys.stdlib_module_names:raise RuntimeError('STOP_UNSAFE_IMPORT')
  if event=='subprocess.Popen':assert Path(args[0]).resolve()==Path(sys.executable).resolve() and str(Path(__file__).resolve()) in args[1]
 sys.addaudithook(hook)

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--group',choices=['T1','T2','T3','T4','T5','T6','J1','J2'],required=True);ap.add_argument('--attempt',type=int,choices=[1,2,3],default=1);ap.add_argument('--worker');ap.add_argument('--mode',choices=['ORIGINAL_UNCHANGED','PATCHED_DERIVED_CANDIDATE']);a=ap.parse_args();ROOT=Path(a.root).resolve()
 p=json.loads((ROOT/'private/TASK_PARAMETERS.json').read_bytes());assert ROOT==Path(p['execution']['scratch'])
 code0,expr,identity=load_code(ROOT,'ORIGINAL_UNCHANGED');code1,_,_=load_code(ROOT,'PATCHED_DERIVED_CANDIDATE');audit(ROOT)
 if a.worker:
  target=Path(a.worker).resolve();assert ROOT in target.parents;c=fixture.Context(target,code1 if a.mode=='PATCHED_DERIVED_CANDIDATE' else code0,patched=a.mode=='PATCHED_DERIVED_CANDIDATE');c.b.begin_ha(2,0,fixture.input_fixture());os._exit(23)
 run=ROOT/'runs'/(a.group+'_attempt'+str(a.attempt));run.mkdir();rows={}
 try:
  for mode,code in [('ORIGINAL_UNCHANGED',code0),('PATCHED_DERIVED_CANDIDATE',code1)]:
   folder=run/mode;folder.mkdir();rows[mode]=globals()[a.group](folder,code,expr,mode.startswith('PATCHED'))
   save(run/(mode+'.json'),rows[mode])
  result={'group':a.group,'attempt':a.attempt,'paired':rows,'same_fixture':True,'real_science_calls':0,'result':'ISOLATED_PASS' if rows['PATCHED_DERIVED_CANDIDATE']['qualified'] else 'PARTIAL'};save(run/'results.json',result);print(json.dumps(result))
 except BaseException:
  (run/'first_error.private.txt').write_text(traceback.format_exc(),encoding='utf-8');raise
