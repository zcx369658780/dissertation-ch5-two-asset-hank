"""SOURCE_ONLY exact value/unit and independently supplied scope gate; never infer scope from a number."""
from decimal import Decimal,InvalidOperation
import re
FACTORS={'people':Decimal('0.0001'),'wan_people':Decimal(1),'yuan/person/year':Decimal(1),'thousand_yuan/person/year':Decimal(1000)}
def validate(source,target):
 for key,status in [('province','PROVINCE_MISMATCH'),('geographic_axis','PROVINCE_AXIS_ERROR'),('year','YEAR_MISMATCH'),('population','POPULATION_SCOPE_MISMATCH'),('time_type','TIME_SCOPE_NOT_EQUIVALENT'),('geographic_basis','GEOGRAPHIC_BASIS_MISMATCH')]:
  if source.get(key) in (None,'UNKNOWN') or target.get(key) in (None,'UNKNOWN'): return 'INDETERMINATE_'+key.upper()
  if source[key]!=target[key]: return status
 if not source.get('value') or not target.get('value'): return 'SOURCE_MISSING'
 if source.get('unit') not in FACTORS: return 'UNIT_UNMAPPED'
 try: normalized=Decimal(source['value'].replace(',',''))*FACTORS[source['unit']]
 except InvalidOperation: return 'VALUE_PARSE_ERROR'
 expected_unit='wan_people' if source['unit'] in ('people','wan_people') else 'yuan/person/year'
 if target['unit']!=expected_unit:return 'TARGET_UNIT_MISMATCH'
 if normalized!=Decimal(target['value']):return 'VALUE_CONFLICT'
 if not source.get('locator') or not source.get('source_sha256'):return 'INDETERMINATE_SOURCE_LOCATOR'
 return 'PASS_UNIT_AND_SCOPE_MATCH'
def numeric_tokens(text):
 return [(m.group(),m.start(),m.end()) for m in re.finditer(r'(?<![\d.])\d+(?:,\d{3})*(?:\.\d+)?(?![\d.])',text)]
def oracle_suite():
 import copy
 s=dict(province='吉林',geographic_axis='PROVINCE',year=2018,population='URBAN_NONPRIVATE_UNIT_EMPLOYED',time_type='YEAR_END',geographic_basis='WORKPLACE_UNIT_REPORTING',value='2793233',unit='people',locator='2019吉林年鉴 B4_2 全省合计',source_sha256='7b6e9bdce3315c1e75358ff2a83ac3768df3577db91f86aaa3c854dfea74b86f')
 t={**s,'value':'279.3233','unit':'wan_people'}
 cases=[]
 def case(name,a,b,expected):
  actual=validate(a,b);cases.append(dict(name=name,source=a,target=b,expected=expected,actual=actual,passed=actual==expected))
 case('JL_EXACT_PEOPLE_TO_WAN',s,t,'PASS_UNIT_AND_SCOPE_MATCH')
 case('JL_ONE_PERSON_DIFFERENCE',{**s,'value':'2793232'},t,'VALUE_CONFLICT')
 case('YEAR_END_NOT_ANNUAL_AVERAGE',s,{**t,'time_type':'ANNUAL_AVERAGE'},'TIME_SCOPE_NOT_EQUIVALENT')
 case('YEAR_2017_NOT_2018',{**s,'year':2017},t,'YEAR_MISMATCH')
 case('SHAANXI_TIBET_COLUMN_OFFSET',{**s,'province':'陕西'},{**t,'province':'西藏'},'PROVINCE_MISMATCH')
 case('HANGZHOU_NOT_ZHEJIANG',{**s,'province':'浙江','geographic_axis':'CITY'},{**t,'province':'浙江'},'PROVINCE_AXIS_ERROR')
 case('NO_VALUE_IS_NOT_ZERO',{**s,'value':None},t,'SOURCE_MISSING')
 case('NONPRIVATE_NOT_TOTAL',s,{**t,'population':'TOTAL_EMPLOYED'},'POPULATION_SCOPE_MISMATCH')
 case('UNKNOWN_TIME_REJECT',{**s,'time_type':'UNKNOWN'},t,'INDETERMINATE_TIME_TYPE')
 case('RESIDENCE_NOT_WORKPLACE',s,{**t,'geographic_basis':'RESIDENCE'},'GEOGRAPHIC_BASIS_MISMATCH')
 names=['北京','天津','河北','山西','内蒙古','辽宁','吉林','黑龙江','上海','江苏','浙江','安徽','福建','江西','山东','河南','湖北','湖南','广东','广西','海南','重庆','四川','贵州','云南','西藏','陕西','甘肃','青海','宁夏','新疆']
 for i,p in enumerate(names):
  for metric,unit,raw in [('WAGE','yuan/person/year',str(31001+i*137)),('EMPLOYED','people',str(700001+i*113))]:
   q={**s,'province':p,'population':metric,'time_type':'ANNUAL_AVERAGE' if metric=='WAGE' else 'YEAR_END','unit':unit,'value':raw,'locator':'SYNTHETIC_ASYMMETRIC_ORACLE_ONLY'}
   v={**q,'unit':'yuan/person/year' if metric=='WAGE' else 'wan_people','value':str(Decimal(raw)*FACTORS[unit])}
   case(f'{p}_{metric}_POS',q,v,'PASS_UNIT_AND_SCOPE_MATCH')
   case(f'{p}_{metric}_PERMUTED',q,{**v,'province':names[(i+1)%31]},'PROVINCE_MISMATCH')
   case(f'{p}_{metric}_WRONG_YEAR',{**q,'year':2017},v,'YEAR_MISMATCH')
   case(f'{p}_{metric}_WRONG_UNIT',{**q,'unit':'wan_people' if metric=='EMPLOYED' else 'thousand_yuan/person/year'},v,'VALUE_CONFLICT')
 assert all(c['passed'] for c in cases),[c for c in cases if not c['passed']]
 return cases
if __name__=='__main__':
 import pathlib,json
 p=pathlib.Path(__file__).parent
 c=oracle_suite();(p/'unit_validator_tests.json').write_text(json.dumps(dict(cases=c,passed=len(c),failed=0),ensure_ascii=False,indent=2),encoding='utf-8');print('ORACLES_PASS',len(c))
