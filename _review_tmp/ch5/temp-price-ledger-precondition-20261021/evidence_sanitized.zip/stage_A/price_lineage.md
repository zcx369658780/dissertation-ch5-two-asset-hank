# TEMP V010 price attribution — SOURCE_ONLY
No production import or model execution. Sources S06–S17 are the twelve frozen research inputs; source_identity.json binds full commits, native Git blob IDs, SHA256 and bytes. References use original UTF-8 file line numbering. S12=firm, S13=wage, S14=steady_state, S15=capital_network, S16=one_turn; S11=V010 frozen plan. SOURCE_NOT_AVAILABLE is a boundary, not permission to open another source.

## Price production and consumption
```text
completed raw return(t-1) -> zscore(ddof=0) -> S_t(destination,origin)
 current returned HA At_i * N_i ----same S_t----> private capital_j
 completed raw return(t-1) ---------same S_t----> entering rah_t
 private capital_j + GovInv_j; destination labor -> firm_t
 firm_t -> raw ra0_t / clipped ra_t -> boundary Corptax compensation
        -> raw wt0_t / clipped wjt_t -> boundary Corptax compensation
 raw wt0_t + destination tau_j + sigma_ji + phi_ji -> net w_eff_(t+1)
 raw ra0_t @ S_t -> displayed post-turn rah; reprepare next turn uses S_(t+1)
 firm_t and per-capita fiscal quantities -> public-account diagnostics
 completed diagnostics -> gated GovInv/Zt adaptation -> next firm state
```
The actual HA-entry adapter and TEMP bridge are not among the five code files. These arrows to HA state demonstrate producers/intended interfaces, not actual runtime consumption. prepare_mainline_household_states rewrites rah (S16:346–363); it does not rewrite w_eff. The separate post-turn rah=raw_t@S_t need not equal the next pre-HA rah=raw_t@S_(t+1). Neither difference alone is a bug.

## What static code proves
S12:61–111 produces firm K,Y,m,wt0,rk,profit and ra0. Firm mt depends on lagged K,L,Z,pi and prior rk, so fixed-others capital comparisons cannot be extrapolated to full endogenous iterations.
S12:119–134 clips firm ra and wjt and transfers price differences into Corptax. S16:401–419 deliberately sends raw wt0 into the mainline net wage and records raw return separately from clipped firm rates. Legacy composition S16:212–238 uses old clipped ra and firm.wjt; it is not the same route as run_mainline_one_turn.
S15:275–342 proves column-normalized same-S private-capital conservation and payoff identity. In the mainline, At is per-capita returned household wealth; multiplication by N occurs once. Public GovInv enters firm K separately and must not be counted in private household portfolio shares.
S13:52–75 proves additive destination tau/sigma deductions and rejects negative net power bases; S13:87–92 labels the resulting index net and the intended HA tau zero. No actual HA consumer is directly inspected.
S12:140 directly proves the mainline GovInc formula using tau*wt0*L; S16:405 calls imported fiscal accounting whose body is outside the permitted set. Returned fiscal fields and literal WageTax implementation remain SOURCE_NOT_AVAILABLE.
S14:197–232 and S11:30 specify the joint max-KN<0.1 gate, Zt target correction, then low-ra GovInv*.9 before high-ra *1.1. Only accepted review S07:44–48 connects this behavior to the historical TEMP run. The local controller shown in S14 invokes the legacy one-turn (235–254); no claim that a complete TEMP driver was inspected.

## Units and branch distinctions
Returns are per model period; the calendar mapping and real-data normalization are NOT_OBSERVED here. Gross wages have model-numeraire/labor units. The net composite wage is an unnormalized nonlinear labor-utility index and may exceed any destination wage: this is not proof of a unit bug. Homogeneity under joint wage rescaling is tested algebraically.
S11:24,26,32 freezes destination tax once, same-S raw lagged capital and per-capita/aggregate fiscal bridging. The original MATLAB comparison is REVIEW_ACCEPTED_STATIC_FACT in S07:62–80, not newly read MATLAB code. Its clipped-ra/used-wjt route differs from the formally adopted V010 route; reverting it requires Owner scientific approval.
Outer convergence excludes capital-price boundaries and requires qualified households and KN/Y stability (S14:303–314). Wage boundary is recorded, not an added stop criterion. TARGET_CALIBRATION_VERIFIED requires additional frozen-input verification per S11:30 and is not inferred from a fiscal identity.

## Historical accepted observations, not new trajectory verification
S08:18–23 reports 100 rounds, final max KN gap 0.1075218256230952, max cross-round Y gap 0.012719310966908814, households 0/2, ra and wage boundary frequency 100/100 per province. S07:23–38 reports raw ra0 minima >0.09 and final rounded .384584/.427239. S07:46 reports 26 GovInv and 23 Zt adjustments per province. The original 100 rows and private ZIP were not read here.
S07:62–80 reports same-state rah about .389/.419 versus firm .09 and raw-wage net index about 6.948/7.029 versus substituted-wjt index about 2.038/2.019. Those substitutions are pure static formula comparisons, not new HA experiments or convergence evidence.
S09:14–18 reports A1 append seq11 versus checkpoint9, A2/A3 seq25, delayed global STOP, and no comparable complete factorial results. This task does not reopen those runs.

## Missing sources and exact boundary
SOURCE_NOT_AVAILABLE: TEMP experiment_bridge/driver and actual post-prepare pre-HA input snapshots; initial fixture raw bytes; all 100 original trajectory rows; HA adapter; migration implementation; fiscal_diagnostics implementation; original production journal and checkpoint code; original MATLAB text. Do not infer actual values or causal outcomes for these components. Any future access needs a newly bounded source scope (NEEDS_OWNER_E3_SOURCE_SCOPE).
Stage A verdict: SUPPORTED_SOURCE_ONLY_WITH_EXPLICIT_INCOMPLETE_CONSUMER_AND_RUNTIME_SOURCES. No new steady state, factorial effect, market clearing, HA error, or Results claim.
