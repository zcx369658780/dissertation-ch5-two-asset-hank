# Private derived Budget repair, not deployed

Authenticated original archive: 1214713 bytes,
SHA256 f3e8984fe4d2ef4be65692c27fa7594d96b870d372a8c45d029899f7891841d8.
Exactly two named source members were read (28651 decoded bytes), never imported.
The original factorial module is 12102 bytes with SHA256
2f956b9c1495d1026b23b219da059681b9cdd98fadb9233acf02154559ddf456.
The accepted public ZIP was fetched at its historical candidate and Git Blob,
not the cleaned branch head. Its original bytes and 13 authorized reusable named
members were verified. Frozen public inputs were checked with native Git hashes.

The private candidate changes ONLY guard, event, checkpoint, begin_ha and finish.
Constructor, profile, close, limits and all code outside Budget retain their ASTs.
No original production file or journal was edited. The candidate retains the
production module's excluded top-level effects and run as private source only:
neither original nor derived full modules are imported or executed. Tests compile
only authenticated Budget/limits ASTs under explicit inert/stdlib bindings.

R1: events and SHA-chain define truth; current must match a valid prefix within
one event. A staged replacement must match the current event head AND a running
owner's remembered file identity/hash. Unknown, changed, partial or ambiguous
stage is retained and rejected. Committed checkpoints are no-ops. WinError5 leaves
original current and owned stage intact. Recovery is limited to this live owner;
it does not introduce a general restart or resume constructor.

R2: the first exception object and structured diagnostic are retained before
secondary reporting. finish rethrows a blocked primary without incrementing failed
or appending a misleading error event. A normal finish writes its cleared-active
state into the event, so checkpoint does not silently diverge at the same seq.
The original exception type is preserved; typed classification is sidecar metadata.

R3: typed prefix/STOP faults and context-specific access/uncertain ledger failures
are hard; ordinary fixture E1 is not. The original full run's text classifier is
unchanged and unexecuted. Future production wiring must consume the structured
primary classification rather than its E2_ display text; that integration remains
outside this task. No production catch path is claimed qualified.

R4: a local cooperating admission/STOP protocol uses an owned byte-lock file and
reentrant mutex. The inert callback runs under the same outer fence as admission.
Threaded race tests demonstrate LOCAL_FENCE only. Actual multi-process publishers,
external supervisor/reader, power-loss durability and uncoordinated STOP writers
are not qualified; no GLOBAL_STOP_ATOMICITY claim is made.

The new support, builder, inert fixture support and paired tests are public.
Original full source, exact private full diff, private diagnostics and disposable
journal streams are retained locally. The public diff shows operative new edits
with explicit elisions of unchanged/private old bodies; the public builder plus
source identity makes its exact derivation inspectable without exposing old code.
