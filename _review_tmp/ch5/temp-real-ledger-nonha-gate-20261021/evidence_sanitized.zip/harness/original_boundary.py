"""Extract frozen original methods without executing either production module.

The private input is required. This public helper contains no archived method body.
Only the extracted Budget class and pure limits function are compiled. All runtime
bindings are disposable stdlib wrappers; this is not a production qualification.
"""
import ast
import builtins
import copy
import hashlib
import json
import symtable
from pathlib import Path

EXPECTED_GLOBALS = {'msvcrt','sys','os','runtime','R','datetime','json','limits',
                    'pathlib','RuntimeError','dict','len','str','int'}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def canonical(node):
    return ast.dump(node, annotate_fields=True, include_attributes=False)

def gate(source, expected):
    data = source.read_bytes()
    assert len(data) == expected['bytes'] and digest(data) == expected['sha256']
    original = ast.parse(data, filename='<private-original-static-only>')
    budget = [n for n in original.body if isinstance(n, ast.ClassDef) and n.name == 'Budget']
    limits = [n for n in original.body if isinstance(n, ast.FunctionDef) and n.name == 'limits']
    assert len(budget) == len(limits) == 1
    budget, limits = budget[0], limits[0]
    assert not budget.bases and not budget.decorator_list and not budget.keywords
    assert all(isinstance(n, ast.FunctionDef) for n in budget.body)
    methods = {}
    for n in budget.body + [limits]:
        assert not n.decorator_list
        assert not any(isinstance(q, (ast.Import, ast.ImportFrom, ast.Global, ast.Nonlocal)) for q in ast.walk(n))
        assert not any(isinstance(q, ast.Call) and isinstance(q.func, ast.Name)
                       and q.func.id in {'eval','exec','compile','__import__','getattr','setattr'} for q in ast.walk(n))
        table = symtable.symtable(ast.unparse(n), '<static-symbols>', 'exec').get_children()[0]
        globals_used = {q.get_name() for q in table.get_symbols() if q.is_global() and q.is_referenced()}
        assert globals_used <= EXPECTED_GLOBALS, globals_used - EXPECTED_GLOBALS
        extracted = copy.deepcopy(n)
        assert canonical(n) == canonical(extracted)
        segment = ast.get_source_segment(data.decode('utf-8'), n).encode('utf-8')
        methods[n.name] = {'line': n.lineno, 'end_line': n.end_lineno,
                           'source_segment_sha256': digest(segment),
                           'original_ast_sha256': digest(canonical(n).encode()),
                           'extracted_ast_sha256': digest(canonical(extracted).encode()),
                           'body_unchanged': True, 'globals': sorted(globals_used)}
    extract = ast.Module(body=[copy.deepcopy(limits), copy.deepcopy(budget)], type_ignores=[])
    ast.fix_missing_locations(extract)
    assert canonical(extract.body[1]) == canonical(budget)
    # The full run function is never compiled or called. Extract one pure compare.
    matches = []
    run = next(n for n in original.body if isinstance(n, ast.FunctionDef) and n.name == 'run')
    for n in ast.walk(run):
        if isinstance(n, ast.Dict):
            for k, v in zip(n.keys, n.values):
                if isinstance(k, ast.Constant) and k.value == 'sharedHardGate':
                    matches.append(v)
    assert len(matches) == 1
    compare = matches[0]
    assert isinstance(compare, ast.Compare) and len(compare.ops) == 1 and isinstance(compare.ops[0], ast.In)
    assert isinstance(compare.left, ast.Constant) and compare.left.value == 'E2_'
    assert ast.unparse(compare.comparators[0]) == 'str(exc)'
    expr = ast.fix_missing_locations(ast.Expression(copy.deepcopy(compare)))
    imports = [ast.unparse(n) for n in ast.walk(original) if isinstance(n, (ast.Import, ast.ImportFrom))]
    effects = [{'node': type(n).__name__, 'line': n.lineno} for n in original.body
               if not isinstance(n, (ast.FunctionDef, ast.ClassDef, ast.Import, ast.ImportFrom))]
    evidence = {'module_sha256': digest(data), 'module_bytes': len(data), 'methods': methods,
                'compiled_nodes': ['limits','Budget'], 'production_module_executed': False,
                'imports_static_only': imports, 'excluded_module_effects': effects,
                'classifier_ast_sha256': digest(canonical(compare).encode()),
                'run_status': 'SOURCE_STATIC_ONLY_NOT_RUNTIME_VERIFIED',
                'dynamic_dependencies': 'EXPLICIT_STDLIB_AND_INERT_BINDINGS_ONLY'}
    return compile(extract, '<isolated-original-budget>', 'exec'), compile(expr, '<original-pure-classifier>', 'eval'), evidence

def instantiate_class(code, bindings):
    # No import/eval/exec capability is available to original method bodies.
    safe = {k: getattr(builtins, k) for k in ['__build_class__','object','RuntimeError',
            'AssertionError','dict','len','str','int']}
    namespace = {'__builtins__': safe, '__name__': 'isolated_original_budget', **bindings}
    exec(code, namespace)
    return namespace['Budget']
