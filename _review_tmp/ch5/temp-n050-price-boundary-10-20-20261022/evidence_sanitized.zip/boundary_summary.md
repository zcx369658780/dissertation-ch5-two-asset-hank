# 每省边界汇总

比例分母仅包含实际完整轮；raw越界才计裁切。家庭字段仅参考带。

| province | stage | firm_field | valid_complete_rounds | upper_hits | lower_hits | upper_pct | lower_pct | first_hit_round | trend | first_contiguous_hit_interval | inside_to_outside | outside_to_inside |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| SYN_A | FIRST_10 | ra | 10 | 10 | 0 | 100 | 0 | 1 | PERSISTENT | [1, 10] | [] | [] |
| SYN_A | FIRST_10 | wjt | 10 | 10 | 0 | 100 | 0 | 1 | PERSISTENT | [1, 10] | [] | [] |
| SYN_A | ALL_COMPLETE | ra | 20 | 20 | 0 | 100 | 0 | 1 | PERSISTENT | [1, 20] | [] | [] |
| SYN_A | ALL_COMPLETE | wjt | 20 | 20 | 0 | 100 | 0 | 1 | PERSISTENT | [1, 20] | [] | [] |
| SYN_B | FIRST_10 | ra | 10 | 10 | 0 | 100 | 0 | 1 | PERSISTENT | [1, 10] | [] | [] |
| SYN_B | FIRST_10 | wjt | 10 | 10 | 0 | 100 | 0 | 1 | PERSISTENT | [1, 10] | [] | [] |
| SYN_B | ALL_COMPLETE | ra | 20 | 20 | 0 | 100 | 0 | 1 | PERSISTENT | [1, 20] | [] | [] |
| SYN_B | ALL_COMPLETE | wjt | 20 | 20 | 0 | 100 | 0 | 1 | PERSISTENT | [1, 20] | [] | [] |
