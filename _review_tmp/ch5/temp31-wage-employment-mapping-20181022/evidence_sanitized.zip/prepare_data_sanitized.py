import sys,pathlib,json,csv,io,hashlib,zipfile,base64,re,datetime
from decimal import Decimal
from lxml import html
from intake_and_events import canonical
from mapping_oracles import interpolate
R=pathlib.Path(__file__).parent;sys.stdout.reconfigure(encoding='utf-8')
def sha(b):return hashlib.sha256(b).hexdigest()
def put(n,x):
 with (R/n).open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2)
def csvout(n,rows):
 with (R/n).open('x',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
old=list(csv.DictReader((R/'prior/source_value_normalization_ledger.csv').read_text(encoding='utf-8-sig').splitlines()));panel=list(csv.DictReader((R/'prior/wage_employment_2018_31_verified.csv').read_text(encoding='utf-8-sig').splitlines()))
metrics=['wage_private_yuan_year','wage_nonprivate_yuan_year','N_resident_wan','E_employed_resident_origin_wan','E_employed_workplace_destination_wan','E_wage_private_annual_average_wan','E_wage_nonprivate_annual_average_wan','N_wage_nonprivate_year_end_wan']
mapold={'wage_private_yuan_year':'wage_private_yuan_year','wage_nonprivate_yuan_year':'wage_nonprivate_yuan_year','N_resident_wan':'N_resident_wan','N_wage_nonprivate_year_end_wan':'N_wage_covered_nonprivate_wan'}
observed=[];imputed=[];scenario=[];sources=[];count=0
for p in panel:
 o=dict(province=p['province'],year=2018,layer='O',model_adopted=False);ir=dict(province=p['province'],year=2018,layer='I',model_adopted=False);sr=dict(province=p['province'],year=2018,layer='S',model_adopted=False)
 for m in metrics:
  rs=[r for r in old if r['province']==p['province'] and r['metric']==mapold.get(m)];r=rs[-1] if rs else None
  eligible=bool(r and r['VALIDATION_STATUS']=='PASS_UNIT_AND_SCOPE_MATCH' and r['SOURCE_CLASS']=='STATISTICAL_AGENCY_ORIGINAL' and r['SOURCE_BYTE_STATUS']=='ORIGINAL_BYTES_VERIFIED' and r['TIME_TYPE']!='UNKNOWN' and r['GEOGRAPHIC_BASIS']!='UNKNOWN')
  if m=='N_wage_nonprivate_year_end_wan':eligible=eligible and r['TIME_TYPE']=='YEAR_END'
  status='OBS_SOURCE_VERIFIED_TEMP_CANDIDATE' if eligible else 'MISSING_QUALIFIED_OFFICIAL_SOURCE_OR_SCOPE'
  o[m]=r['NORMALIZED_VALUE'] if eligible else 'NA';o[m+'_status']=status;o[m+'_source_id']=r['source_id'] if eligible else '';count+=eligible
  ir[m]='NA';ir[m+'_status']='NOT_IMPUTED_O_PRESENT' if eligible else 'NO_VERIFIED_COMPARABLE_2017_2019_ENDPOINT_PAIR'
  sr[m]='NA';sr[m+'_status']='NEEDS_OWNER_E3_NO_OFFICIAL_RATIO_ADOPTED'
  sources.append(dict(province=p['province'],target_year=2018,metric=m,layer='O' if eligible else 'UNVERIFIED_REFERENCE_OR_MISSING',value=o[m],previous_value=r['NORMALIZED_VALUE'] if r else 'NA',previous_status=r['VALIDATION_STATUS'] if r else 'UNMAPPED',source_id=r['source_id'] if r else '',url=r['url'] if r else '',sha256=r['SOURCE_SHA'] if r else '',source_class=r['SOURCE_CLASS'] if r else 'MISSING',vintage=r['DOC_VINTAGE'] if r else 'UNKNOWN',raw_value=r['RAW_VALUE'] if r else '',raw_unit=r['RAW_UNIT'] if r else '',time_type=r['TIME_TYPE'] if r else 'UNKNOWN',geographic_basis=r['GEOGRAPHIC_BASIS'] if r else 'UNKNOWN',geographic_axis='PROVINCE',population=r['STAT_POPULATION'] if r else 'UNKNOWN',lookup_time='HISTORICAL_TIMESTAMP_IN_FIXED_RECEIPT_OR_UNKNOWN',endpoint_2017='NOT_VERIFIED',endpoint_2019='NOT_VERIFIED',reason=status))
 observed.append(o);imputed.append(ir);scenario.append(sr)
csvout('wage_employment_2018_observed_31.csv',observed);csvout('wage_employment_2018_interpolated_31.csv',imputed);csvout('wage_employment_2018_scenario_31.csv',scenario)
csvout('prior_observations_preserved_31.csv',panel)
# Read only a precisely named earlier archive referenced by the accepted prior package; obtain one unchanged source, not a refetch.
zp=pathlib.Path('FROZEN_SOURCE_PATH_REDACTED');zb=zp.read_bytes()
if sha(zb)!='962d1f789ccd6f61fccbad503ab1a4d780c30abdb8af38c9730a03321bdfcca2':raise RuntimeError('REFERENCED_ORIGINAL_ZIP_IDENTITY_MISMATCH')
with zipfile.ZipFile(io.BytesIO(zb)) as z:rec=next(json.loads(l) for l in z.read('official_origin_bytes.jsonl').decode().splitlines() if json.loads(l)['source_id']=='FJ_P')
fb=base64.b64decode(rec['content_base64']);assert sha(fb)==rec['sha256']
ft=html.fromstring(fb.decode('utf-8'));[x.drop_tree() for x in ft.xpath('//script|//style')];t=re.sub(r'\s+',' ',ft.text_content())
first=t.find('2018年，全省城镇私营单位就业人员年平均工资');paragraph=t[first:first+250];m=re.search(r'2017年的(\d+)',paragraph);v17=m.group(1) if m else None
fj=json.loads((R/'FJ_PRIVATE_2019_outcome.json').read_text(encoding='utf-8'));tj=fj.get('text','');match=re.search(r'2019年，全省城镇私营单位就业人员年平均工资为(\d+)',tj);v19=match.group(1) if match else None
same_scope=all(s in t and s in tj for s in ['城镇私营单位','税前工资','全面调查和抽样调查相结合','GB/T4754-2017'])
endpoint_base=dict(province='福建',metric='wage_private_yuan_year',unit='yuan/person/year',population='URBAN_PRIVATE_UNIT_EMPLOYED',time_type='ANNUAL_AVERAGE',geographic_basis='UNIT_REPORTING',definition_version='GB/T4754-2017_PRIVATE_UNIT_TAX_PRE_ANNUAL_WAGE' if same_scope else 'UNKNOWN',original_verified=True)
a={**endpoint_base,'year':2017,'value':v17,'url':rec['url'],'sha256':rec['sha256'],'vintage':'2019 release reporting 2018 and 2017 base'}
b={**endpoint_base,'year':2019,'value':v19,'original_verified':fj.get('provider_http')==200 and fj.get('original_bytes_complete'),'url':fj['request'],'sha256':fj.get('sha256'),'vintage':'2020-05-25 release reporting 2019'}
sensitivity=interpolate(a,b);sensitivity.update(role='OBSERVED_HOLDOUT_DIAGNOSTIC_ONLY_NOT_MISSING_VALUE_FILL',observed_2018='52930',endpoint_2017=a,endpoint_2019=b,same_definition_checks=same_scope,no_O_overwrite=True)
if sensitivity['status']=='I_CANDIDATE_NOT_OFFICIAL':
 sensitivity['difference_from_observed']=str(Decimal(sensitivity['log_linear'])-Decimal('52930'));sensitivity['relative_difference_from_observed']=str(Decimal(sensitivity['difference_from_observed'])/Decimal('52930'))
put('observed_holdout_endpoint_sensitivity.json',sensitivity)
sources.append({k:'' for k in sources[0]})
sources[-1].update(province='福建',target_year=2018,metric='wage_private_yuan_year',layer='HOLDOUT_REFERENCE_NOT_I_FILL',value=sensitivity.get('log_linear','NA'),previous_value='52930',source_id='FJ_2017_AND_2019_HOLDOUT',url=a['url']+' | '+b['url'],sha256=a['sha256']+' | '+str(b['sha256']),source_class='OFFICIAL_ORIGINAL_ENDPOINTS',vintage=a['vintage']+' | '+b['vintage'],raw_value=str(v17)+' | '+str(v19),raw_unit='yuan/person/year',time_type='ANNUAL_AVERAGE',geographic_basis='UNIT_REPORTING',geographic_axis='PROVINCE',population='URBAN_PRIVATE_UNIT_EMPLOYED',lookup_time=fj['requested_utc'],endpoint_2017=str(v17),endpoint_2019=str(v19),reason='O already present, retain observed; diagnostic interpolation never fills O')
csvout('official_source_and_endpoint_ledger.csv',sources)
legal_sources=[]
for sid,value,year,source,rawt,rawsha,request_time in [('FJ_P_BASE2017',v17,2017,rec['url'],paragraph,rec['sha256'],'PRIOR_FIXED_EVIDENCE'),('FJ_PRIVATE_2019',v19,2019,fj['request'],tj[match.start():match.end()+80] if match else '',fj.get('sha256'),fj['requested_utc'])]:
 legal_sources.append(dict(source_id=sid,source_url=source,data_year=year,publication_vintage='2019 release' if year==2017 else '2020 release',value=value,unit='yuan/person/year',raw_source_sha256=rawsha,locator='body first statewide annual private wage paragraph',short_excerpt=rawt[:110],retrieved_utc=request_time,original_bytes_verified=True,full_article_not_republished=True))
put('official_endpoint_excerpt_evidence.json',legal_sources)
events=[json.loads(l) for l in (R/'historical_canonical_events.jsonl').read_text(encoding='utf-8').splitlines()];new=[]
for f in sorted(R.glob('call_*_intent.json')):
 intent=json.loads(f.read_text(encoding='utf-8'));outpath=f.with_name(f.name.replace('_intent','_outcome'));out=json.loads(outpath.read_text(encoding='utf-8')) if outpath.exists() else None
 for qi,(kind,payload) in enumerate(canonical(intent['args'])):
  new.append(dict(event_id=intent['call_id']+'-'+str(qi),billing_run='CURRENT',request_kind=kind,batch_index=int(intent['call_id'].split('-')[-1]),query_index=qi,request=payload,request_time_utc=intent['requested_utc'],completed_utc=out['completed_utc'] if out else 'UNKNOWN',attempt_state='ATTEMPTED_RECEIPT_SAVED' if out else 'ATTEMPTED_OUTCOME_UNAVAILABLE',source_id=intent['call_id'],receipt_sha256=sha(outpath.read_bytes()) if out else '',provider_http='UNKNOWN_TOOL_RECEIPT_NOT_ORIGIN_HTTP',new_budget_charge=1))
for f in sorted(R.glob('*_intent.json')):
 if f.name.startswith('call_'):continue
 intent=json.loads(f.read_text(encoding='utf-8'));outpath=f.with_name(f.name.replace('_intent','_outcome'));out=json.loads(outpath.read_text(encoding='utf-8'))
 new.append(dict(event_id=intent['event_id'],billing_run='CURRENT',request_kind='official_http',batch_index=0,query_index=0,request=intent['request'],request_time_utc=intent['requested_utc'],completed_utc=out['completed_utc'],attempt_state='ATTEMPTED_RECEIPT_SAVED',source_id=intent['source_id'],receipt_sha256=sha(outpath.read_bytes()),provider_http=out.get('provider_http'),transport_error=out.get('transport_error'),new_budget_charge=1))
assert len({s['event_id'] for s in events+new})==len(events+new)
raw_calls=list(R.glob('call_*_intent.json'));independent_count=sum(len(json.loads(f.read_text(encoding='utf-8'))['events']) for f in raw_calls)+len(list(R.glob('*PRIVATE_2019_intent.json')))+len(list(R.glob('JS_WAGES_2019_intent.json')))
assert len(new)==independent_count and len(new)<=160
with (R/'source_request_canonical_events.jsonl').open('x',encoding='utf-8') as f:
 for s in events+new:f.write(json.dumps(s,ensure_ascii=False)+'\n')
put('source_request_reconciliation.json',dict(historical_event_count=len(events),historical_frozen_independent_count=58,historical_budget_charge=0,historical_faulty_count=50,current_event_count=len(new),current_independent_dispatch_intents=independent_count,current_match=len(new)==independent_count,all_events=len(events+new),duplicate_ids=0,policy='one query/open/HTTP attempt = one event including failed attempts',E1_used=0,money_cost='UNKNOWN_PROVIDER_BILLING_NOT_EXPOSED'))
put('data_coverage_summary.json',dict(O_qualified_cells=count,O_provinces=sum(any(p[m]!='NA' for m in metrics) for p in observed),I_filled_cells=0,S_numeric_cells=0,complete_panel_provinces=0,observed_does_not_mean_Owner_adopted=True,household_population_workbook_read=False,reason='symbolic mapping does not require reopening private canonical workbook',metrics=metrics,new_source_requests=len(new)))
print(json.dumps(dict(O_qualified_cells=count,I_filled=0,S_numeric=0,current_events=len(new),holdout=sensitivity),ensure_ascii=False))
